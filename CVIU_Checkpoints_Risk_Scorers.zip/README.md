# Source-selected risk-head weights

18 original checkpoint files, six families x three fixed runs; no retraining or inference was performed for packaging. The manifest binds family/run, selected step, original location and SHA-256. All original bytes match the retained checkpoint identities. Total checkpoint bytes: 1,447,128.

These are risk heads, not RAFT-Stereo or Depth Anything backbone weights. Use the recorded normalization/model/input code in the editable source and S3/S4. The plain pretrained-model provenance and exact project entry/asset requirements are in MATERIALS_ACCESS.md. Loading weights alone cannot recreate cached stereo/mono/GT inputs. Files were prepared locally for the author; public redistribution/license and actual external delivery remain the author's decision.
