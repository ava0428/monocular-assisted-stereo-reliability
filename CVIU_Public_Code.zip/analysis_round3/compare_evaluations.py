"""CPU-only reductions of saved original/additional results; no model or CAL execution."""
from pathlib import Path
import csv,json,hashlib
from collections import defaultdict
import numpy as np
H=Path(__file__).resolve().parent;A=H.parent
def load(p):return json.loads(p.read_text(encoding='utf-8'))
def rows(p):return list(csv.DictReader(p.open(encoding='utf-8')))
def writecsv(n,x):
 with (H/n).open('w',newline='',encoding='utf-8') as f:
  w=csv.DictWriter(f,fieldnames=list(x[0]));w.writeheader();w.writerows(x)
def dump(n,x):(H/n).write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8')
oldrows=rows(A/'results/canonical_summary/scene_metrics_19x45.csv')
newrows=rows(A/'analysis_round2/regenerated_scene_metrics.csv')
old={(r['scene'],r['method']):r for r in oldrows};assert len(old)==855
new={(r['scene'],r['family'],r['seed'],r['rule'],r['tau']):r for r in newrows};assert len(new)==len(newrows)==19*49
scenes=sorted({r['scene'] for r in oldrows});seeds=['20260910','20260911','20260912'];families=['r1','r2_concat','r2_dis','r2_gate']
labels={'r1':'Stereo-Err','r2_concat':'Stereo+Mono','r2_dis':'Stereo+Mono+Disag','r2_gate':'Base-Risk'}
idx=np.random.default_rng(20260913).integers(0,19,size=(10000,19))
def boot(x):
 d=x.mean(axis=0);lo,hi=np.quantile(d[idx].mean(axis=1),[.025,.975])
 return {'delta':float(d.mean()),'ci_low':float(lo),'ci_high':float(hi)}
def arr(origin,fam,metric,rule='qd/a'):
 if origin=='original':return np.array([[float(old[s,'Rel-Analytic:'+fam+':'+seed][metric]) for s in scenes] for seed in seeds])
 return np.array([[float(new[s,fam,seed,rule,'0.9' if rule=='qd/a' else ''][metric]) for s in scenes] for seed in seeds])
# Exact frame IDs and fixed checkpoint identities, rather than row positions.
original_frames={r['frame'] for r in load(A/'results/canonical_summary/status.json')['frames']}
frame_records=rows(A/'analysis_round2/core_frame_metrics.csv')+rows(A/'analysis_round2/extras_frame_metrics.csv')
assert len(frame_records)==5292
expected={r['scene']+'/'+r['frame_id'] for r in rows(A/'review_support/split_frames.csv') if r['role']=='EVAL'}
assert original_frames==expected=={r['scene']+'/'+r['frame'] for r in frame_records}
counts=defaultdict(int)
for f in expected: counts[f.split('/')[0]]+=1
assert len(expected)==108 and len(counts)==19
for (scene,fam,seed,rule,tau),r in new.items():assert int(r['frames'])==counts[scene]
for r in oldrows:assert int(r['frames'])==counts[r['scene']]
cpold={(r['family'],r['seed']):r for r in load(A/'review_support/checkpoint_availability.json')}
cpnew={(r['family'],r['seed']):r for r in load(A/'analysis_round2/checkpoint_identity.json')}
for k,v in cpnew.items():assert v['sha256']==cpold[k]['sha256'] and v['selected_step']==cpold[k]['selected_step']
# Recompute every new scene mean from stored frame rows, preserving frame-then-scene weighting.
groups=defaultdict(list)
for r in frame_records:groups[r['scene'],r['family'],r['seed'],r['rule'],r['tau']].append(r)
max_reduction=0.
for k,rs in groups.items():
 assert len(rs)==counts[k[0]] and len({r['frame'] for r in rs})==len(rs)
 for metric in ['absrel_80','absrel_90','absrel_aurc']:
  e=abs(float(np.mean([float(r[metric]) for r in rs]))-float(new[k][metric]));max_reduction=max(max_reduction,e);assert e<1e-14
means=[];pairs=[];directions=[]
for metric in ['absrel_80','absrel_90']:
 for fam in families:
  o,n=arr('original',fam,metric),arr('additional',fam,metric)
  means.append({'family':fam,'metric':metric,'original_mean':float(o.mean(axis=1).mean()),'original_run_sd':float(o.mean(axis=1).std(ddof=1)),'additional_mean':float(n.mean(axis=1).mean()),'additional_run_sd':float(n.mean(axis=1).std(ddof=1)),'additional_minus_original':float(n.mean()-o.mean())})
 for fam in ['r2_concat','r2_gate']:
  for origin in ['original','additional']:
   a,b=arr(origin,fam,metric),arr(origin,'r1',metric);p=boot(a-b)
   pairs.append({'evaluation':origin,'family':fam,'metric':metric,**p,'relative_reduction_percent':float(100*(b.mean(axis=1).mean()-a.mean(axis=1).mean())/b.mean(axis=1).mean())})
for origin in ['original','additional']:
 d=(arr(origin,'r2_gate','absrel_80')-arr(origin,'r1','absrel_80')).mean(axis=0)
 directions.append({'evaluation':origin,'favourable_scenes':int((d<0).sum()),'total':19,'Mirror_delta':float(d[scenes.index('Mirror')]),'scene_unit':'three fixed runs averaged within Booster directory group'})
matched=[];unmatched=[]
for k,n in new.items():
 scene,fam,seed,rule,tau=k
 if fam=='Depth-Only':method='Depth-Only'
 elif fam in families and rule=='qd/a' and tau=='0.9':method=f'Rel-Analytic:{fam}:{seed}'
 elif fam in ['r1','r2_gate'] and rule=='projected_raw' and tau=='':method=f'Raw:{fam}:{seed}'
 else:unmatched.append({'scene':scene,'family':fam,'seed':seed,'rule':rule,'tau':tau,'reason':'No same-path/same-policy configuration in original evaluation'});continue
 assert (scene,method) in old
 for metric in ['absrel_80','absrel_90','absrel_aurc']:
  ov=float(old[scene,method][metric]);nv=float(n[metric]);matched.append({'scene':scene,'method':method,'family':fam,'seed':seed,'rule':rule,'tau':tau,'metric':metric,'original':ov,'additional':nv,'difference':nv-ov})
assert len(matched)==19*19*3
maxrow=max(matched,key=lambda r:abs(r['difference']))
cal=load(A/'analysis_round2/cal_refit.json')['rows'];maxfit=max((r for r in cal if r['tau']==.9),key=lambda r:abs(r['delta_vs_historical']))
fit={'family':maxfit['family'],'seed':maxfit['seed'],'tau':maxfit['tau'],'original_delta':maxfit['historical_delta'],'additional_delta':maxfit['delta'],'difference':maxfit['delta_vs_historical'],'unit':'native disparity px'}
path=[]
for rule in ['h0/a','qd/a']:
 x,y=arr('additional','r1','absrel_80',rule),arr('additional','r2_gate','absrel_80',rule)
 path.append({'rule':rule,'stereo_mean':float(x.mean(axis=1).mean()),'stereo_sd':float(x.mean(axis=1).std(ddof=1)),'base_mean':float(y.mean(axis=1).mean()),'base_sd':float(y.mean(axis=1).std(ddof=1)),**boot(y-x),'relative_reduction_percent':float(100*(x.mean(axis=1).mean()-y.mean(axis=1).mean())/x.mean(axis=1).mean())})
base_offset=boot(arr('additional','r2_gate','absrel_80','qd/a')-arr('additional','r2_gate','absrel_80','h0/a'))
depth=float(np.mean([float(new[s,'Depth-Only','0','1/a','']['absrel_80']) for s in scenes]))
result={'status':'PASS_SAVED_RESULT_CONSISTENCY','matched_identity':'family, checkpoint hash/run, path, tau, metric/coverage, frame IDs and scene groups','frame_count':108,'scenes':scenes,'seeds':seeds,'intersection_configurations':19,'unmatched_additional_configurations':30,'unmatched_original_configurations':26,'max_new_frame_to_scene_difference':max_reduction,'cohort_means':means,'paired_contrasts':pairs,'scene_directions':directions,'largest_scene_run_difference':maxrow,'largest_tau90_offset_difference':fit,'construction_paths':path,'base_fitted_offset_difference':base_offset,'DepthOnly':depth,'bootstrap':{'replicates':10000,'seed':20260913,'unit':'scene-directory group after fixed-run averaging','multiplicity_adjusted':False,'CAL_refitted':False},'limitations':['Same exposed cohort; not independent validation.','Known execution-environment differences do not by themselves explain every numerical difference.','Intersection excludes unmatched paths; no comparison by row position.']}
dump('execution_consistency.json',result);writecsv('matched_scene_comparison.csv',matched);writecsv('unmatched_additional_rows.csv',unmatched);writecsv('cohort_comparison.csv',means);writecsv('paired_comparison.csv',pairs)
matched_original={(r['scene'],r['method']) for r in matched}
writecsv('unmatched_original_rows.csv',[{'scene':r['scene'],'method':r['method'],'reason':'No same-path/same-policy configuration in additional re-evaluation'} for r in oldrows if (r['scene'],r['method']) not in matched_original])
# Main text table: shared rule once, mean/SD from unrounded fixed-run means.
ls=[r'\begin{inlinetable}\centering\small',r'\caption{Dimensionless AbsRel in the fitted-offset comparison of the additional re-evaluation at retained coverage $\rho=0.80$. For each scorer, its inputs and source-selected weights are held fixed across the two processing paths; the cohort and three run labels are shared. Values are mean $\pm$ sample run SD; differences are Base-Risk minus Stereo-Err with 95\% descriptive paired-scene intervals. These results are separate from the original evaluation in Table~\ref{tab:core}. Depth-Only is one shared rule, with no run SD or between-scorer contrast.}\label{tab:offset}',r'\setlength{\tabcolsep}{4pt}\renewcommand{\arraystretch}{1.2}',r'\begin{tabular}{lrrr}\toprule',r'Ordering & Stereo-Err & Base-Risk & Difference [95\% interval]\\\midrule']
for p in path:
 label=r'$h_0/a$ ($\delta=0$)' if p['rule']=='h0/a' else r'$q_d/a$ ($\tau=0.90$)'
 ls.append(label+f" & ${p['stereo_mean']:.6f} \\pm {p['stereo_sd']:.6f}$ & ${p['base_mean']:.6f} \\pm {p['base_sd']:.6f}$ & \\shortstack{{{p['delta']:+.6f}\\\\{{[{p['ci_low']:+.6f}, {p['ci_high']:+.6f}]}}}}"+r'\\')
ls.append(r'Depth-Only ($1/a$) & \multicolumn{2}{c}{'+f'{depth:.6f} (shared)'+r'} & ---\\\bottomrule\end{tabular}\end{inlinetable}')
(H/'main_offset_table.tex').write_text('\n'.join(ls)+'\n')
ls=[r'\begin{supplementtable}\centering\small',r'\caption{Matched-configuration consistency between the original evaluation (O) and additional re-evaluation (A), at $\tau=0.90$. AbsRel means use the same 19 scene-directory groups and three runs. Differences and intervals in panel (b) are multiplied by $10^4$; intervals are descriptive paired-scene bootstrap intervals, not run SDs.}\label{tab:execution_consistency}',r'\textbf{(a) Cohort means}\par\smallskip',r'\begin{tabular}{llrrr}\toprule Scorer & $\rho$ & O & A & A$-$O\\\midrule']
for r in means:ls.append(f"{labels[r['family']]} & {'0.80' if r['metric']=='absrel_80' else '0.90'} & {r['original_mean']:.9f} & {r['additional_mean']:.9f} & {r['additional_minus_original']:+.9f}"+r'\\')
ls += [r'\bottomrule\end{tabular}\par\medskip',r'\textbf{(b) Contrast with matched Stereo-Err}\par\smallskip',r'\begin{tabular}{llrr}\toprule Contrast & $\rho$ & O: $\Delta$ [95\% interval] & A: $\Delta$ [95\% interval]\\\midrule']
for metric in ['absrel_80','absrel_90']:
 for fam in ['r2_concat','r2_gate']:
  pp=[next(r for r in pairs if r['family']==fam and r['metric']==metric and r['evaluation']==origin) for origin in ['original','additional']]
  ls.append(labels[fam]+(' & 0.80' if metric=='absrel_80' else ' & 0.90')+' & '+' & '.join(f"${r['delta']*1e4:+.3f}\\;[{r['ci_low']*1e4:+.3f}, {r['ci_high']*1e4:+.3f}]$" for r in pp)+r'\\')
ls += [r'\bottomrule\end{tabular}\par\medskip',r'\textbf{(c) Base-Risk minus Stereo-Err at $\rho=0.80$}\par\smallskip',r'\begin{tabular}{lrr}\toprule Evaluation & Negative scene means & Mirror difference\\\midrule']
for r in directions:ls.append(f"{r['evaluation'].capitalize()} & {r['favourable_scenes']}/19 & {r['Mirror_delta']:+.9f}"+r'\\')
ls += [r'\bottomrule\end{tabular}\end{supplementtable}']
(H/'execution_consistency_table.tex').write_text('\n'.join(ls)+'\n')
def old_base(rule):return float(np.mean([[float(old[s,f'{rule}:r2_gate:{seed}']['absrel_80']) for s in scenes] for seed in seeds]))
rawcal=old_base('DispCal')-old_base('Raw');calra=old_base('Rel-Analytic')-old_base('DispCal')
mantissa,exponent=f'{rawcal:.2e}'.split('e')
macros={'RoundThreeZeroPct':f"{path[0]['relative_reduction_percent']:.2f}",'RoundThreeFittedPct':f"{path[1]['relative_reduction_percent']:.2f}",'RoundThreeRawCal':mantissa+r'\times10^{'+str(int(exponent))+'}','RoundThreeCalRA':f'{calra:.5f}'}
dump('original_path_display_source.json',{'DispCal_minus_Raw':rawcal,'RA_minus_DispCal':calra,'formatted':macros})
(H/'display_macros.tex').write_text('\n'.join('\\newcommand{\\'+k+'}{'+v+'}' for k,v in macros.items())+'\n')
print(json.dumps({k:result[k] for k in ['status','scene_directions','largest_scene_run_difference','largest_tau90_offset_difference','construction_paths','base_fitted_offset_difference']},indent=2))
