# CVIU public code and saved-result inputs

Research: *Monocular-Assisted Reliability for Stereo Depth: The Role of Score
Processing and Coverage*, Zhenqi Wei and Jinsong Hu. This is the curated public
code/results derivative of the 2026-10-23 figure-refined local source. It is not
the manuscript source ZIP and does not claim a standalone raw-model pipeline.

## Start here

Extract this ZIP into a fresh directory. With Python 3 and NumPy installed:

```sh
python reproduce.py summary
```

This replays paired scene changes from saved original/additional matrices and
renders display tables using saved CAL-refit results. It runs no model, native
pixel evaluation or CAL refit. It rewrites derived analysis outputs, so retain
the ZIP and work in a fresh extraction.

For the explicit CAL-group refit diagnostic, use the separate
`CVIU_Analysis_Calibration_Public.zip`, which includes the six exact sampled
operands and their Booster CC BY-NC notice; run `python reproduce.py cal-bootstrap`
there. This refits the saved sampled CAL operands only; it does not propagate
refits into EVAL selective risks. The six operands are not duplicated here.

## Plotting and checks

Requires NumPy and Matplotlib. From the extracted root:

```sh
python analysis_revision/build_core_figures.py
python analysis_round8/plot_mechanism.py
python analysis_round8/plot_scenes.py
python review_support/verify_review.py
```

The figure generators read unrounded saved records/intervals and create outputs
under `manuscript/figures/`; that output path does not mean the manuscript itself
is bundled. The S3 verifier is a marked public copy: it verifies every retained
source hash and reports one deliberately omitted unlicensed upstream inspection
file. Its empirical/synthetic statistical calculations are unchanged.

Figure 1/6 display-generation scripts are supplied for inspection, but their
Booster image/display NPZs and final embedded-image figure exports are excluded.
They do not run without those inputs. Original preparation scripts identify the
data-generation paths; some are historical project-path entries and are not a
validated clean-host workflow. Do not run historical preparation/model scripts
over a preserved results archive.

## Public companion files

Original evaluation: S1 ZIP and S2 CSV. Implementation/configuration/splits:
S3_Public. Additional-execution records: S4 ZIP. Execution consistency and CAL
diagnostic: separate analysis ZIPs. Source-selected risk heads: six-family
18-checkpoint ZIP and separate three-checkpoint Rel-Direct ZIP. Source identities,
original/additional execution labels, precise data and weight bytes are retained.

Original author code uses MIT; original saved results/shareable head checkpoints
use the selected CC BY 4.0 grant subject to existing third-party rights. Read
LICENSE, LICENSE-CC-BY-4.0.txt and THIRD_PARTY_NOTICES.md. The DAV2 preprocessing
adapter includes Apache-2.0-derived code and a marked public-copy attribution.
Booster operands in the separate archive retain their CC BY-NC 4.0 notice.
Weights retain SceneFlow source-training provenance; no third-party backbone
weights or raw datasets are redistributed here.
