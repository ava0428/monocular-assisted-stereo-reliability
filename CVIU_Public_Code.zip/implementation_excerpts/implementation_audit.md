# Bounded implementation/availability audit

The canonical evaluator source is independently SHA-256 matched to its frozen run contract. It uses `cv2.resize` / `cv2.INTER_LINEAR` on `np.float64` arrays, with `(width,height)` destination order. P4 multiplies disparity/radius by four after interpolation; raw scores use the same helper with scale one. OpenCV has no `align_corners` argument here. The run records OpenCV 5.0.0 and NumPy 2.3.2.

The v15 delivery manifest explicitly sets `raw_score_GT_checkpoint_included=false`. The separate checkpoint manifest records 18 identities; 108 sealed frame receipts retain 1944 score identities. These identity records are provenance evidence, not delivery of model weights or score maps. Replace main line 205's `Released weights and scores` with `Recorded checkpoint and score-file identities`. The scientific review bundle supplies summary data, diagnostics, visualization samples and an offline summary-reproduction ZIP.

## Coordinate convention and distinct APIs

The [official OpenCV 5.0.0 source](https://github.com/opencv/opencv/blob/5.0.0/modules/imgproc/src/resize.cpp#L3865) uses `x_source=(x_destination+0.5)*W_source/W_destination-0.5` (y analog at line 3918), with source edge repetition. For P4, both ratios are one quarter. The generic CV_64F path uses double pixel buffers with float interpolation coefficients (lines 3656--3660); array dtype does not imply every library-internal operation uses float64. The [official resize API](https://docs.opencv.org/4.13.0/da/d54/group__imgproc__transform.html) has no `align_corners` option.

The run-bound input/operand manifests confirm quarter `(H,W)=(752,1028)` and native `(H,W)=(3008,4112)` metadata for all inputs. The input manifest's `INTER_AREA` rule concerns source RGB downsampling for inference; native map projection uses `INTER_LINEAR`.

The donor-map operation is separately `torch.nn.functional.interpolate`, float32, target `(H,W)`, bilinear, `align_corners=False`. Its archived source matches both the recorded CAL source manifest and recovered component source record. DDCV-LR uses `grid_sample`, float32, bilinear, zero padding and `align_corners=True`; its disparity/W grid implies displacement `d*(W-1)/W`. These settings do not apply to native OpenCV resize.

The 2x3 synthetic CPU ramp resized to 8x12 through the exact frozen helper AST passes with zero error against the half-pixel/edge-clamp expectation, including the factor-four unit conversion. It uses local OpenCV 4.12.0 / NumPy 2.0.2, so it is a local implementation check only. The historical run's OpenCV package/build bytes are not hash-bound in the consulted records.

`proposed_main_si_insertions.tex` contains the concise main replacement, detailed SI definition and availability correction. No raw operands, checkpoint bytes or models were opened, and this audit does not alter the active paper.

The nature-polishing shared core dependencies are absent from the installed skill tree. The installed local methods/English/generic fragments were used, with all wording bounded by the verified source.
