"""Bound native two-frame path and retained-set analysis, no model forwards."""
from pathlib import Path
import ast,json,hashlib,time,math,sys
import numpy as np
import cv2
HERE=Path(__file__).resolve().parent;ROOT=next(p for p in HERE.parents if (p/'src/models/risk_predictor.py').exists())
def load(p):return json.loads(p.read_text(encoding='utf-8'))
src=HERE.parent/'review_support/sources/scripts/jise_exact_unified_eval_v1.py';tree=ast.parse(src.read_text(encoding='utf-8'));ns={'np':np,'math':math,'BOUNDS':(0.,.2,.4,.6,.8,.9,1.)}
for name in ['exact_metrics']:
    node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name==name);exec(compile(ast.Module(body=[node],type_ignores=[]),str(src),'exec'),ns)
exact=ns['exact_metrics'];old=ROOT/'outputs/jise_numeric_close_v1_synced_20261005';fits={f"{x['family']}:{x['seed']}":x['delta'] for x in load(old/'cal_fits_20261005.json')['fits']}
results=[];sets=[]
for scene in ['Door','Mirror']:
    ip=ROOT/'outputs/jise_mono_ablation_booster_inputs_20261005/frames'/(scene+'_im0.npz')
    with np.load(ip) as z:d0=z['stereo_disparity']
    with np.load(ROOT/'outputs/jise_mono_ablation_booster_eval_operands_20261005'/(scene+'.npz')) as z:gt=z['gt_disparity']
    u=np.isfinite(gt)&(gt>0);shape=gt.shape;target=(shape[1],shape[0]);d=cv2.resize(d0.astype(float),target,interpolation=cv2.INTER_LINEAR)[u]*4;e=np.abs(d-gt[u]);a=d;loss=e/a
    def project(raw):return cv2.resize(raw.astype(float),target,interpolation=cv2.INTER_LINEAR)[u]
    for origin,fam,rawpath in [('historical','r2_gate',ROOT/'outputs/ddcv_rel_cal_validation_20261012/baseRA_maps/r2_gate_seed20260910'/(scene+'_im0.npy')),('regenerated','r1',HERE/'pilot_scores/r1'/(scene+'_im0.npy')),('regenerated','r2_gate',HERE/'pilot_scores/r2_gate'/(scene+'_im0.npy'))]:
        raw=np.load(rawpath);h0=project(np.maximum(np.expm1(raw.astype(float)),0))*4;delta=fits[fam+':20260910'];q=np.maximum(0,h0+delta)
        for rule,risk in [('projected_raw',project(raw)),('h0',h0),('h0/a',h0/a),('qd/a',q/a),('1/a',1/a)]:
            t=time.perf_counter();metric,_=exact(risk,{'absrel':loss},262144);elapsed=time.perf_counter()-t
            r={'scene':scene,'frame':'im0','run':'seed0','origin':origin,'family':fam,'rule':rule,'seconds':elapsed,'absrel_80':metric['absrel_80'],'absrel_90':metric['absrel_90'],'absrel_aurc':metric['absrel_aurc'],'n':len(d),'EVAL_pixel_empirical_radius_coverage':float(np.mean(e<=q)),'delta':delta}
            results.append(r);print(scene,origin,fam,rule,round(elapsed,2),r['absrel_80'],flush=True)
        if origin=='historical':
            k=math.ceil(.8*len(d));bm=np.zeros(len(d),bool);dm=bm.copy();bm[np.argsort(q/a,kind='stable')[:k]]=True;dm[np.argsort(1/a,kind='stable')[:k]]=True
            for label,m in [('shared',bm&dm),('Base-only',bm&~dm),('Depth-only',dm&~bm),('neither',~bm&~dm)]:
                sets.append({'scene':scene,'group':label,'count':int(m.sum()),'mean_absrel':float(loss[m].mean()) if m.any() else None,'loss_sum_over_common_k80':float(loss[m].sum()/k),'retained_count_k80':k})
    del gt,u,d,e,a,loss,h0,q
(HERE/'native_pilot.json').write_text(json.dumps({'classification':'historical two-frame analysis plus separately marked regenerated pilot','calibration_source':'Historical delta replay for both origins; full regenerated validation separately uses current refits.','rows':results,'retained_sets':sets},indent=2)+'\n')
