"""Compare declared sources and donor assignments, without altering history."""
from pathlib import Path
import json,hashlib,io
import numpy as np
HERE=Path(__file__).resolve().parent;ROOT=next(p for p in HERE.parents if (p/'src/models/risk_predictor.py').exists());OUT=HERE.parents[2]/'compute_round2'
def load(p):return json.loads(p.read_text(encoding='utf-8'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
rows=[]
for r in load(HERE.parent/'review_support/source_identity.json'):
    rel=r['path'];p=ROOT/rel
    if p.is_file() and (rel.startswith('src/') or rel.startswith('configs/')):rows.append({'path':rel,'current_sha256':sha(p),'preserved_sha256':r['sha256'],'equal':sha(p)==r['sha256']})
donors=[]
for role,old in [('CAL',ROOT/'outputs/jise_mono_ablation_cal_eval_joint_20261005/cal_receipts/run_manifest.json'),('EVAL',ROOT/'outputs/jise_mono_ablation_target_metrics_20261005/component_scores_20261005_a5/run_manifest.json')]:
    expected=load(old)['n_shuffle_donor_map'];new=load(OUT/role/'run.json')['donor_map'];assert new==expected;donors.append({'role':role,'equal':True,'frames':len(new)})
legacy=[]
for fam in ['r1','r2_gate']:
    stem='Bathroom_im0';key=fam+'_seed20260910'
    with np.load(ROOT/'outputs/v4_booster_cal_scores_129_run1/frames'/(stem+'.npz')) as z:x=z[key]
    y=np.load(OUT/'CAL/raw_scores'/key/(stem+'.npy'));b=io.BytesIO();np.save(b,x);saved=hashlib.sha256(b.getvalue()).hexdigest();rec=load(ROOT/'outputs/jise_mono_ablation_cal_eval_joint_20261005/cal_receipts/raw_scores'/key/(stem+'.json'))
    legacy.append({'family':fam,'frame':stem,'array_equal_to_older_local_v4_cache':bool(np.array_equal(x,y)),'saved_array_sha256':saved,'remote_component_receipt_sha256':rec['score_sha256'],'receipt_match':saved==rec['score_sha256'],'scope':'One CAL frame only; do not infer exact all-family provenance from this comparison'})
(HERE/'execution_identity.json').write_text(json.dumps({'source_comparison':rows,'donor_mapping':donors,'CAL_legacy_probe':legacy,'adapter_difference':'The preserved early middlebury_scores.py lacks r2_concat/r2_dis imports, builder entries and parameter entries. The current adapter adds those two already-defined families; raw_score and load_verified_model bodies are unchanged. This does not identify the cause of numerical differences from remote scores.','interpretation':'Current reconstruction is a separate numerical execution, not a byte-identical restore; all current scores and current refits are used consistently.'},indent=2)+'\n')
z=load(HERE/'native_pilot.json');lines=[r'\begin{table}[!htbp]',r'\centering\small',r'\caption{Retained-set decomposition for the two historical examples at global coverage 0.80 and seed0. Each contribution is the sum of AbsRel over the stated set divided by the common retained count $k=\lceil0.80n\rceil$. The shared contribution appears in both risks. These are full-native-frame quantities, not estimates from the displayed images.}',r'\label{tab:round2_sets}',r'\begin{tabular}{llrrr}',r'\toprule Frame & Set & Pixels & Mean AbsRel & Contribution\\',r'\midrule']
for r in z['retained_sets']:
    if r['group']=='neither':continue
    lines.append(f"{r['scene']}/im0 & {r['group']} & {r['count']:,} & {r['mean_absrel']:.6f} & {r['loss_sum_over_common_k80']:.6f} \\\\")
lines += [r'\bottomrule',r'\end{tabular}',r'\end{table}']
(HERE/'retained_sets.tex').write_text('\n'.join(lines)+'\n')
print(json.dumps({'sources':len(rows),'changed':[r['path'] for r in rows if not r['equal']],'donors':donors,'legacy':legacy},indent=2))
