"""Frame->scene->equal scene, fixed-run averaging and original paired bootstrap."""
from pathlib import Path
import csv,json,importlib.util
from collections import defaultdict
import math
import numpy as np
HERE=Path(__file__).resolve().parent;INPUTS=HERE/'summary_inputs'
def csvload(p):return list(csv.DictReader(p.open(encoding='utf-8')))
def writecsv(p,rows):
    if not rows:return
    with p.open('w',newline='',encoding='utf-8') as f:w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
cal=json.loads((HERE/'cal_refit.json').read_text());calrows=[];calranges=[]
split=list(csv.DictReader((INPUTS/'split_frames.csv').open(encoding='utf-8')))
eval_pairs={(r['scene'],r['frame_id']) for r in split if r['role']=='EVAL'};cal_scenes={r['scene'] for r in split if r['role']=='CAL'}
assert len(eval_pairs)==108 and len({s for s,f in eval_pairs})==len(cal_scenes)==19
family_names=['r1','r2_gate','r2_concat','r2_dis','n_random','n_shuffle'];fixed_seeds=['20260910','20260911','20260912']
expected_fits={(f,int(s),t) for f in family_names for s in fixed_seeds for t in [.8,.9,.95]}
assert len(cal['rows'])==54 and {(r['family'],r['seed'],r['tau']) for r in cal['rows']}==expected_fits
for r in cal['rows']:
    assert r['n']==155648 and r['k']==math.ceil((155648+1)*r['tau']) and set(r['scene_sample_coverage'])==cal_scenes
    d=r['scene_sample_coverage'];lo=min(d.values());hi=max(d.values());calranges.append({'family':r['family'],'seed':r['seed'],'tau':r['tau'],'minimum':lo,'maximum':hi,'minimum_scenes':[s for s,v in d.items() if v==lo],'maximum_scenes':[s for s,v in d.items() if v==hi]})
    for scene,val in d.items():calrows.append({'family':r['family'],'seed':r['seed'],'tau':r['tau'],'scene':scene,'fitted_samples':8192,'empirical_coverage':val})
writecsv(HERE/'cal_fitted_sample_scene_coverage.csv',calrows)
(HERE/'cal_fitted_sample_coverage_ranges.json').write_text(json.dumps(calranges,indent=2)+'\n')
rows=[]
matrix=[]
for stage in ['core','extras']:
    p=HERE/(stage+'_frame_metrics.csv')
    if p.exists():
        current=csvload(p);byframe=defaultdict(list)
        for r in current:byframe[r['scene'],r['frame']].append(r)
        assert set(byframe)==eval_pairs
        if stage=='core':expected={('Depth-Only','0','1/a','')}|{(f,s,rule,'0.9' if rule=='qd/a' else '') for f in ['r1','r2_gate'] for s in fixed_seeds for rule in ['projected_raw','h0','h0/a','qd/a']}
        else:expected={(f,s,'qd/a',t) for f in ['r1','r2_gate'] for s in fixed_seeds for t in ['0.8','0.95']}|{(f,s,'qd/a','0.9') for f in ['r2_concat','r2_dis','n_random','n_shuffle'] for s in fixed_seeds}
        for key,rs in byframe.items():
            assert len(rs)==len(expected) and {(r['family'],r['seed'],r['rule'],r['tau']) for r in rs}==expected,(stage,key)
        matrix.append({'stage':stage,'frames':len(byframe),'scene_groups':19,'expected_rows_per_frame':len(expected),'observed_rows':len(current),'exact_config_set_every_frame':True,'duplicate_rows':0})
        rows+=current
identity=json.loads((HERE/'execution_identity.json').read_text());assert all(r['equal'] for r in identity['donor_mapping'])
recovery=json.loads((HERE/'score_recovery_complete.json').read_text());assert recovery['frames']==228 and recovery['forwards']==4104
(HERE/'matrix_verification.json').write_text(json.dumps({'status':'PASS','stages':matrix,'CAL_fits':54,'samples_each_CAL_fit':155648,'CAL_scenes_per_fit':19,'CAL_ranks_verified':True,'fixed_checkpoint_forwards':4104,'current_donor_maps_match_historical':True,'scope':'Complete summary/configuration-set verification; not a repeated raw-score/GT reevaluation'},indent=2)+'\n')
assert rows
groups=defaultdict(list)
for r in rows:groups[r['scene'],r['family'],r['seed'],r['rule'],r['tau']].append(r)
metrics=['absrel_80','absrel_90','absrel_aurc','EVAL_pixel_empirical_coverage']
scenes=[]
for (scene,family,seed,rule,tau),rs in sorted(groups.items()):
    scenes.append({'scene':scene,'family':family,'seed':seed,'rule':rule,'tau':tau,'frames':len(rs),**{m:float(np.mean([float(r[m]) for r in rs])) if all(r.get(m) not in ('',None) for r in rs) else None for m in metrics}})
writecsv(HERE/'regenerated_scene_metrics.csv',scenes)
coverage_scenes=[{k:r[k] for k in ['scene','family','seed','tau','frames','EVAL_pixel_empirical_coverage']} for r in scenes if r['rule']=='qd/a']
writecsv(HERE/'eval_empirical_coverage_scene.csv',coverage_scenes)
sg=defaultdict(list)
for r in scenes:sg[r['family'],r['seed'],r['rule'],r['tau']].append(r)
runrows=[]
for key,rs in sorted(sg.items()):
    assert len(rs)==19;runrows.append(dict(zip(['family','seed','rule','tau'],key),**{m:float(np.mean([r[m] for r in rs])) if all(r[m] is not None for r in rs) else None for m in metrics}))
writecsv(HERE/'regenerated_run_metrics.csv',runrows)
cg=defaultdict(list)
for r in runrows:cg[r['family'],r['rule'],r['tau']].append(r)
cohort=[]
for (family,rule,tau),rs in sorted(cg.items()):
    c={'family':family,'rule':rule,'tau':tau,'runs':len(rs)}
    for m in metrics:
        v=[r[m] for r in rs];c[m]=float(np.mean(v)) if all(x is not None for x in v) else None;c[m+'_sd']=float(np.std(v,ddof=1)) if len(v)>1 and all(x is not None for x in v) else None
    cohort.append(c)
writecsv(HERE/'regenerated_cohort_metrics.csv',cohort)
writecsv(HERE/'eval_empirical_coverage_cohort.csv',[{k:r[k] for k in ['family','tau','runs','EVAL_pixel_empirical_coverage','EVAL_pixel_empirical_coverage_sd']} for r in cohort if r['rule']=='qd/a'])
coverage_extremes=[]
for family,tau in sorted({(r['family'],r['tau']) for r in coverage_scenes}):
    group=[r for r in coverage_scenes if r['family']==family and r['tau']==tau];means={s:float(np.mean([r['EVAL_pixel_empirical_coverage'] for r in group if r['scene']==s])) for s in sorted({r['scene'] for r in group})}
    coverage_extremes.append({'family':family,'tau':tau,'aggregation':'frame mean within scene, fixed-run mean within scene, 19 scene groups equal weight','scene_mean_coverage':means,'minimum':min(means.values()),'maximum':max(means.values()),'minimum_scenes':[s for s,v in means.items() if v==min(means.values())],'maximum_scenes':[s for s,v in means.items() if v==max(means.values())]})
(HERE/'eval_empirical_coverage_ranges.json').write_text(json.dumps(coverage_extremes,indent=2)+'\n')
source=INPUTS/'analyze_jise_exact_unified_v1.py';sp=importlib.util.spec_from_file_location('saved',source);mod=importlib.util.module_from_spec(sp);sp.loader.exec_module(mod)
scene_names=sorted({r['scene'] for r in scenes});lut={(r['scene'],r['family'],r['seed'],r['rule'],r['tau']):r for r in scenes};seeds=['20260910','20260911','20260912'];idx=np.random.default_rng(20260913).integers(0,19,size=(10000,19));pairs=[]
def arr(family,rule,tau,metric):return np.array([[lut[s,family,seed if family!='Depth-Only' else '0',rule,tau][metric] for s in scene_names] for seed in seeds])
comparisons=[]
for fam in ['r1','r2_gate']:
    for l,r in [('h0','projected_raw'),('h0/a','h0'),('qd/a','h0/a')]:comparisons.append((fam,l,'0.9' if l=='qd/a' else '',fam,r,''))
    comparisons.append((fam,'qd/a','0.9','Depth-Only','1/a',''))
comparisons.append(('r2_gate','qd/a','0.9','r1','qd/a','0.9'))
for rule in ['projected_raw','h0','h0/a']:comparisons.append(('r2_gate',rule,'','r1',rule,''))
if (HERE/'extras_frame_metrics.csv').exists():
    for fam in ['r2_concat','r2_dis','n_random','n_shuffle']:comparisons.append((fam,'qd/a','0.9','r1' if fam.startswith('r2') else 'r2_dis','qd/a','0.9'))
    for tau in ['0.8','0.95']:comparisons.append(('r2_gate','qd/a',tau,'r1','qd/a',tau))
for lf,lr,lt,rf,rr,rt in comparisons:
    for metric in metrics[:3]:pairs.append({'left':lf+':'+lr+':'+lt,'right':rf+':'+rr+':'+rt,'metric':metric,**mod.paired_bootstrap(arr(lf,lr,lt,metric)-arr(rf,rr,rt,metric),idx)})
writecsv(HERE/'regenerated_paired_bootstrap.csv',pairs)
# Compare only like-for-like original raw/RA results, never replace them.
original=csvload(INPUTS/'scene_metrics_19x45.csv');old={(r['scene'],r['method']):r for r in original};parity=[]
for r in scenes:
    if r['family']=='Depth-Only':method='Depth-Only'
    elif r['family'] in ['r1','r2_gate','r2_concat','r2_dis'] and r['rule'] in ['projected_raw','qd/a'] and r['tau'] in ['', '0.9']:
        method=('Raw' if r['rule']=='projected_raw' else 'Rel-Analytic')+':'+r['family']+':'+r['seed']
    else:continue
    for m in metrics[:3]:parity.append({'scene':r['scene'],'method':method,'metric':m,'historical':float(old[r['scene'],method][m]),'regenerated':r[m],'difference':r[m]-float(old[r['scene'],method][m])})
writecsv(HERE/'canonical_comparison_no_replacement.csv',parity)
pg=defaultdict(list)
for r in parity:pg[(r['method'].rsplit(':',1)[0] if ':' in r['method'] else r['method']),r['metric']].append(r)
writecsv(HERE/'canonical_comparison_cohort.csv',[{'method_group':k[0],'metric':k[1],'historical':float(np.mean([r['historical'] for r in rs])),'regenerated':float(np.mean([r['regenerated'] for r in rs])),'difference':float(np.mean([r['difference'] for r in rs])),'max_abs_scene_run_difference':max(abs(r['difference']) for r in rs)} for k,rs in sorted(pg.items())])
summary={'classification':'current-code regenerated validation, not replacement canonical','frames':108,'scenes':19,'fixed_runs':3,'cohort':cohort,'paired':pairs,'max_abs_scene_numeric_difference_vs_historical':max(abs(r['difference']) for r in parity),'scope':'core Stereo/Base 5paths; extras present='+str((HERE/'extras_frame_metrics.csv').exists())}
(HERE/'regenerated_summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
