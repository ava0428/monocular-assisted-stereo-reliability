"""Fit all predeclared tau levels to regenerated CAL scores only."""
from pathlib import Path
import sys,json,time,hashlib
import cv2,numpy as np
HERE=Path(__file__).resolve().parent;ROOT=next(p for p in HERE.parents if (p/'src/models/risk_predictor.py').exists());OUT=HERE.parents[2]/'compute_round2';sys.path.insert(0,str(ROOT))
from src.taskspace.booster_calibration import frame_quotas,sampled_operands
from src.taskspace.calibration import fit_c1d
def load(p):return json.loads(p.read_text(encoding='utf-8'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
protocol=load(HERE/'full_protocol.json');scenes=load(ROOT/'manifests/v4_booster_cal_frames_125.json')['scenes'];inp=ROOT/'outputs/jise_mono_ablation_booster_cal_inputs_20261005';records={(r['scene'],r['frame']):r for r in load(inp/'manifest.json')['records']}
keys=[(f,s) for f in protocol['families'] for s in protocol['seeds']];samples={k:[] for k in keys};ids=[];t=time.perf_counter();frame_provenance=[]
for si,scene in enumerate(scenes):
    name=scene['scene'];gp=ROOT/'outputs/v4_booster_cal_range_116'/name/'disp_00.npy';assert sha(gp)==scene['shared']['disp_00.npy']['sha256'];gt=np.load(gp,mmap_mode='r');quota=frame_quotas([f['frame'] for f in scene['frames']]);target=(gt.shape[1],gt.shape[0])
    for f in scene['frames']:
        frame=f['frame'];r=records[name,frame];ip=inp/r['input_npz'];assert sha(ip)==r['input_sha256']
        with np.load(ip) as z:d=z['stereo_disparity']
        stem=name+'_'+frame;first=OUT/'CAL/raw_scores'/('r1_seed'+str(protocol['seeds'][0]))/(stem+'.npy');raw=np.load(first)
        errors,base,ix=sampled_operands(gt,d,raw,quota[frame]);ids.extend([name]*len(ix))
        for key in keys:
            path=OUT/'CAL/raw_scores'/(key[0]+'_seed'+str(key[1]))/(stem+'.npy')
            deadline=time.monotonic()+180
            while not path.with_suffix('.json').exists():
                if time.monotonic()>deadline:raise TimeoutError(str(path))
                time.sleep(.2)
            rr=load(path.with_suffix('.json'));assert sha(path)==rr['score_sha256'] and rr['input_npz_sha256']==r['input_sha256']
            if key==keys[0]:h=base
            else:
                raw=np.asarray(np.load(path),dtype=np.float64);native=cv2.resize(np.maximum(np.expm1(raw),0),target,interpolation=cv2.INTER_LINEAR)*4;h=native.ravel()[ix]
            assert np.isfinite(h).all();samples[key].append((errors,h))
        frame_provenance.append({'scene':name,'frame':frame,'n':len(ix),'input_sha256':r['input_sha256']})
    print('CAL',si+1,len(scenes),name,round(time.perf_counter()-t,1),flush=True)
old={(r['family'],r['seed']):r for r in load(ROOT/'outputs/jise_mono_ablation_cal_eval_joint_20261005/cal_fits.json')['fits']}
result=[];group=np.asarray(ids)
for key in keys:
    errors=np.concatenate([x[0] for x in samples[key]]);h=np.concatenate([x[1] for x in samples[key]]);assert len(errors)==19*8192
    p=OUT/'CAL/sampled_operands'/(key[0]+'_'+str(key[1])+'.npz');p.parent.mkdir(exist_ok=True);np.savez_compressed(p,error=errors,h0=h,scene=group)
    for tau in protocol['tau']:
        fit=fit_c1d(errors,h,tau);q=np.maximum(h+fit.delta,0);r={'family':key[0],'seed':key[1],'tau':tau,'delta':fit.delta,'n':fit.n,'k':fit.k,'CAL_fitted_sample_empirical_coverage':float(np.mean(errors<=q)),'CAL_error_quantiles':np.quantile(errors,[0,.25,.5,.75,.9,.95,1]).tolist(),'CAL_h0_quantiles':np.quantile(h,[0,.25,.5,.75,.9,.95,1]).tolist(),'CAL_q_quantiles':np.quantile(q,[0,.25,.5,.75,.9,.95,1]).tolist(),'scene_sample_coverage':{s:float(np.mean((errors<=q)[group==s])) for s in sorted(set(ids))}}
        if tau==.9:r.update(historical_delta=old[key]['delta'],delta_vs_historical=fit.delta-old[key]['delta'])
        result.append(r)
(HERE/'cal_refit.json').write_text(json.dumps({'classification':'current-code regenerated CAL; historical fit unchanged','tau_fixed_in_protocol':protocol['tau'],'quantile_levels':[0,.25,.5,.75,.9,.95,1.],'samples':'8192 per scene split deterministically among frames; 155648 total','coverage_scope':'fitted CAL sample only, not holdout','rows':result,'frames':frame_provenance,'elapsed_seconds':time.perf_counter()-t},indent=2)+'\n');print('FIT COMPLETE',time.perf_counter()-t,flush=True)
