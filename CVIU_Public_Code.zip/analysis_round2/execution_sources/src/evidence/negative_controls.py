"""Week 4 negative controls — ``N-random`` and ``N-shuffle`` (V3 §14.5, protocol §11).

Both keep the **same parameter budget, training protocol and seeds** as the
variant they control. Neither may be omitted: per V3 §39, if either reproduces an
R2-like gain, the gain is attributed to dataset statistics, parameter expansion
or non-corresponding features rather than a genuine mono-stereo relation.

``N-random``
    ``R1(11)`` plus 8 fixed random channels of the same shape and
    dimensionality as ``mono5 + disagreement3``, generated once from the stated
    seed, persisted and never resampled or trained.

``N-shuffle``
    ``R1(11)`` correct; the mono map is replaced by another sample's under a
    deterministic in-batch permutation, and ``mono5 + disagreement3`` are
    **recomputed** from the shuffled raw map (see
    :func:`src.evidence.mono_evidence.shuffle_mono_in_batch`) — never by
    permuting precomputed feature tensors.

Neither seed nor permutation rule may read a metric. Both are constants here so
the choice is auditable rather than made per run.
"""
from __future__ import annotations

from typing import Final

import torch

#: ``N-random`` generation seed. Chosen once, at implementation time; the
#: protocol requires only that it is fixed and recorded, never that it is tuned.
N_RANDOM_SEED: Final[int] = 20260913

#: ``N-shuffle`` permutation seed.
N_SHUFFLE_SEED: Final[int] = 20260914

#: ``N-random`` supplies exactly the dimensionality of ``mono5 + disagreement3``.
N_RANDOM_CHANNELS: Final[int] = 8


def random_control_channels(
    shape: tuple[int, ...],
    *,
    seed: int = N_RANDOM_SEED,
    device: torch.device | str = "cpu",
    dtype: torch.dtype = torch.float32,
) -> torch.Tensor:
    """The fixed ``N-random`` channels for one spatial shape.

    Deterministic in ``(shape, seed)`` alone: the same shape always yields the
    same tensor, so nothing is resampled between runs or across epochs.
    """
    if len(shape) != 2:
        raise ValueError(f"expected a (H, W) shape, got {shape}")
    generator = torch.Generator(device="cpu").manual_seed(int(seed))
    # U(-1, 1): bounded like the real mono/disagreement channels, so the control
    # differs in *correspondence* rather than in scale or range.
    values = torch.rand(N_RANDOM_CHANNELS, *shape, generator=generator, dtype=torch.float32) * 2.0 - 1.0
    return values.to(device=device, dtype=dtype)


def build_donor_permutation(
    sample_ids,
    group_of,
    *,
    seed: int = N_SHUFFLE_SEED,
    max_attempts: int = 10_000,
) -> dict[str, str]:
    """Population-level donor mapping for the target-domain ``N-shuffle`` control.

    Frozen by ``PROTOCOL_CORRECTION_WEEK4_008``. The frozen control replaces a
    sample's mono map with *another sample's* inside a training batch, which the
    Middlebury development scenes cannot supply: they are evaluated per scene and
    have pairwise different resolutions. This builds the same "not the
    corresponding mono map" relation at population level instead.

    Deterministic in ``(sorted sample ids, seed)``, reusing the frozen
    ``shuffle_permutation`` RNG rule (``manual_seed(seed + n)``). Constraints, with
    deterministic continuation on the same RNG stream until they hold:

    * no fixed point — ``donor != target``;
    * no same-group donation, so a scene's exposure or variant never donates to
      itself.

    Donor choice consults nothing but the ids and their groups: no image content,
    label, error, metric or observed model result.
    """
    order = sorted(sample_ids)
    size = len(order)
    if size < 2:
        raise ValueError("N-shuffle needs at least 2 samples in the population")
    generator = torch.Generator().manual_seed(int(seed) + size)
    for _ in range(max_attempts):
        permutation = torch.randperm(size, generator=generator)
        mapping = {order[index]: order[int(permutation[index])] for index in range(size)}
        if all(mapping[name] != name and group_of[mapping[name]] != group_of[name] for name in order):
            return mapping
    raise RuntimeError(
        f"no donor permutation satisfying the constraints after {max_attempts} attempts"
    )


def transport_mono_to_target(donor_mono: torch.Tensor, target_shape: tuple[int, int]) -> torch.Tensor:
    """Resize a donor raw mono map to the target ``HxW`` — the only permitted transport.

    Frozen by ``PROTOCOL_CORRECTION_WEEK4_008``: bilinear with
    ``align_corners=False``. Deliberately **not** the DA-V2 adapter's resize,
    which uses ``align_corners=True`` and is therefore a different operation.

    Nothing else may be applied: no GT-aware resize, no disparity/error
    alignment, no mean-variance or percentile matching, no target normalization,
    no donor cropping, and no adjustment from the target stereo prediction.
    """
    if donor_mono.dim() == 2:
        donor_mono = donor_mono.unsqueeze(0)
    if donor_mono.dim() != 3 or donor_mono.shape[0] != 1:
        raise ValueError(f"expected a single-channel mono map, got {tuple(donor_mono.shape)}")
    resized = torch.nn.functional.interpolate(
        donor_mono.unsqueeze(0).float(),
        size=tuple(int(v) for v in target_shape),
        mode="bilinear",
        align_corners=False,
    )
    return resized[0]


def shuffle_permutation(batch_size: int, *, seed: int = N_SHUFFLE_SEED) -> torch.Tensor:
    """The deterministic in-batch permutation for ``N-shuffle``.

    Deterministic in ``(batch_size, seed)``: every batch of a given size gets the
    same permutation, so the control is reproducible and is never the identity.
    """
    if batch_size < 2:
        raise ValueError("N-shuffle needs a batch of at least 2 samples")
    generator = torch.Generator().manual_seed(int(seed) + int(batch_size))
    permutation = torch.randperm(batch_size, generator=generator)
    if bool((permutation == torch.arange(batch_size)).all()):
        permutation = torch.roll(permutation, shifts=1)
    return permutation
