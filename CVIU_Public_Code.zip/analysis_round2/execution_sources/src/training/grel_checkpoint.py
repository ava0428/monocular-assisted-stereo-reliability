"""Grel-direct checkpoint writer and loader.

The Week 6 audit phase could only *refuse* ``.pt``/``.pth`` writes. That is a
pre-authorization protection, not a production behaviour: once training is
authorized, checkpoints must be written — safely.

Safety here means: authorized-only, run-directory-scoped, temp-file plus fsync
plus atomic publish, refuse-overwrite-on-different-content, digest verification
*before* ``torch.load``, and a strict state-dict load. An interrupted run leaves
no selected-checkpoint record, and a frozen manifest may only be assembled after
all three seeds have completed.
"""
from __future__ import annotations

import hashlib
import os
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping, Sequence

import torch

from src.calibration.lockfile import RunLease
from src.taskspace.guards import ExecutionRefused, require_training_authorised
from src.training.grel_binding import GrelRunBinding

CHECKPOINT_SCHEMA = "week6-grel-direct-checkpoint-1"
MANIFEST_SCHEMA = "week6-grel-direct-checkpoints-1"

#: A run must be complete before it can contribute a selected checkpoint.
STATUS_RUNNING = "RUNNING"
STATUS_COMPLETE = "COMPLETE"
STATUS_FAILED = "FAILED"


class CheckpointRefused(RuntimeError):
    """A checkpoint write or load was refused."""


class IncompleteRun(CheckpointRefused):
    """An incomplete run may not produce a selected-checkpoint record."""


def assert_write_authorised(authorised: bool | None = None) -> None:
    """Unauthorized checkouts may not write a checkpoint at all."""
    require_training_authorised(authorised)


def assert_run_directory(target: Path, run_directory: Path) -> None:
    """A checkpoint may only be written inside the current exclusive run directory."""
    resolved = Path(target).resolve()
    run = Path(run_directory).resolve()
    if run not in resolved.parents and resolved != run:
        raise CheckpointRefused(
            f"{resolved} is outside the exclusive run directory {run}"
        )
    if resolved.suffix not in (".pt", ".pth"):
        raise CheckpointRefused(f"{resolved} is not a checkpoint file")


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _atomic_publish(payload: bytes, target: Path) -> str:
    """Temp file in the same directory, fsync, then an atomic replace."""
    target.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temp_name = tempfile.mkstemp(dir=target.parent, suffix=".tmp")
    temp = Path(temp_name)
    try:
        with os.fdopen(descriptor, "wb") as handle:
            handle.write(payload)
            handle.flush()
            os.fsync(handle.fileno())
        if target.exists() and _sha256_file(target) != hashlib.sha256(payload).hexdigest():
            raise CheckpointRefused(
                f"{target} already exists with different content; refusing to overwrite"
            )
        os.replace(temp, target)
    finally:
        if temp.exists():
            temp.unlink(missing_ok=True)
    return _sha256_file(target)


def save_checkpoint(
    *,
    run_directory: Path,
    step: int,
    seed: int,
    model: torch.nn.Module,
    optimizer: torch.optim.Optimizer,
    scheduler: Any,
    metrics: Mapping[str, float],
    binding: GrelRunBinding,
    extra_state: Mapping[str, Any] | None = None,
    authorised: bool | None = None,
    lease: RunLease | None = None,
) -> tuple[Path, str]:
    """Write one checkpoint atomically and return ``(path, sha256)``."""
    assert_write_authorised(authorised)
    if lease is None:
        raise CheckpointRefused("authorized checkpoint write requires the held run lease")
    lease.verify()
    if lease.path.parent.resolve() != Path(run_directory).resolve():
        raise CheckpointRefused(
            f"lease belongs to {lease.path.parent}, not run directory {run_directory}"
        )
    target = Path(run_directory) / f"grel_direct_seed{seed}_step{step}.pt"
    assert_run_directory(target, run_directory)

    payload = {
        "schema": CHECKPOINT_SCHEMA,
        "step": int(step),
        "seed": int(seed),
        "model": model.state_dict(),
        "optimizer": optimizer.state_dict(),
        "scheduler": scheduler.state_dict() if scheduler is not None else None,
        "metrics": {k: float(v) for k, v in metrics.items()},
        "binding": binding.as_dict(),
        "extra_state": dict(extra_state or {}),
    }
    import io

    buffer = io.BytesIO()
    torch.save(payload, buffer)
    digest = _atomic_publish(buffer.getvalue(), target)
    return target, digest


def load_checkpoint(
    path: Path,
    *,
    expected_sha256: str,
    model: torch.nn.Module,
    optimizer: torch.optim.Optimizer | None = None,
    scheduler: Any = None,
    map_location: str = "cpu",
) -> dict:
    """Verify the digest FIRST, then ``torch.load``, then a strict state-dict load."""
    path = Path(path)
    if not path.exists():
        raise CheckpointRefused(f"{path} does not exist")
    actual = _sha256_file(path)
    if actual != expected_sha256:
        raise CheckpointRefused(
            f"{path}: sha256 {actual} != expected {expected_sha256}; refusing to load"
        )
    payload = torch.load(path, map_location=map_location, weights_only=False)
    if payload.get("schema") != CHECKPOINT_SCHEMA:
        raise CheckpointRefused(f"{path}: unknown checkpoint schema {payload.get('schema')!r}")

    model.load_state_dict(payload["model"], strict=True)  # strict: no silent partial load
    if optimizer is not None and payload.get("optimizer") is not None:
        optimizer.load_state_dict(payload["optimizer"])
    if scheduler is not None and payload.get("scheduler") is not None:
        scheduler.load_state_dict(payload["scheduler"])
    return payload


@dataclass
class RunState:
    """The run's own completion record. A partial run never yields a selection."""

    run_id: str
    status: str = STATUS_RUNNING
    selected_step: int | None = None
    selected_sha256: str | None = None
    interruption_history: tuple[str, ...] = ()

    def mark_complete(self, step: int, sha256: str) -> None:
        if self.status != STATUS_RUNNING:
            raise CheckpointRefused(f"run {self.run_id} is {self.status}, not RUNNING")
        self.status = STATUS_COMPLETE
        self.selected_step = int(step)
        self.selected_sha256 = sha256

    def selected_record(self) -> Mapping[str, object]:
        """A selected-checkpoint record exists only for a COMPLETE run."""
        if self.status != STATUS_COMPLETE:
            raise IncompleteRun(
                f"run {self.run_id} is {self.status}; an incomplete run produces no "
                f"selected-checkpoint record"
            )
        return {"run_id": self.run_id, "step": self.selected_step, "sha256": self.selected_sha256}


def assemble_frozen_manifest(states: Sequence[RunState]) -> Mapping[str, object]:
    """A frozen checkpoint manifest may only be assembled after ALL seeds complete."""
    incomplete = sorted(s.run_id for s in states if s.status != STATUS_COMPLETE)
    if incomplete:
        raise IncompleteRun(
            f"refusing to assemble a frozen manifest: run(s) {incomplete} are not COMPLETE"
        )
    return {
        "schema": MANIFEST_SCHEMA,
        "variant": "grel_direct",
        "seeds": [s.selected_record() for s in states],
    }


def assert_manifest_not_committed(manifest_path: Path, repo_root: Path) -> None:
    """The training driver must not rewrite a committed manifest in place."""
    relative = Path(manifest_path).resolve().relative_to(Path(repo_root).resolve())
    committed = (Path(repo_root) / "manifests").resolve()
    if committed in Path(manifest_path).resolve().parents:
        raise CheckpointRefused(
            f"{relative} lives under the committed manifests/ directory; the training driver "
            f"writes run-local artefacts only"
        )


def assert_authorised_for_write(target: Path, authorised: bool) -> None:
    """Convenience guard used by tests: unauthorized means no bytes on disk."""
    if not authorised:
        if Path(target).exists():
            raise ExecutionRefused(f"{target} exists although training is unauthorized")
        raise ExecutionRefused("training is not authorized; no checkpoint may be written")
