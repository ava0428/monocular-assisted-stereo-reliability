"""Week 3 source-domain training utilities."""
