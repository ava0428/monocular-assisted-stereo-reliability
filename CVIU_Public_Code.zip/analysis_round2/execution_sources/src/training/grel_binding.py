"""Immutable RunBinding and the source-training authorization chain.

Frozen by specification body §17 and the freeze file §7.

A binding is per seed and immutable. Two properties are load-bearing:

* the **authorization commit must be clean HEAD**, and the implementation commit
  must be its **ancestor** — so the run cannot be launched from a working tree
  that carries uncommitted edits;
* the **diff of the authorization commit is an exact set** — the arming commit may
  touch the authorization document and the training config and nothing else.

Resume accepts a run only when the binding digest is *identical*, so a resumed run
cannot silently continue under different code, data or configuration.
"""
from __future__ import annotations

import hashlib
import json
from dataclasses import asdict, dataclass, field
from typing import Mapping, Sequence

from src.taskspace.guards import ExecutionRefused, refuse_globs_and_fallbacks
from src.taskspace.spec import (
    FROZEN_SPEC_SHA256,
    R2_GATE_SEEDS,
    SPECIFICATION_BODY_SHA256,
)


class BindingViolation(RuntimeError):
    """A binding field is missing, stale, or inconsistent."""


BINDING_SCHEMA = "week6-grel-direct-run-binding-1"

#: The exact set of paths the authorization commit may touch.
AUTHORIZATION_ALLOWED_PATHS = frozenset(
    {
        "docs/WEEK6_GREL_TRAINING_AUTHORIZATION_032.md",
        "configs/experiments/week6_grel_training.yaml",
    }
)

#: A placeholder must never reach a production binding.
UNSET_SENTINELS = ("unset", "", "UNSET", "none", "TBD", None)


@dataclass(frozen=True)
class GrelRunBinding:
    """Everything that fixes what a single seed's training run is."""

    seed: int
    implementation_commit: str
    authorization_commit: str
    freeze_blob_sha256: str
    amendment_body_sha256: str
    training_config_sha256: str
    source_integrity_manifest_git_blob_sha256: str
    raw_train_digest: str
    raw_validation_digest: str
    stereo_train_digest: str
    stereo_validation_digest: str
    mono_train_digest: str
    mono_validation_digest: str
    normalization_digest: str
    train_manifest_digest: str
    validation_manifest_digest: str
    skipped_sample_set_digest: str
    backbone_checkpoint_digest: str
    source_split_digest: str
    input_schema_digest: str
    architecture_digest: str
    schema: str = BINDING_SCHEMA

    def __post_init__(self) -> None:
        if self.seed not in R2_GATE_SEEDS:
            raise BindingViolation(f"seed {self.seed} is not one of the frozen {R2_GATE_SEEDS}")
        for name, value in asdict(self).items():
            if name == "schema":
                continue
            if value in UNSET_SENTINELS:
                raise BindingViolation(
                    f"{name} is unset ({value!r}); an unset placeholder may never enter a "
                    f"production binding"
                )
            if name.endswith("sha256") or name.endswith("digest"):
                if not isinstance(value, str) or len(value) != 64:
                    raise BindingViolation(f"{name} must be a 64-hex digest, got {value!r}")
        if self.freeze_blob_sha256 != FROZEN_SPEC_SHA256:
            raise BindingViolation("freeze_blob_sha256 does not match the effective freeze")
        if self.amendment_body_sha256 != SPECIFICATION_BODY_SHA256:
            raise BindingViolation("amendment_body_sha256 does not match the frozen body")
        from src.integrity.source_integrity import LEGACY_STEREO_DIGEST

        active = {
            self.raw_train_digest,
            self.raw_validation_digest,
            self.stereo_train_digest,
            self.stereo_validation_digest,
            self.mono_train_digest,
            self.mono_validation_digest,
        }
        if LEGACY_STEREO_DIGEST in active:
            raise BindingViolation(
                "the UNRECORDED legacy stereo-cache digest may not be an active binding identity"
            )

    def digest(self) -> str:
        payload = json.dumps(asdict(self), sort_keys=True, separators=(",", ":"))
        return hashlib.sha256(payload.encode("utf-8")).hexdigest()

    def as_dict(self) -> Mapping[str, object]:
        return {**asdict(self), "binding_digest": self.digest()}


def validate_authorization(
    *,
    authorization_commit: str,
    implementation_commit: str,
    head_is_clean: bool,
    changed_paths: Sequence[str],
    is_ancestor: bool,
    run_id: str,
) -> None:
    """The authorization chain, checked exactly as the freeze writes it."""
    if not head_is_clean:
        raise ExecutionRefused(
            "the authorization commit must be clean HEAD; the working tree carries changes"
        )
    if not is_ancestor:
        raise ExecutionRefused(
            f"implementation commit {implementation_commit} is not an ancestor of the "
            f"authorization commit {authorization_commit}"
        )
    if authorization_commit == implementation_commit:
        raise ExecutionRefused(
            "the authorization commit must differ from the implementation commit"
        )
    if run_id in (authorization_commit, implementation_commit):
        raise ExecutionRefused(
            "a run id may not be the authorization or implementation commit; the id would "
            "then be self-referential"
        )
    if authorization_commit in UNSET_SENTINELS:
        raise BindingViolation("authorization_commit is unset")

    extras = sorted(set(changed_paths) - AUTHORIZATION_ALLOWED_PATHS)
    if extras:
        raise ExecutionRefused(
            f"the authorization commit touches path(s) outside the exact allowed set: {extras}"
        )
    if not changed_paths:
        raise ExecutionRefused("the authorization commit touches nothing")


def bindings_from_authorization_blobs(
    *,
    authorization_commit: str,
    implementation_commit: str,
    config_blob_sha256: str,
    source_manifest_blob_sha256: str,
    source_manifest: Mapping[str, object],
    input_schema_digest: str,
    architecture_digest: str,
) -> tuple[GrelRunBinding, ...]:
    """Construct the three bindings from Git-blob identities.

    The source manifest is already parsed from the **implementation commit's
    blob** by the git-driven authorization gate. No working-tree bytes, absolute
    path, self-reported legacy digest, or run id enters this constructor.
    """
    roles = source_manifest["source_integrity"]["roles"]  # type: ignore[index]
    normalization = source_manifest["normalization"]  # type: ignore[index]
    skipped = source_manifest["skipped_validation"]  # type: ignore[index]
    cache_provenance = source_manifest["cache_provenance"]  # type: ignore[index]
    split_digest = str(source_manifest["split_digest"])

    common = dict(
        implementation_commit=implementation_commit,
        authorization_commit=authorization_commit,
        freeze_blob_sha256=FROZEN_SPEC_SHA256,
        amendment_body_sha256=SPECIFICATION_BODY_SHA256,
        training_config_sha256=config_blob_sha256,
        source_integrity_manifest_git_blob_sha256=source_manifest_blob_sha256,
        raw_train_digest=str(roles["SCENEFLOW_RAW_TRAIN"]["aggregate_sha256"]),
        raw_validation_digest=str(roles["SCENEFLOW_RAW_VALIDATION"]["aggregate_sha256"]),
        stereo_train_digest=str(roles["SCENEFLOW_STEREO_CACHE_TRAIN"]["aggregate_sha256"]),
        stereo_validation_digest=str(
            roles["SCENEFLOW_STEREO_CACHE_VALIDATION"]["aggregate_sha256"]
        ),
        mono_train_digest=str(roles["SCENEFLOW_MONO_CACHE_TRAIN"]["aggregate_sha256"]),
        mono_validation_digest=str(
            roles["SCENEFLOW_MONO_CACHE_VALIDATION"]["aggregate_sha256"]
        ),
        normalization_digest=str(normalization["semantic_digest"]),
        train_manifest_digest=str(source_manifest["train_manifest_digest"]),
        validation_manifest_digest=str(source_manifest["validation_manifest_digest"]),
        skipped_sample_set_digest=str(skipped["skipped_sample_set_digest"]),
        backbone_checkpoint_digest=str(cache_provenance["raft_checkpoint_sha256"]),
        source_split_digest=split_digest,
        input_schema_digest=input_schema_digest,
        architecture_digest=architecture_digest,
    )
    bindings = tuple(GrelRunBinding(seed=seed, **common) for seed in R2_GATE_SEEDS)
    assert_per_seed_isolation(bindings)
    return bindings


def run_id_for(binding: GrelRunBinding) -> str:
    """Derived only after the binding is complete; it never enters its own input."""
    return f"week6-grel-{binding.seed}-{binding.digest()[:16]}"


def assert_per_seed_isolation(bindings: Sequence[GrelRunBinding]) -> None:
    """Each seed gets its own run. No optimizer, scheduler or checkpoint is shared."""
    seeds = [b.seed for b in bindings]
    if len(seeds) != len(set(seeds)):
        raise BindingViolation(f"duplicate seed across runs: {sorted(seeds)}")
    digests = [b.digest() for b in bindings]
    if len(digests) != len(set(digests)):
        raise BindingViolation(
            "two seeds share a binding digest; per-seed runs must be independent"
        )


def assert_resume_binding_matches(stored: Mapping[str, object], incoming: GrelRunBinding) -> None:
    """A resume is accepted only under an IDENTICAL binding."""
    incoming_dict = incoming.as_dict()
    for key, value in incoming_dict.items():
        if key == "binding_digest":
            continue
        if stored.get(key) != value:
            raise BindingViolation(
                f"resume refused: {key} differs ({stored.get(key)!r} != {value!r}). A resumed "
                f"run must continue under an identical binding."
            )
    if stored.get("binding_digest") != incoming_dict["binding_digest"]:
        raise BindingViolation("resume refused: binding digest differs")


def resolve_seed(checkpoint_selector: str, seed: int) -> int:
    """Exact seed lookup only. No glob, latest, best-seed or fallback."""
    refuse_globs_and_fallbacks(checkpoint_selector)
    if seed not in R2_GATE_SEEDS:
        raise BindingViolation(f"seed {seed} is not frozen")
    return seed


@dataclass
class RunRecord:
    run_id: str
    binding: GrelRunBinding
    history: list = field(default_factory=list)

    def as_dict(self) -> Mapping[str, object]:
        return {
            "run_id": self.run_id,
            "binding": self.binding.as_dict(),
            "history": list(self.history),
        }
