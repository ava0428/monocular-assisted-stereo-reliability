"""Week 6 task-space implementation (PROTOCOL_AMENDMENT_WEEK6_021).

Synthetic-fixture only in this phase. No real array is read, no model is run and
no task-space number is produced.
"""
