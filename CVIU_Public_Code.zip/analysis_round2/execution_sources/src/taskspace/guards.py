"""Hard guards for Week 6.

Every guard raises. None is a warning. Each is exercised by a synthetic test.

The three execution gates are separate: training, Middlebury task-space
execution and ETH3D access each need their own authorisation, and no entry point
may implylicitly invoke another phase.
"""
from __future__ import annotations

import os
from pathlib import Path
from typing import Iterable, Mapping, Sequence

from src.taskspace.spec import (
    C1Z_GATE_ROLE,
    CROSS_DATASET_POOLING,
    ETH3D_ACCESS_AUTHORISED,
    ETH3D_ENV_KEYS,
    ETH3D_STATUS,
    MIDDLEBURY_TASK_EXECUTION_AUTHORISED,
    TRAINING_AUTHORISED,
    UNRESOLVED,
)

SPEC_BLOCKER = "WEEK6_IMPLEMENTATION_SPEC_BLOCKER"


class Eth3DAccessRefused(RuntimeError):
    """ETH3D is the locked external test. Zero accesses."""


class SpecBlocker(RuntimeError):
    """A quantity that would change a result is undefined in the frozen text."""


class ExecutionRefused(RuntimeError):
    """An execution gate is closed."""


class GateIsolationViolation(RuntimeError):
    """A quantity that must never reach Checkpoint 4 reached it."""


def refuse_eth3d(environ: Mapping[str, str] | None = None) -> None:
    """First-phase refusal: any ETH3D configuration refuses outright."""
    env = os.environ if environ is None else environ
    for key in ETH3D_ENV_KEYS:
        if env.get(key):
            raise Eth3DAccessRefused(
                f"{key} is set. V3 §22.4 keeps ETH3D as {ETH3D_STATUS}, and "
                f"ETH3D_ACCESS_AUTHORISED = {ETH3D_ACCESS_AUTHORISED}. No Week 6 step may "
                f"read it."
            )


def refuse_eth3d_path(path: Path | str) -> None:
    """Refuse any path whose components name the locked external test."""
    parts = {part.lower() for part in Path(path).parts}
    for banned in ("eth3d", "eth_3d", "eth3d_root"):
        if banned in parts or any(banned in part for part in parts):
            raise Eth3DAccessRefused(
                f"path {path!r} names the locked external test; access is forbidden"
            )


def require_training_authorised(flag: bool | None = None) -> None:
    authorised = TRAINING_AUTHORISED if flag is None else flag
    if not authorised:
        raise ExecutionRefused(
            "training_authorised is false. Grel-direct training needs its own explicit "
            "authorisation; the protocol freeze is not one."
        )


def require_middlebury_task_execution_authorised(flag: bool | None = None) -> None:
    authorised = MIDDLEBURY_TASK_EXECUTION_AUTHORISED if flag is None else flag
    if not authorised:
        raise ExecutionRefused(
            "middlebury_task_execution_authorised is false. Middlebury task-space execution "
            "needs its own explicit authorisation."
        )


def require_eth3d_access_authorised(flag: bool | None = None) -> None:
    authorised = ETH3D_ACCESS_AUTHORISED if flag is None else flag
    if not authorised:
        raise Eth3DAccessRefused(
            "eth3d_access_authorised is false. ETH3D access needs its own explicit "
            "authorisation."
        )


def assert_resolved(values: Mapping[str, object]) -> None:
    """Refuse the sentinel in any field that would change a result."""
    unresolved = sorted(k for k, v in values.items() if v is None or v == UNRESOLVED)
    if unresolved:
        raise SpecBlocker(f"{SPEC_BLOCKER}: unresolved key(s) {unresolved}")


def refuse_pooled_datasets(labels: Sequence[str]) -> None:
    """The two datasets are always reported separately and never pooled."""
    if len(set(labels)) > 1:
        raise GateIsolationViolation(
            f"{CROSS_DATASET_POOLING}: refusing to pool {sorted(set(labels))}"
        )


def assert_c1z_not_a_gate_input(participates: bool) -> None:
    if participates:
        raise GateIsolationViolation(
            "C1_z is a conditional calibration diagnostic; it is never a Checkpoint 4 input"
        )
    if C1Z_GATE_ROLE:
        raise AssertionError("the frozen spec says C1_z is not a gate input; code disagrees")


def assert_no_result_can_move_a_threshold(
    before: Mapping[str, object], after: Mapping[str, object]
) -> None:
    """A verdict may not change any frozen value."""
    differing = sorted(k for k in set(before) | set(after) if before.get(k) != after.get(k))
    if differing:
        raise GateIsolationViolation(
            f"a verdict must not change frozen value(s): {differing}"
        )


def refuse_globs_and_fallbacks(selector: str) -> None:
    """No glob, no 'latest', no best-seed search, no fallback checkpoint."""
    banned = ("*", "?", "latest", "best_available", "fallback")
    lowered = selector.lower()
    for token in banned:
        if token in lowered:
            raise ExecutionRefused(
                f"checkpoint selection {selector!r} contains {token!r}; glob, latest and "
                f"fallback selection are PROHIBITED. Resolve by exact seed index only."
            )


def assert_seed_is_frozen(seed: int, frozen: Iterable[int]) -> int:
    frozen_set = set(frozen)
    if seed not in frozen_set:
        raise ExecutionRefused(
            f"seed {seed} is not one of the frozen seeds {sorted(frozen_set)}"
        )
    return seed
