"""V3 stereo reliability package."""
