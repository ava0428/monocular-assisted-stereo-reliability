"""Week 5 constants: what V3 fixes, and what the amendment froze on top of it.

``V3_FINAL_RESEARCH_PLAN.md`` does not determine eight quantities that each change
a formal calibration result. The previous phase recorded them as
`PRE-EXECUTION SPECIFICATION BLOCKER`s and stopped. `PROTOCOL_AMENDMENT_WEEK5_010`
closes them, in advance of any Week 5 calibration number, as forward-looking
choices — **not** as details V3 already contained. Both the original text and the
frozen choice are kept below so the record shows the gap was real and was closed
by a decision, not by a derivation.

The refusal path is kept. :data:`UNRESOLVED` still exists, still cannot be
defaulted, and :meth:`CalibrationSpec.from_config` still raises
:class:`SpecBlocked` if any key is reopened without a value.
"""
from __future__ import annotations

import hashlib
import json
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Mapping

CALIBRATION_PROTOCOL = "week5_scene_disjoint_calibration_v1"

#: Identifies the amendment that closed the specification gaps.
WEEK5_AMENDMENT = "PROTOCOL_AMENDMENT_WEEK5_010"

#: Sentinel meaning "no frozen value". Kept so a reopened key fails loudly.
UNRESOLVED = "UNRESOLVED_PRE_EXECUTION_SPECIFICATION_BLOCKER"

# --------------------------------------------------------------------------
# Fixed by V3 — usable as-is, no freedom.
# --------------------------------------------------------------------------

#: Calibration operating points. V3 §27.2 ("目标: 90%, 95%") and §40.
NOMINAL_COVERAGES = (0.90, 0.95)

#: V3 §21's selective-prediction retention grid. A *different object* from the
#: calibration levels above; kept here so the two can never be conflated.
SELECTIVE_COVERAGE_GRID = (1.00, 0.95, 0.90, 0.80, 0.70, 0.50)

#: V3 §27.2: "Coverage Error |Coverage-(1-alpha)|".
COVERAGE_ERROR_DEFINITION = "abs(empirical_coverage - (1 - alpha))"

#: V3 §19.2 writes the calibrated disparity interval as ``[d - q_d, d + q_d]``.
INTERVAL_WIDTH_DEFINITION = "upper_endpoint - lower_endpoint = 2 * q_d  (V3 19.2)"

#: V3 §18: split unit at least scene/image; pixel-random splits forbidden.
SPLIT_UNIT = "scene"
PIXEL_RANDOM_SPLIT = "PROHIBITED"

#: V3 §18: fitting on target ground truth makes a result *target-calibrated*.
TARGET_CALIBRATED_LABEL = "target-calibrated"
ZERO_SHOT_LABEL_FORBIDDEN_WHEN_FITTED = True

#: Week 5 calibrates in disparity space; task space is Week 6 (V3 §19–§20, §43).
CALIBRATION_SPACE = "disparity"

#: V3 §22.4 / §43 Week 7: ETH3D is the locked external test.
ETH3D_STATUS = "LOCKED_EXTERNAL_TEST"
ETH3D_ACCESS_DURING_WEEK5 = "PROHIBITED"

#: Runtime reporting fields; V3 fixes the first five and sets **no** R2 gate (§28).
RUNTIME_FIELDS = (
    "T_stereo",
    "T_mono",
    "T_features",
    "T_predictor",
    "T_calibration",
    "T_total",
    "peak_vram",
)
RUNTIME_SCENARIOS = ("cached_prior", "online")
RUNTIME_GATE = None

#: The three source-frozen R2-gate training seeds (V3 §31).
R2_GATE_SEEDS = (20260910, 20260911, 20260912)
SEED_SELECTION = "PROHIBITED"
TARGET_GUIDED_ENSEMBLE = "PROHIBITED"
POOL_SEEDS_INTO_ONE_CALIBRATOR = "PROHIBITED"

# --------------------------------------------------------------------------
# Frozen by PROTOCOL_AMENDMENT_WEEK5_010 — forward-looking choices
# --------------------------------------------------------------------------

#: C0 half-width rule: undo the ``log1p`` training target with ``expm1``.
C0_RADIUS_RULE = "maximum(expm1(s), 0)"

#: C1 family and interval mode.
C1_FAMILY = "split_conformal_additive_radius"
C1_INTERVAL_MODE = "symmetric_additive_radius_correction"

#: Explicit order-statistic quantile with the ``n + 1`` finite-sample correction.
C1_QUANTILE_RULE = "explicit_order_statistic_no_interpolation"
C1_FINITE_SAMPLE_CORRECTION = "ceil((n+1)*(1-alpha))"
C1_FIT_UNIT = "pooled_valid_cal_pixels_within_seed_and_fold"

#: The single frozen calibration ablation.
C1_ABLATION = "C1-constant"
C1_ABLATION_DEFINITION = "marginal empirical-residual split-conformal interval"

#: Primary aggregation: unweighted scene macro over the 15 unique eval scenes.
PRIMARY_AGGREGATION = "scene_macro"
SUPPLEMENTARY_AGGREGATION = "pixel_micro"
DESCRIPTIVE_AGGREGATION = "fold_macro"

#: Checkpoint 3 (V3 §40, thresholds frozen by the amendment).
CHECKPOINT3_NOMINAL_COVERAGES = (0.90, 0.95)
CHECKPOINT3_ABSOLUTE_TOLERANCE = 0.03
CHECKPOINT3_OUTCOMES = ("PASS", "FAIL")
CROSS_SEED_STD_DDOF = 1

#: Metric families C1 must leave exactly unchanged (C3.3).
WIDTH_ONLY_PARITY_FIELDS = (
    "disparity_prediction_sha256",
    "valid_mask_sha256",
    "epe",
    "bad2_rate",
    "raw_risk_sha256",
    "aurc",
    "ause",
)

#: Labels that may never describe a Week 5 result.
RESULT_LABEL = "CROSS_FITTED_DEVELOPMENT_EVIDENCE"
FORBIDDEN_LABELS = ("external", "untouched", "independent validation", "held-out", "zero-shot")


@dataclass(frozen=True)
class FrozenChoice:
    """One specification gap, the V3 text that left it open, and its resolution."""

    key: str
    governing_text: str
    source: str
    why_it_changes_a_result: str
    frozen_value: str
    rationale: str
    frozen_by: str = WEEK5_AMENDMENT

    def as_dict(self) -> dict[str, str]:
        return asdict(self)


FROZEN_CHOICES: tuple[FrozenChoice, ...] = (
    FrozenChoice(
        key="c1_family",
        governing_text=(
            "C1: Scene-disjoint empirical calibration. 候选: isotonic; split-quantile; "
            "empirical residual calibration."
        ),
        source="V3 §17",
        why_it_changes_a_result=(
            "V3 names three candidate families and designates no primary. They do not produce "
            "the same interval: a score-conditional family varies the width per pixel, a "
            "marginal one does not."
        ),
        frozen_value=C1_FAMILY,
        rationale=(
            "An additive split-conformal radius keeps the C0 radius the predictor already "
            "implies and corrects it by one conformal offset, so the comparison isolates the "
            "correction rather than replacing the score. Distribution-free coverage is NOT "
            "claimed (V3 §17 declines it), because the pixels are spatially correlated and the "
            "15 scenes are not exchangeable."
        ),
    ),
    FrozenChoice(
        key="c1_interval_mode",
        governing_text="候选: isotonic; split-quantile; empirical residual calibration.",
        source="V3 §17",
        why_it_changes_a_result=(
            "Whether the half-width is a function of the raw score is not stated; coverage and "
            "mean width both move."
        ),
        frozen_value=C1_INTERVAL_MODE,
        rationale=(
            "Symmetric and additive in the C0 radius: h1 = max(0, h0 + delta_alpha). The "
            "per-pixel adaptation of the R2 score is retained through h0 instead of being "
            "discarded by a constant width."
        ),
    ),
    FrozenChoice(
        key="c1_quantile_rule",
        governing_text="Empirical Coverage / Coverage Error / Mean Interval Width / Sharpness",
        source="V3 §27.2",
        why_it_changes_a_result=(
            "V3 fixes the metric, not the interpolation; 'linear' and 'inverted_cdf' differ by "
            "up to one order statistic, a measurable coverage difference at 15 scenes."
        ),
        frozen_value=C1_QUANTILE_RULE,
        rationale=(
            "An explicit 1-based order statistic, `sorted(a)[k-1]`. No linear interpolation and "
            "no library quantile whose default semantics may change across versions."
        ),
    ),
    FrozenChoice(
        key="c1_finite_sample_correction",
        governing_text="MVT 不强制宣称 conformal distribution-free guarantee.",
        source="V3 §17",
        why_it_changes_a_result=(
            "V3 declines to require a conformal guarantee without saying whether the "
            "finite-sample inflation is applied. It changes the width."
        ),
        frozen_value=C1_FINITE_SAMPLE_CORRECTION,
        rationale=(
            "k = ceil((n+1)*(1-alpha)), the standard split-conformal rank. k > n is a hard "
            "failure rather than a silent cap to n: an uncertifiable level is reported, not "
            "hidden. No guarantee is asserted on top of it."
        ),
    ),
    FrozenChoice(
        key="c1_fit_unit",
        governing_text="严禁: 把同一张图的像素随机拆到 calibration 和 test。划分单位至少为 scene/image。",
        source="V3 §18",
        why_it_changes_a_result=(
            "§18 fixes the *split* unit, not the *fit* unit. Pooling cal-scene pixels weights "
            "a large scene more than a small one."
        ),
        frozen_value=C1_FIT_UNIT,
        rationale=(
            "Pooled valid calibration pixels within one (seed, fold). The confound is disclosed "
            "rather than removed: scenes with more valid pixels contribute more calibration "
            "scores. Per-scene valid pixel counts are recorded with every fit."
        ),
    ),
    FrozenChoice(
        key="c0_interval_rule",
        governing_text="C0: Raw score / raw error estimate，不校准。",
        source="V3 §17",
        why_it_changes_a_result=(
            "C0 is defined as the raw uncalibrated score, but V3 never says how a raw score "
            "becomes an interval. Any rule sets the C0 half of the comparison."
        ),
        frozen_value=C0_RADIUS_RULE,
        rationale=(
            "The predictor is trained on log1p(|error|), so expm1 is the unit-restoring inverse "
            "and the radius is already in disparity pixels. Negative inverses are set to zero; "
            "the raw score is not clipped, and |s| is never used."
        ),
    ),
    FrozenChoice(
        key="aggregation_unit",
        governing_text="报告均值与 CI。",
        source="V3 §22.3",
        why_it_changes_a_result=(
            "Coverage, coverage error and mean width may be pooled over pixels, averaged over "
            "scenes, or averaged over folds. The numbers differ and §22.3 does not choose."
        ),
        frozen_value=PRIMARY_AGGREGATION,
        rationale=(
            "Unweighted mean over the 15 unique eval-role scenes. The three fold means are "
            "reported descriptively and are never averaged into the primary number, because the "
            "folds have unequal scene counts (6 / 4 / 5)."
        ),
    ),
    FrozenChoice(
        key="checkpoint3_threshold",
        governing_text="coverage error 控制约 ±2~3 percentage points；同时 interval width 不显著恶化。",
        source="V3 §40",
        why_it_changes_a_result=(
            "§40 gives a band ('约 ±2~3 percentage points') and an undefined significance "
            "comparison ('不显著恶化') rather than a pass/fail rule."
        ),
        frozen_value=f"abs_tol={CHECKPOINT3_ABSOLUTE_TOLERANCE}",
        rationale=(
            "The strict end of V3's own band is taken (0.03, not 0.02~0.03), checked on all six "
            "seed x level combinations rather than on the seed mean. 'Width not significantly "
            "worse' is replaced by exact width-only parity (C3.3) plus finite, non-negative, "
            "fully reported widths (C3.4) — never by a significance claim."
        ),
    ),
)

FROZEN_KEYS = tuple(choice.key for choice in FROZEN_CHOICES)

_VALID = {
    "c1_family": {C1_FAMILY},
    "c1_interval_mode": {C1_INTERVAL_MODE},
    "c1_quantile_rule": {C1_QUANTILE_RULE},
    "c1_finite_sample_correction": {C1_FINITE_SAMPLE_CORRECTION},
    "c1_fit_unit": {C1_FIT_UNIT},
    "c0_interval_rule": {"expm1_raw_score_radius"},
    "aggregation_unit": {PRIMARY_AGGREGATION, SUPPLEMENTARY_AGGREGATION, DESCRIPTIVE_AGGREGATION},
    "checkpoint3_threshold": {f"abs_tol={CHECKPOINT3_ABSOLUTE_TOLERANCE}"},
}

#: The frozen values, as a mapping a config can be checked against.
FROZEN_VALUES = {
    "c1_family": C1_FAMILY,
    "c1_interval_mode": C1_INTERVAL_MODE,
    "c1_quantile_rule": C1_QUANTILE_RULE,
    "c1_finite_sample_correction": C1_FINITE_SAMPLE_CORRECTION,
    "c1_fit_unit": C1_FIT_UNIT,
    "c0_interval_rule": "expm1_raw_score_radius",
    "aggregation_unit": PRIMARY_AGGREGATION,
    "checkpoint3_threshold": f"abs_tol={CHECKPOINT3_ABSOLUTE_TOLERANCE}",
}


class SpecBlocked(RuntimeError):
    """Raised when a value that affects a scientific result has no frozen choice."""


def blocking_keys(spec_config: Mapping[str, Any]) -> list[str]:
    """Which registered keys are still open in ``spec_config`` (a raw mapping)."""
    return [key for key in FROZEN_KEYS if spec_config.get(key, UNRESOLVED) == UNRESOLVED]


def _require(value: Any, key: str) -> Any:
    if value is None or value == UNRESOLVED:
        raise SpecBlocked(
            f"{key} has no frozen value: reopen it only with an explicit protocol amendment "
            f"written before any Week 5 calibration number exists."
        )
    return value


@dataclass(frozen=True)
class CalibrationSpec:
    """A fully resolved calibration specification."""

    c1_family: str
    c1_interval_mode: str
    c1_quantile_rule: str
    c1_finite_sample_correction: str
    c1_fit_unit: str
    c0_interval_rule: str
    aggregation_unit: str
    checkpoint3_threshold: str
    nominal_coverages: tuple[float, ...] = NOMINAL_COVERAGES
    protocol: str = CALIBRATION_PROTOCOL
    frozen_by: str = WEEK5_AMENDMENT

    @classmethod
    def from_config(cls, config: Mapping[str, Any]) -> "CalibrationSpec":
        """Build from a raw config mapping; refuse if any key is reopened."""
        nested = config.get("calibration", config)
        open_keys = blocking_keys(nested)
        if open_keys:
            raise SpecBlocked(f"Week 5 calibration spec is not frozen: {sorted(open_keys)}")
        values: dict[str, Any] = {}
        for key in FROZEN_KEYS:
            value = _require(nested.get(key), key)
            if value not in _VALID[key]:
                raise SpecBlocked(f"{key}={value!r} is not one of {sorted(_VALID[key])}")
            values[key] = value
        coverages = tuple(float(c) for c in nested.get("nominal_coverages", NOMINAL_COVERAGES))
        for coverage in coverages:
            if not 0.0 < coverage < 1.0:
                raise ValueError(f"Nominal coverage must lie in (0, 1), got {coverage}")
        return cls(nominal_coverages=coverages, **values)

    def as_dict(self) -> dict[str, Any]:
        payload = asdict(self)
        payload["nominal_coverages"] = list(self.nominal_coverages)
        return payload

    def digest(self) -> str:
        canonical = json.dumps(self.as_dict(), sort_keys=True, separators=(",", ":"))
        return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


def load_spec_config(path: Path) -> dict[str, Any]:
    """Load the Week 5 calibration config as a plain mapping."""
    import yaml

    with Path(path).open("r", encoding="utf-8") as handle:
        data = yaml.safe_load(handle)
    if not isinstance(data, dict):
        raise ValueError(f"Expected a YAML mapping in {path}")
    return data
