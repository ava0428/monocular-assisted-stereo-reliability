"""Exclusive run ownership: one lock, one owner, no automatic recovery.

A run directory is owned by exactly one process at a time. Ownership is taken
with an atomic ``O_CREAT | O_EXCL`` create, which is the only portable primitive
that both Windows and Linux honour — a prior ``exists()`` check is not a
mechanism, it is a race.

A lock left behind by a crashed process is **stale**, not free. This module will
not delete it, will not time it out, and will not take it over. It stops and
reports, and a human decides. There is deliberately no ``--force-unlock``.
"""
from __future__ import annotations

import json
import os
import socket
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable
from uuid import uuid4

LOCK_FILENAME = "run.lock"
LOCK_SCHEMA = "week5-run-lock-1"
MODE_FRESH = "fresh"
MODE_RESUME = "resume"


class LockError(RuntimeError):
    """The run lock could not be taken, or was not ours to release."""


class StaleLockError(LockError):
    """A lock exists that this process did not create. Never broken automatically."""


@dataclass(frozen=True)
class LockRecord:
    schema: str
    run_id: str
    binding_digest: str
    pid: int
    hostname: str
    owner_token: str
    created_at: str
    mode: str

    def as_dict(self) -> dict:
        return asdict(self)


class RunLease:
    """A held lock. Every production write must present one of these."""

    def __init__(self, path: Path, record: LockRecord) -> None:
        self._path = Path(path)
        self._record = record
        self._released = False

    @property
    def path(self) -> Path:
        return self._path

    @property
    def record(self) -> LockRecord:
        return self._record

    @property
    def owner_token(self) -> str:
        return self._record.owner_token

    @property
    def run_id(self) -> str:
        return self._record.run_id

    @property
    def released(self) -> bool:
        return self._released

    def verify(self) -> None:
        """Confirm we still hold it, matching on the owner token, not on existence."""
        if self._released:
            raise LockError("this lease has already been released")
        if not self._path.is_file():
            raise LockError(f"lock file {self._path} disappeared while the lease was held")
        payload = json.loads(self._path.read_text(encoding="utf-8"))
        if payload.get("owner_token") != self._record.owner_token:
            raise LockError(
                f"lock {self._path} is held by owner {payload.get('owner_token')!r}, "
                f"not by us ({self._record.owner_token!r})"
            )

    def release(self) -> None:
        """Release only if the token still matches; never remove another's lock."""
        if self._released:
            return
        if not self._path.is_file():
            self._released = True
            return
        payload = json.loads(self._path.read_text(encoding="utf-8"))
        if payload.get("owner_token") != self._record.owner_token:
            raise LockError(
                f"refusing to release {self._path}: it is owned by "
                f"{payload.get('owner_token')!r}, not by us"
            )
        self._path.unlink()
        self._released = True

    def __enter__(self) -> "RunLease":
        self.verify()
        return self

    def __exit__(self, exc_type, exc, tb) -> bool:
        # A handled error still releases; a crash never reaches here, and the
        # stale lock it leaves is a human decision, not an automatic one.
        self.release()
        return False


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def acquire_run_lock(
    run_dir: Path,
    *,
    run_id: str,
    binding_digest: str,
    mode: str,
    owner_token: str | None = None,
    clock: Callable[[], str] | None = None,
) -> RunLease:
    """Take the run lock atomically. A second holder fails immediately."""
    if mode not in (MODE_FRESH, MODE_RESUME):
        raise LockError(f"mode must be {MODE_FRESH!r} or {MODE_RESUME!r}, got {mode!r}")
    run_dir = Path(run_dir)
    run_dir.mkdir(parents=True, exist_ok=True)
    lock_path = run_dir / LOCK_FILENAME
    record = LockRecord(
        schema=LOCK_SCHEMA,
        run_id=str(run_id),
        binding_digest=str(binding_digest),
        pid=os.getpid(),
        hostname=socket.gethostname(),
        owner_token=owner_token or uuid4().hex,
        created_at=(clock or _now)(),
        mode=mode,
    )
    payload = (json.dumps(record.as_dict(), sort_keys=True, separators=(",", ":")) + "\n").encode("utf-8")
    try:
        # Atomic create: O_EXCL fails if the file appeared between any earlier
        # check and this call, which is exactly the race a check cannot close.
        descriptor = os.open(lock_path, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
    except FileExistsError as exc:
        existing = {}
        try:
            existing = json.loads(lock_path.read_text(encoding="utf-8"))
        except (OSError, ValueError):  # pragma: no cover - unreadable lock is still a lock
            pass
        raise StaleLockError(
            f"run lock {lock_path} already exists and was not created by this process "
            f"(run_id={existing.get('run_id')!r} pid={existing.get('pid')!r} "
            f"host={existing.get('hostname')!r} created={existing.get('created_at')!r}). "
            f"A stale lock is never broken, timed out or taken over automatically; inspect it and "
            f"remove it deliberately."
        ) from exc
    try:
        with os.fdopen(descriptor, "wb") as handle:
            handle.write(payload)
            handle.flush()
            os.fsync(handle.fileno())
    except BaseException:
        lock_path.unlink(missing_ok=True)
        raise
    return RunLease(lock_path, record)


def read_lock(run_dir: Path) -> LockRecord | None:
    """Read the current lock record, if any. Read-only."""
    path = Path(run_dir) / LOCK_FILENAME
    if not path.is_file():
        return None
    payload = json.loads(path.read_text(encoding="utf-8"))
    if payload.get("schema") != LOCK_SCHEMA:
        raise LockError(f"unexpected lock schema {payload.get('schema')!r} in {path}")
    return LockRecord(**payload)
