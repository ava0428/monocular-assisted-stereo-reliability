"""Week 5 — scene-disjoint calibration (V3 §16–§18, §27.2, §40).

``V3_FINAL_RESEARCH_PLAN.md`` leaves eight calibration quantities open.
``PROTOCOL_AMENDMENT_WEEK5_010`` freezes them before any Week 5 calibration
number exists, as forward-looking choices recorded in
:data:`~src.calibration.spec.FROZEN_CHOICES` — not as details V3 already had.
Every field is still explicit and still required: nothing is defaulted, and
constructing a spec with any key reopened raises :class:`SpecBlocked`.

Nothing here reads a Middlebury cache, a prediction or a metric. The fold
structure comes from the pre-registered split config, which contains scene
*names* only.
"""
from __future__ import annotations

from src.calibration.spec import (
    CALIBRATION_PROTOCOL,
    CHECKPOINT3_ABSOLUTE_TOLERANCE,
    FROZEN_CHOICES,
    FROZEN_KEYS,
    FROZEN_VALUES,
    NOMINAL_COVERAGES,
    PRIMARY_AGGREGATION,
    RESULT_LABEL,
    SELECTIVE_COVERAGE_GRID,
    UNRESOLVED,
    WEEK5_AMENDMENT,
    CalibrationSpec,
    FrozenChoice,
    SpecBlocked,
)

__all__ = [
    "CALIBRATION_PROTOCOL",
    "CHECKPOINT3_ABSOLUTE_TOLERANCE",
    "FROZEN_CHOICES",
    "FROZEN_KEYS",
    "FROZEN_VALUES",
    "NOMINAL_COVERAGES",
    "PRIMARY_AGGREGATION",
    "RESULT_LABEL",
    "SELECTIVE_COVERAGE_GRID",
    "UNRESOLVED",
    "WEEK5_AMENDMENT",
    "CalibrationSpec",
    "FrozenChoice",
    "SpecBlocked",
]
