"""``Grel-direct`` — the primary Week 6 task-space candidate.

``Grel-direct`` is the frozen R2-gate network **verbatim**. The only permitted
difference from R2-gate is the training target and the selection objective:

    R2-gate      target  log1p( |d_pred - d_gt| )
    Grel-direct  target  log1p( ProxyRel ),  ProxyRel = |d_pred - d_gt| / d_pred

Parity is structural, not asserted after the fact: this module builds the *same*
class with the *same* ``GateSpec``, so the constructor, the three-tensor forward
and the parameter count cannot drift. :func:`assert_parity_with_r2_gate` makes
that explicit for a test and fails loudly if it ever stops being true.

The target is named ``ProxyRel`` and never ``AbsRel``: SceneFlow's ``d_offs = 0``
has no first-hand code or data contract, so the training target is a
disparity-derived proxy, and the estimator is evaluated against a
calibration-derived ``AbsRel`` on Middlebury / ETH3D. That source-target estimand
mismatch is pre-disclosed and must not be packaged as one common target.
"""
from __future__ import annotations

import numpy as np
import torch

from src.models.risk_predictor import (
    GATE_MONO_CHANNELS,
    GateRiskPredictor,
    GateSpec,
    build_r2_gate,
    gate_parameter_count,
)
from src.taskspace.geometry import proxy_rel
from src.taskspace.spec import (
    PROXYREL_DEFINITION,
    PROXYREL_TARGET,
    R2_GATE_SEEDS,
)

#: The frozen R2-gate topology. Grel-direct reuses it unchanged.
GREL_HIDDEN_CHANNELS = 21
GREL_GATE_CHANNELS = 88
GREL_TRAINABLE_PARAMETERS = 18_910

#: The only permitted difference: the target. Never called "source AbsRel".
GREL_TARGET = PROXYREL_TARGET
GREL_TARGET_NAME = "ProxyRel"


class TargetNaming(RuntimeError):
    """The source target was described as ``AbsRel``. It is ``ProxyRel``."""


def build_grel_direct(
    hidden_channels: int = GREL_HIDDEN_CHANNELS,
    gate_channels: int = GREL_GATE_CHANNELS,
) -> GateRiskPredictor:
    """The Grel-direct model: the frozen R2-gate network, unchanged."""
    return GateRiskPredictor(
        GateSpec(
            name="Grel-direct",
            stereo_channels=11,
            mono_disagreement_channels=8,
            hidden_channels=hidden_channels,
            gate_channels=gate_channels,
        )
    )


def _clone_state(source: torch.nn.Module, target: torch.nn.Module) -> None:
    target.load_state_dict(source.state_dict())


def assert_parity_with_r2_gate() -> dict[str, object]:
    """Exact parity of constructor, forward and parameter count.

    Two independently built networks are given the SAME weights and the SAME
    three input tensors, and their outputs must be bit-identical. Anything other
    than the target differing between the two models fails here.
    """
    torch.manual_seed(20260910)
    reference = build_r2_gate()
    candidate = build_grel_direct()
    _clone_state(reference, candidate)

    shapes = ((11, 6, 5), (8, 6, 5), (5, 6, 5))
    stereo = torch.randn(2, *shapes[0])
    disagreement = torch.randn(2, *shapes[1])
    mono = torch.randn(2, *shapes[2])

    reference.eval()
    candidate.eval()
    with torch.no_grad():
        ref = reference(stereo, disagreement, mono)
        got = candidate(stereo, disagreement, mono)

    if not torch.equal(ref, got):
        worst = float((ref - got).abs().max())
        raise AssertionError(f"Grel-direct forward differs from R2-gate by {worst}")

    ref_params = int(sum(p.numel() for p in reference.parameters() if p.requires_grad))
    got_params = int(sum(p.numel() for p in candidate.parameters() if p.requires_grad))
    if ref_params != got_params:
        raise AssertionError(f"parameter count {got_params} != R2-gate {ref_params}")
    if got_params != GREL_TRAINABLE_PARAMETERS:
        raise AssertionError(
            f"parameter count {got_params} != the frozen {GREL_TRAINABLE_PARAMETERS}"
        )
    if got_params != gate_parameter_count(GREL_HIDDEN_CHANNELS, GREL_GATE_CHANNELS):
        raise AssertionError("analytical and instantiated parameter counts disagree")

    if candidate.input_channels != (11, 8, GATE_MONO_CHANNELS):
        raise AssertionError(f"input channels {candidate.input_channels} != (11, 8, 5)")

    return {
        "trainable_parameters": got_params,
        "input_channels": candidate.input_channels,
        "hidden_channels": GREL_HIDDEN_CHANNELS,
        "gate_channels": GREL_GATE_CHANNELS,
        "forward_identical": True,
    }


def forward_is_three_tensors(model: GateRiskPredictor) -> bool:
    """The input is three separate tensors, never one 24-channel tensor."""
    import inspect

    params = list(inspect.signature(model.forward).parameters)
    return params == ["stereo", "mono_disagreement", "mono"]


def build_proxyrel_target(d_pred: np.ndarray, d_gt: np.ndarray) -> np.ndarray:
    """``log1p( |d_pred - d_gt| / d_pred )`` — the ProxyRel training target."""
    return np.log1p(proxy_rel(d_pred, d_gt))


def assert_proxyrel_naming(text: str) -> str:
    """Refuse calling the source target ``AbsRel``."""
    lowered = text.lower()
    if "absrel" in lowered and "proxyrel" not in lowered:
        raise TargetNaming(
            f"{PROXYREL_DEFINITION} is the source target and is named ProxyRel, not AbsRel: "
            f"{text!r}"
        )
    return text


def frozen_seeds() -> tuple[int, ...]:
    return R2_GATE_SEEDS
