"""Current-code checkpoint reconstruction pilot. No backbone or training."""
from pathlib import Path
import sys,json,time,hashlib
import numpy as np
HERE=Path(__file__).resolve().parent;ROOT=next(p for p in HERE.parents if (p/'src/models/risk_predictor.py').exists())
sys.path.insert(0,str(ROOT))
import torch
from src.evidence.normalization import NormalizationConstants
from src.taskspace.middlebury_scores import load_verified_model,raw_score
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_text(encoding='utf-8'))
HERE.mkdir(exist_ok=True)
scope={'classification':'current-code regenerated validation; original arrays not overwritten','families':['r1','r2_gate'],'seed':20260910,'pilot_frames':['Door_im0','Mirror_im0'],'tau_policy':.90,'new_training':False,'new_backbone_forwards':False,'device':'local CUDA','precision':'float32 model inference, float64 native evaluator','fixed_before_result':True}
(HERE/'pilot_protocol.json').write_text(json.dumps(scope,indent=2)+'\n')
entries=load(HERE.parent/'review_support/checkpoint_availability.json')
constants=NormalizationConstants.load(ROOT/'configs/normalization_sceneflow_train.json');device=torch.device('cuda')
records=[]
for fam in scope['families']:
    e=next(x for x in entries if x['family']==fam and x['seed']==20260910);cp=ROOT/e['local_matches'][0];e['bytes']=cp.stat().st_size
    model=load_verified_model(fam,cp,e,device)
    for stem in scope['pilot_frames']:
        p=ROOT/'outputs/jise_mono_ablation_booster_inputs_20261005/frames'/(stem+'.npz')
        with np.load(p) as z:arrays={k:z[k] for k in z.files}
        torch.cuda.synchronize();t=time.perf_counter();raw=raw_score(fam,model,arrays,constants,device);torch.cuda.synchronize();elapsed=time.perf_counter()-t
        dest=HERE/'pilot_scores'/fam/(stem+'.npy');dest.parent.mkdir(parents=True,exist_ok=True);np.save(dest,raw)
        r={'family':fam,'frame':stem,'input_sha256':sha(p),'checkpoint_sha256':sha(cp),'score_sha256':sha(dest),'seconds':elapsed,'shape':list(raw.shape),'peak_cuda_bytes':torch.cuda.max_memory_allocated()}
        old=ROOT/'outputs/ddcv_rel_cal_validation_20261012/baseRA_maps/r2_gate_seed20260910'/(stem+'.npy')
        if fam=='r2_gate':
            x=np.load(old);diff=raw.astype(float)-x;r.update(old_score_sha256=sha(old),exact_equal=bool(np.array_equal(raw,x)),max_abs_delta=float(np.max(np.abs(diff))),mean_abs_delta=float(np.mean(np.abs(diff))))
        records.append(r);print(json.dumps(r),flush=True)
result={'protocol':scope,'torch':torch.__version__,'numpy':np.__version__,'gpu':torch.cuda.get_device_name(0),'normalization_sha256':sha(ROOT/'configs/normalization_sceneflow_train.json'),'records':records,'source_hashes':{str(p.relative_to(ROOT)):sha(p) for p in [ROOT/'src/taskspace/middlebury_scores.py',ROOT/'src/models/r2_inputs.py',ROOT/'src/models/risk_predictor.py',ROOT/'src/evidence/stereo_evidence_gpu.py',ROOT/'src/evidence/normalization.py',ROOT/'src/evidence/mono_evidence.py',ROOT/'src/evidence/negative_controls.py']}}
(HERE/'pilot_inference.json').write_text(json.dumps(result,indent=2)+'\n')
