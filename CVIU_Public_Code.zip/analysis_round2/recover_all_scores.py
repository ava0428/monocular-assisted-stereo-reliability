"""Regenerate existing frozen heads on cached predictions, no backbone/GT."""
from pathlib import Path
import sys,json,time,hashlib,shutil
import numpy as np
HERE=Path(__file__).resolve().parent;ROOT=next(p for p in HERE.parents if (p/'src/models/risk_predictor.py').exists());OUT=HERE.parents[2]/'compute_round2'
sys.path.insert(0,str(ROOT))
import torch
from src.evidence.normalization import NormalizationConstants
from src.evidence.negative_controls import build_donor_permutation
from src.taskspace.middlebury_scores import load_verified_model,raw_score
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_text(encoding='utf-8'))
def write(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,indent=2)+'\n')
FAMILIES=['r1','r2_gate','r2_concat','r2_dis','n_random','n_shuffle'];SEEDS=[20260910,20260911,20260912]
protocol={'classification':'current-code regenerated validation, disjoint from canonical','families':FAMILIES,'seeds':SEEDS,'tau':[.8,.9,.95],'primary_tau':.9,'coverage':[.8,.9],'paths':['projected_raw','h0','h0/a','qd/a','1/a'],'primary_complete_path_families':['r1','r2_gate'],'scopes':{'EVAL':108,'CAL':120},'backbone_forwards':0,'training':False,'GT_opened_during_score_generation':False,'output_root':str(OUT),'free_disk_bytes_before':shutil.disk_usage(OUT.parent).free}
write(HERE/'full_protocol.json',protocol)
constants=NormalizationConstants.load(ROOT/'configs/normalization_sceneflow_train.json');device=torch.device('cuda')
entries=load(HERE.parent/'review_support/checkpoint_availability.json');models={};identities={}
for fam in FAMILIES:
    for seed in SEEDS:
        e=next(x for x in entries if x['family']==fam and x['seed']==seed);cp=ROOT/e['local_matches'][0];e['bytes']=cp.stat().st_size
        models[fam,seed]=load_verified_model(fam,cp,e,device);identities[fam,seed]={'sha256':sha(cp),'step':e['selected_step'],'path':str(cp.relative_to(ROOT))}
t0=time.perf_counter();records=[]
for role,input_name in [('EVAL','jise_mono_ablation_booster_inputs_20261005'),('CAL','jise_mono_ablation_booster_cal_inputs_20261005')]:
    inp=ROOT/'outputs'/input_name;manifest=load(inp/'manifest.json');frames=manifest.get('frames',manifest.get('records'));byid={r['scene']+'/'+r['frame']:r for r in frames};donors=build_donor_permutation(tuple(byid),{k:r['scene'] for k,r in byid.items()})
    write(OUT/role/'run.json',{'input_manifest_sha256':sha(inp/'manifest.json'),'donor_map':donors,'torch':torch.__version__,'gpu':torch.cuda.get_device_name(0),'normalization_sha256':sha(ROOT/'configs/normalization_sceneflow_train.json'),'protocol':protocol})
    for i,rec in enumerate(frames):
        ip=inp/rec['input_npz'];assert sha(ip)==rec['input_sha256'];stem=rec['scene']+'_'+rec['frame'];start=time.perf_counter()
        with np.load(ip) as z:arrays={k:z[k] for k in z.files}
        donor=byid[donors[rec['scene']+'/'+rec['frame']]]
        with np.load(inp/donor['input_npz']) as z:donor_mono=z['mono_relative_depth']
        for fam in FAMILIES:
            for seed in SEEDS:
                dest=OUT/role/'raw_scores'/(fam+'_seed'+str(seed))/(stem+'.npy');receipt=dest.with_suffix('.json')
                if receipt.exists():
                    rr=load(receipt);assert dest.is_file() and sha(dest)==rr['score_sha256'];continue
                raw=raw_score(fam,models[fam,seed],arrays,constants,device,donor_mono=donor_mono if fam=='n_shuffle' else None);dest.parent.mkdir(parents=True,exist_ok=True);np.save(dest,raw)
                rr={'role':role,'family':fam,'seed':seed,'scene':rec['scene'],'frame':rec['frame'],'score_sha256':sha(dest),'input_npz_sha256':rec['input_sha256'],'checkpoint':identities[fam,seed],'shape':list(raw.shape),'donor_id':donors[rec['scene']+'/'+rec['frame']] if fam=='n_shuffle' else None,'GT_opened':False};write(receipt,rr)
        records.append({'role':role,'frame':stem,'seconds':time.perf_counter()-start});print(role,i+1,len(frames),stem,round(records[-1]['seconds'],2),flush=True)
write(HERE/'score_recovery_complete.json',{'frames':len(records),'forwards':len(records)*18,'elapsed_seconds':time.perf_counter()-t0,'peak_cuda_bytes':torch.cuda.max_memory_allocated(),'torch':torch.__version__,'records':records,'output_root':str(OUT),'classification':protocol['classification']})
