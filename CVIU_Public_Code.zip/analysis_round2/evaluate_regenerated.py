"""Independent current-code validation using the bound exact metric function.
Core: Stereo/Base all 3 runs, 5 paths, 108 frames. Extras: remaining matched
families at .90 plus Stereo/Base tau .80/.95, no tuning or cohort changes.
"""
from pathlib import Path
import json,time,hashlib,argparse,csv
from concurrent.futures import ThreadPoolExecutor
import numpy as np,cv2
from gpu_sort_contract import evaluator
HERE=Path(__file__).resolve().parent;ROOT=next(p for p in HERE.parents if (p/'src/models/risk_predictor.py').exists());OUT=HERE.parents[2]/'compute_round2'
def load(p):return json.loads(p.read_text(encoding='utf-8'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,indent=2)+'\n')
ap=argparse.ArgumentParser();ap.add_argument('--stage',choices=['core','extras'],required=True);ap.add_argument('--workers',type=int,choices=[1,2],default=2);args=ap.parse_args()
assert load(HERE/'gpu_sort_parity.json')['tie_nan_neginf_posinf_status_parity']
fits={(r['family'],r['seed'],r['tau']):r['delta'] for r in load(HERE/'cal_refit.json')['rows']}
old={(r['family'],r['seed']):r['delta'] for r in load(ROOT/'outputs/jise_mono_ablation_cal_eval_joint_20261005/cal_fits.json')['fits']}
inp=ROOT/'outputs/jise_mono_ablation_booster_inputs_20261005';gtroot=ROOT/'outputs/jise_mono_ablation_booster_eval_operands_20261005';frames=load(inp/'manifest.json')['frames'];gts={r['scene']:r for r in load(gtroot/'manifest.json')['records']};seeds=[20260910,20260911,20260912]
exact=evaluator(True);t0=time.perf_counter();full=[]
with ThreadPoolExecutor(max_workers=args.workers) as pool:
    for fi,rec in enumerate(frames):
        stem=rec['scene']+'_'+rec['frame'];dest=OUT/'evaluations'/args.stage/(stem+'.json')
        if dest.exists():full.extend(load(dest)['rows']);continue
        tick=time.perf_counter();ip=inp/rec['input_npz'];gp=gtroot/gts[rec['scene']]['operand_npz'];assert sha(ip)==rec['input_sha256'] and sha(gp)==gts[rec['scene']]['operand_sha256']
        with np.load(ip) as z:d0=z['stereo_disparity']
        with np.load(gp) as z:gt=z['gt_disparity']
        u=np.isfinite(gt)&(gt>0);target=(gt.shape[1],gt.shape[0]);d=cv2.resize(d0.astype(float),target,interpolation=cv2.INTER_LINEAR)[u]*4;a=d+gts[rec['scene']]['geometry']['doffs'];e=np.abs(d-gt[u]);loss=e/a;assert np.isfinite(loss).all() and np.all(a>0)
        rows=[];pending=[]
        def job(fam,seed,rule,tau,risk,diag):
            metric,_=exact(risk,{'absrel':loss},262144)
            return {'scene':rec['scene'],'frame':rec['frame'],'family':fam,'seed':seed,'rule':rule,'tau':tau,**{k:metric[k] for k in ['absrel_80','absrel_90','absrel_aurc','n_unit','score_nan','score_neginf','score_posinf']},**diag}
        if args.stage=='core':rows.append(job('Depth-Only',0,'1/a',None,1/a,{}))
        families=['r1','r2_gate'] if args.stage=='core' else ['r1','r2_gate','r2_concat','r2_dis','n_random','n_shuffle']
        for fam in families:
            for seed in seeds:
                p=OUT/'EVAL/raw_scores'/(fam+'_seed'+str(seed))/(stem+'.npy');receipt=load(p.with_suffix('.json'));assert sha(p)==receipt['score_sha256'] and receipt['input_npz_sha256']==rec['input_sha256']
                raw=np.asarray(np.load(p),float);h0=cv2.resize(np.maximum(np.expm1(raw),0),target,interpolation=cv2.INTER_LINEAR)[u]*4
                if args.stage=='core':
                    delta=fits[fam,seed,.9];q=np.maximum(h0+delta,0);qold=np.maximum(h0+old[fam,seed],0)
                    diag={'delta':delta,'EVAL_pixel_empirical_coverage':float(np.mean(e<=q)),'EVAL_old_delta_coverage':float(np.mean(e<=qold)),'mean_h0':float(h0.mean()),'mean_abs_disparity_error':float(e.mean()),'mean_qd':float(q.mean()),'zero_radius_count':int((q==0).sum())}
                    tasks=[('projected_raw',None,cv2.resize(raw,target,interpolation=cv2.INTER_LINEAR)[u]),('h0',None,h0),('h0/a',None,h0/a),('qd/a',.9,q/a)]
                else:
                    taus=[.8,.95] if fam in ('r1','r2_gate') else [.9];tasks=[];diag={}
                    for tau in taus:tasks.append(('qd/a',tau,np.maximum(h0+fits[fam,seed,tau],0)/a))
                jobs=[]
                for rule,tau,risk in tasks:
                    dd=dict(diag);dd['applied_delta']=fits[fam,seed,tau] if rule=='qd/a' else (0. if rule=='h0/a' else None)
                    if args.stage=='extras':dd={'delta':fits[fam,seed,tau],'EVAL_pixel_empirical_coverage':float(np.mean(e<=np.maximum(h0+fits[fam,seed,tau],0)))}
                    jobs.append(pool.submit(job,fam,seed,rule,tau,risk,dd))
                if args.stage=='extras':pending.extend(jobs)
                else:rows.extend(j.result() for j in jobs)
                del tasks,jobs,h0,raw
        rows.extend(j.result() for j in pending)
        record={'stage':args.stage,'classification':'current-code regenerated validation; current refit delta','source_input_sha256':rec['input_sha256'],'source_gt_sha256':gts[rec['scene']]['operand_sha256'],'frame_seconds':time.perf_counter()-tick,'rows':rows};write(dest,record);full.extend(rows);print(args.stage,fi+1,len(frames),stem,round(record['frame_seconds'],2),'elapsed',round(time.perf_counter()-t0),flush=True)
        del gt,d,a,e,loss,u
write(HERE/(args.stage+'_evaluation_complete.json'),{'stage':args.stage,'frames':len(frames),'rows':len(full),'elapsed_seconds':time.perf_counter()-t0,'classification':'current-code regenerated validation'})
fields=list(dict.fromkeys(k for r in full for k in r))
with (HERE/(args.stage+'_frame_metrics.csv')).open('w',newline='',encoding='utf-8') as f:w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(full)
