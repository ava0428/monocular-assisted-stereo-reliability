# Round 2: existing-checkpoint validation

This directory separates newly executed validation from the unchanged historical canonical tables. The primary family, run, CAL/EVAL split, native domain, interpolation, stable ordering, retained counts and exact integration definitions are retained. All six families reuse their source-selected checkpoints; cached stereo/mono predictions avoid every backbone forward. No training or new data is used.

Completed: 4,104 head forwards, 54 CAL fits, and 5,292 native frame/configuration evaluations (49 configurations on each of 108 frames). The exact family/run/path/tau set is checked per frame, with 19 scene-directory groups and no missing/duplicate configurations. These are configurations, not 49 independent methods. Core and extras stages are complete. All newly evaluated risk arrays had zero NaN, negative-infinity and positive-infinity counts; this statement does not replace the historical Depth-Exact state analysis.

## Meaning of the outputs

- `native_pilot.json`: historical Door/Mirror im0, seed0, five-path analysis and retained-set decomposition, plus separately marked regenerated pilots. Both pilot origins hold the historical delta fixed for compatibility diagnosis; the complete regenerated validation separately uses its new CAL fits. Historical-score two-frame analyses can be attached to the existing Figure 4. The `EVAL_pixel_empirical_radius_coverage` field always refers to the calibrated radius, not retained coverage and not an uncalibrated-path claim.
- `pilot_inference.json`: checkpoint/input identities, two-frame differences from available historical Base-Risk score maps and runtime context. Timings are pilot diagnostics, not an end-to-end cost benchmark.
- `full_protocol.json`: families, all three fixed runs, predeclared tau 0.80/0.90/0.95, grids and scope, written before full regeneration/results.
- `score_recovery_complete.json`: actual complete 4,104 head forwards on the 120 CAL and 108 EVAL cached inputs; no GT during score generation.
- `cal_refit.json`: all 54 new fits, fitted-sample empirical coverage, radius/error quantiles and per-directory-group sample coverage. Each configuration uses 155,648 samples (8,192 per directory group distributed among its frames). The new tau=0.90 fit is compared with the historical fit rather than forced to match it. The empirical fitted-sample coverages are not independent coverage validation.
- `gpu_sort_parity.json`: ten genuine native-array stable-order comparisons (two frames, five paths each) and one explicit synthetic NaN/negative-infinity/positive-infinity/tie case. This bounded check is not a CPU/GPU parity test on every full-cohort array. Only stable float64 sorting is accelerated; the preserved `exact_metrics` function performs the original NumPy float64 all-count accumulation. No sampled curve integration is substituted. The complete matrix check verifies executed scope and reductions, not a second native-data rerun.
- `core_frame_metrics.csv`: complete current-score/current-fit Stereo-Err and Base-Risk, each three runs, projected raw, h0, h0/a, qd/a and shared Depth-Only.
- `extras_frame_metrics.csv`: additional current-score/current-fit matched Mono, Disag, Random Mono and Shuffled Mono at tau=0.90, and Stereo/Base at tau=0.80/0.95. This keeps the R2-dis-topology controls separate from gate causality.
- `regenerated_*`: frame-to-scene-equal reductions, fixed-run sample SD and descriptive paired scene bootstrap. The bootstrap averages fixed runs inside each scene before resampling 19 scene-directory groups with the historical RNG/10,000 draws; it does not refit CAL during resampling.
- `canonical_comparison_no_replacement.csv`: like-for-like comparison of historical and newly executed raw/RA numerical results. A difference is retained, never repaired by editing canonical files.
- `absrel_identity_roundoff.json`: the regenerated evaluator forms positive-depth AbsRel as `abs(d-gt)/(d+doffs)` in float64; the historical driver formed the equivalent depth ratio. For Door/Mirror native frames, maximum pixel-level roundoff differences are 8.88e-16 and 1.78e-15. This is disclosed as an arithmetic-expression difference within the same metric, not a correction to historical results. Stable sorting and the full historical integration function are preserved.
- `execution_sources/`: the actual project inference/CAL imports and normalization config used in this execution. `execution_source_identity.json` binds their hashes. The preserved early adapter predates the concat/dis registry additions; the scoring function bodies are unchanged. Runtime/device differences remain part of the distinct execution identity.
- `checkpoint_identity.json`: all 18 source-selected checkpoint hashes, selected steps and existing local relative locations. The actual inference loader rehashes and strictly checks each checkpoint before loading; weight bytes are not part of the light attachment.

In core output, `EVAL_pixel_empirical_coverage` refers to the family/run's tau=0.90 calibrated qd and is repeated across its path rows for context. It is a native-domain pixel fraction averaged by frame then scene for cohort reports. It must not be interpreted as coverage by raw or h0. `tau` is blank for raw/h0/h0/a; `applied_delta=0` identifies the zero-offset construction. `EVAL_old_delta_coverage` replays the historical delta on regenerated scores as a separately named diagnostic, never a canonical replacement.

## Actual local execution commands

Executed with `D:/Anaconda3/envs/msn-yolo/python.exe` (PyTorch 2.0.1+cu118, local RTX4070 Laptop). The figure/LaTeX pipeline is independent.

```powershell
python analysis_round2/pilot_recover.py
python analysis_round2/native_pilot.py
python analysis_round2/gpu_sort_contract.py
python analysis_round2/recover_all_scores.py
python analysis_round2/fit_regenerated_cal.py
python analysis_round2/evaluate_regenerated.py --stage core
python analysis_round2/evaluate_regenerated.py --stage extras --workers 1
python analysis_round2/evaluate_regenerated.py --stage extras --workers 2
python analysis_round2/summarize_regenerated.py
python analysis_round2/check_execution_identity.py
python analysis_round2/snapshot_execution_sources.py
```

Scripts locate the original project root by its existing `src/models/risk_predictor.py`. Original input/checkpoint manifests supply paths and hash identities. This is a runnable project entry, not a claim that the manuscript's light attachments include all weights, raw RGB/GT and scores.

The extras stage was resumed with a two-worker independent-task queue after 49 complete frame files had been preserved; no partial JSON file was found and no metric definition changed. `extras_execution_resume.json` records this scheduling change. Its completion `elapsed_seconds` measures the resumed invocation, not the whole extras stage. Core completed in 1,229 s, score regeneration in 283 s and CAL fitting in 198 s; overlapping job times must not be added as wall time or reported as inference latency.

For a clean summary-only review, use `python summarize_regenerated.py` followed by `python write_validation_tables.py` from this directory. The three original, hash-bound inputs in `summary_inputs/` remove project-path dependencies for this entry. This was actually run in a separate clean directory: all seven checked summary/table outputs are byte-identical (`final_analysis_verification.json`). This verifies existing native results and paired statistics; it does not repeat inference, calibration fitting or native sorting.

Large regenerated score arrays and full per-frame native evaluation records are written to `compute_round2/` beside the candidate directory, so they cannot accidentally enter the light submission ZIP. Their actual presence and completion are recorded by the completion JSON files. The source-selected weight files remain at the existing manifest-listed locations. Small summary files and this executed source are suitable for the light validation attachment. The raw score package is about 12.7 GB and is retained locally; availability for external review still requires an actual author-approved delivery channel.

Only files with a corresponding completion record and verified expected count should be treated as finished. If execution is interrupted, resume the same command; verified completed frame artifacts are reused. No historical file is overwritten.
