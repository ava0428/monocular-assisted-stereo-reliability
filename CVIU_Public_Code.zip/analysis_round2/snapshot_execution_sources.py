"""Preserve actual local inference/CAL imports for this regenerated execution."""
from pathlib import Path
import sys,shutil,hashlib,json
HERE=Path(__file__).resolve().parent;ROOT=next(p for p in HERE.parents if (p/'src/models/risk_predictor.py').exists());sys.path.insert(0,str(ROOT))
from src.taskspace.middlebury_scores import raw_score
from src.taskspace.booster_calibration import sampled_operands
from src.evidence.negative_controls import build_donor_permutation
paths={Path(m.__file__).resolve() for name,m in list(sys.modules.items()) if name.startswith('src') and getattr(m,'__file__',None)}
paths.add(ROOT/'configs/normalization_sceneflow_train.json');records=[]
for p in sorted(paths):
    rel=p.relative_to(ROOT);dest=HERE/'execution_sources'/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest);records.append({'path':rel.as_posix(),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
(HERE/'execution_source_identity.json').write_text(json.dumps(records,indent=2)+'\n');print('Preserved',len(records),'actual imported project sources/configs')
