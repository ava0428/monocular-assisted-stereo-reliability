"""Execution-only stable argsort adapter; exact_metrics arithmetic stays NumPy."""
from pathlib import Path
import ast,math,json,time
import numpy as np
import torch
HERE=Path(__file__).resolve().parent
SOURCE=HERE.parent/'review_support/sources/scripts/jise_exact_unified_eval_v1.py'
class StableGPU:
    def __getattr__(self,name):return getattr(np,name)
    def argsort(self,a,kind=None,**kwargs):
        if kind!='stable' or kwargs:raise ValueError('only bound one-dimensional stable argsort permitted')
        a=np.asarray(a);assert a.ndim==1 and a.dtype==np.float64
        return torch.argsort(torch.as_tensor(a,device='cuda'),stable=True).cpu().numpy()
def evaluator(gpu=False):
    tree=ast.parse(SOURCE.read_text(encoding='utf-8'));node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='exact_metrics')
    ns={'np':StableGPU() if gpu else np,'math':math,'BOUNDS':(0.,.2,.4,.6,.8,.9,1.)}
    exec(compile(ast.Module(body=[node],type_ignores=[]),str(SOURCE),'exec'),ns);return ns['exact_metrics']
if __name__=='__main__':
    import cv2
    ROOT=next(p for p in HERE.parents if (p/'src/models/risk_predictor.py').exists());records=[]
    for stem in ['Door_im0','Mirror_im0']:
        scene=stem.split('_')[0]
        with np.load(ROOT/'outputs/jise_mono_ablation_booster_inputs_20261005/frames'/(stem+'.npz')) as z:d=z['stereo_disparity']
        with np.load(ROOT/'outputs/jise_mono_ablation_booster_eval_operands_20261005'/(scene+'.npz')) as z:gt=z['gt_disparity']
        u=np.isfinite(gt)&(gt>0);shape=gt.shape;target=(shape[1],shape[0]);d=cv2.resize(d.astype(float),target,interpolation=cv2.INTER_LINEAR)[u]*4;loss=np.abs(d-gt[u])/d
        raw=np.asarray(np.load(HERE/'pilot_scores/r2_gate'/(stem+'.npy')),float);h=cv2.resize(np.maximum(np.expm1(raw),0),target,interpolation=cv2.INTER_LINEAR)[u]*4
        for name,risk in [('raw',cv2.resize(raw,target,interpolation=cv2.INTER_LINEAR)[u]),('h0',h),('h0/a',h/d),('qd/a',(h+76.50444364561133)/d),('1/a',1/d)]:
            a=np.argsort(risk,kind='stable');t=time.perf_counter();b=StableGPU().argsort(risk,kind='stable');elapsed=time.perf_counter()-t;assert np.array_equal(a,b)
            records.append({'frame':stem,'path':name,'n':len(risk),'index_parity':True,'gpu_sort_seconds':elapsed});del a,b
        t=time.perf_counter();g,_=evaluator(True)((h+76.50444364561133)/d,{'absrel':loss},262144);elapsed=time.perf_counter()-t
        c,_=evaluator(False)((h+76.50444364561133)/d,{'absrel':loss},262144);assert g==c;records[-1]['exact_metrics_dictionary_parity']=True;records[-1]['gpu_sort_cpu_metric_seconds']=elapsed
    # Bad flags are sanitized to +inf exactly as in original function; ties retain flattened order.
    risk=np.array([1.,1.,np.inf,np.nan,-np.inf,0.,0.,np.inf]);loss=np.arange(8,dtype=float)
    c,cp=evaluator(False)(risk,{'absrel':loss},262144);g,gp=evaluator(True)(risk,{'absrel':loss},262144);assert c==g
    (HERE/'gpu_sort_parity.json').write_text(json.dumps({'records':records,'tie_nan_neginf_posinf_status_parity':True,'float64':True,'only_argsort_accelerated':True,'all_cumsum_and_metric_arithmetic_preserved':True},indent=2)+'\n');print(records)
