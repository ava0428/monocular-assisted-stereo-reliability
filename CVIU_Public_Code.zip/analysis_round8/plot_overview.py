"""Real-input study overview: frozen predictions, separately processed scorers.

Figure contract: explain how shared fixed point predictions are selected by raw
and matched scorer-specific paths, not how predictors improve disparity.
Archetype: schematic-led composite; real input row, controlled path diagram.
Inputs are a hash-bound copy of the existing Mirror im0 scoring-grid arrays.
The script only renders stored arrays and vector diagram objects.
"""
from pathlib import Path
import json, hashlib
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
from matplotlib.colors import Normalize
from overview_alignment import require_matplotlib_panel_alignment

HERE=Path(__file__).resolve().parent
OUT=HERE.parent/'manuscript/figures/round8'
OUT.mkdir(parents=True,exist_ok=True)
matplotlib.rcParams.update({'font.family':'Arial','font.size':9,
    'pdf.fonttype':42,'svg.fonttype':'none','mathtext.fontset':'dejavusans',
    'axes.linewidth':0.6,'savefig.dpi':600})
W,H=170,110
fig=plt.figure(figsize=(W/25.4,H/25.4),facecolor='white')
canvas=fig.add_axes([0,0,1,1]);canvas.set(xlim=(0,W),ylim=(0,H));canvas.axis('off')
ink='#26323A';muted='#55636E';edge='#7B8993'
def txt(x,y,s,fs=9,weight='normal',color=ink,ha='center',va='center'):
    return canvas.text(x,y,s,fontsize=fs,fontweight=weight,color=color,ha=ha,va=va,linespacing=1.18)
def box(x,y,w,h,s,fc='#F6F8FA',ec=edge,fs=9):
    canvas.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0,rounding_size=1.0',
        linewidth=.7,facecolor=fc,edgecolor=ec,zorder=1))
    txt(x+w/2,y+h/2,s,fs=fs)
def arrow(points,color=edge,lw=.8):
    for a,b in zip(points[:-2],points[1:-1]):
        canvas.plot([a[0],b[0]],[a[1],b[1]],color=color,lw=lw,zorder=0)
    canvas.add_patch(FancyArrowPatch(points[-2],points[-1],arrowstyle='-|>',
        mutation_scale=7,lw=lw,color=color,zorder=0,shrinkA=0,shrinkB=0))

provenance=json.loads((HERE/'overview_inputs.provenance.json').read_text())
assert hashlib.sha256((HERE/'overview_inputs.npz').read_bytes()).hexdigest()==provenance['prepared_npz_sha256']
with np.load(HERE/'overview_inputs.npz',allow_pickle=False) as z:
    rgb,stereo,mono=(z[k] for k in ['left_rgb','stereo_disparity','mono_relative_depth'])
assert rgb.shape[:2]==stereo.shape==mono.shape==(752,1028)
assert np.isfinite(stereo).all() and np.isfinite(mono).all()

# Equal native-aspect image panels; no crop or display normalization of RGB.
axes=[];bars=[]
xs=[8,64.75,121.5];iw=40.5;ih=iw*752/1028;iy=72.5
items=[(rgb,None,'RGB pair (left shown)'),(stereo,'viridis','Frozen stereo disparity'),(mono,'cividis','Frozen monocular prior')]
for x,(arr,cmap,title) in zip(xs,items):
    ax=fig.add_axes([x/W,iy/H,iw/W,ih/H]);axes.append(ax)
    ax.imshow(arr,cmap=cmap,interpolation='none',aspect='equal')
    ax.set_axis_off();txt(x+iw/2,105.1,title,fs=9.5,weight='bold')
    if cmap:
        cbax=fig.add_axes([(x+4)/W,69.35/H,(iw-8)/W,1.55/H]);bars.append(cbax)
        sm=plt.cm.ScalarMappable(norm=Normalize(float(arr.min()),float(arr.max())),cmap=cmap)
        cb=fig.colorbar(sm,cax=cbax,orientation='horizontal',ticks=[float(arr.min()),float(arr.max())])
        cb.ax.set_xticklabels([f'{arr.min():.1f}',f'{arr.max():.1f}'])
        cb.ax.tick_params(labelsize=9,length=1.6,pad=1.3)
        cb.outline.set_linewidth(.4);cb.solids.set_rasterized(False);cb.solids.set_edgecolor('face')
txt(28.25,67.2,'Mirror, im0',fs=9)
txt(85,63.7,'scoring-grid pixels',fs=9)
txt(141.75,63.7,'relative scale',fs=9)

# The scorer group is a comparison set, not a fusion layer. Inputs are explicit.
box(5,44.5,162,15.5,'',fc='#FAFBFC')
txt(86,57.1,'SceneFlow-trained, then frozen scorers: each outputs $s$',fs=9.5,weight='bold')
txt(47,52.6,'RGB + stereo: shared by all',fs=9)
txt(132,52.6,'Mono: assisted scorers only',fs=9)
canvas.add_patch(FancyBboxPatch((46,45.2),120,5.2,boxstyle='round,pad=0,rounding_size=.7',
    linewidth=.5,facecolor='#F1F6F8',edgecolor='#A8BBC5',zorder=1))
for x,label,col in [(25,'Stereo-Err','#666666'),(64,'Stereo+Mono','#0072B2'),
                    (107,'Stereo+Mono+Disag','#009E73'),(148,'Base-Risk','#D55E00')]:
    txt(x,47.8,label,fs=9,color=col,weight='bold')
arrow([(28.25,64.4),(28.25,60)])
arrow([(85,60.75),(85,60)])
arrow([(162,72.5),(169,72.5),(169,47.8),(166,47.8)])

# Each scorer is processed independently. Nonlinear conversion precedes P4.
arrow([(5,44.5),(1.4,44.5),(1.4,36.5),(29,36.5)])
txt(13,38.6,'Raw',fs=9,weight='bold')
box(29,32,46,9,'Native projection of $s$\nRaw ordering')
arrow([(75,36.5),(78,36.5),(78,42.3),(155.5,42.3),(155.5,41)])
box(81,32,42,9,'CAL: own offset fit\nfor each scorer/run',fc='#FFF7E9',ec='#C6923F')
arrow([(102,32),(102,27)],color='#A77B34')

txt(16,29.1,'Matched',fs=9,weight='bold')
arrow([(1.4,36.5),(1.4,21.5),(5,21.5)])
box(5,16,32,11,'Radius conversion\n'+r'$h_q=\max(e^s-1,0)$')
box(42,16,30,11,'Native projection\n+ unit scaling: $h_0$')
box(77,16,32,11,'Offset + clipping\n'+r'$q_d=\max(h_0+\delta,0)$',fc='#FFF7E9',ec='#C6923F')
box(115,16,24,11,r'$r=q_d/a$'+'\n'+r'$a=\hat d+d_{\mathrm{offs}}$')
for a,b in [(37,42),(72,77),(109,115),(139,143)]:arrow([(a,21.5),(b,21.5)])
box(143,16,25,25,'Retain lowest\nρ fraction in\ncommon valid\ndomain\nSame frozen\nprediction',fc='#EFF5F8')
box(5,2.5,48,9,'EVAL ground truth',fc='#FAFAFA')
box(70,2.5,98,9,'Common valid domain + measured loss',fc='#EFF5F8')
arrow([(53,7),(70,7)])
arrow([(155.5,16),(155.5,11.5)])

fig.canvas.draw()
require_matplotlib_panel_alignment(fig,axes=axes,panel_ids=['rgb','stereo','mono'],
    row_groups=[['rgb','stereo','mono']],json_out=HERE/'study_overview.alignment.json',
    tolerance_pt=1.5,gutter_tolerance_pt=1.5,strict=True)
fig.savefig(OUT/'study_overview.pdf',dpi=600)
fig.savefig(OUT/'study_overview.svg',dpi=600)
fig.savefig(OUT/'study_overview.png',dpi=600)
plt.close(fig)
print('Wrote study_overview PDF/SVG/PNG at 170 x 110 mm; three original 1028 x 752 arrays.')
