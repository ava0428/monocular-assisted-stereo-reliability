"""Original-evaluation scene means, with raw and RA ranges shown separately.

Contract: show the raw concentration and the matched scene-mean direction across
all 19 directory groups, including adverse Mirror. This is a quantitative grid:
panel a establishes raw heterogeneity; panel b shows matched residual direction.
No per-scene intervals are estimated and no evaluation/bootstrap is performed.
"""
from pathlib import Path
import csv
import hashlib
import json
import statistics

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from mechanism_alignment import require_matplotlib_panel_alignment

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
SOURCE = ROOT / "results/canonical_summary/scene_metrics_19x45.csv"
OUT = ROOT / "manuscript/figures/round8"
OUT.mkdir(parents=True, exist_ok=True)
STEM = OUT / "scene_differences"
RUNS = ("20260910", "20260911", "20260912")

with SOURCE.open(encoding="utf-8", newline="") as handle:
    rows = list(csv.DictReader(handle))
lookup = {(row["scene"], row["method"]): row for row in rows}
scenes = sorted({row["scene"] for row in rows})
assert len(rows) == len(lookup) == 19 * 45
assert len(scenes) == 19
for scene in scenes:
    assert sum(row["scene"] == scene for row in rows) == 45

summary = []
for scene in scenes:
    item = {"scene": scene, "execution": "original evaluation", "rho": 0.80,
            "n_fixed_runs": 3, "frames": int(lookup[(scene, "Depth-Only")]["frames"])}
    for path, prefix in (("raw", "Raw"), ("matched_ra", "Rel-Analytic")):
        base = [float(lookup[(scene, f"{prefix}:r2_gate:{run}")]["absrel_80"]) for run in RUNS]
        stereo = [float(lookup[(scene, f"{prefix}:r1:{run}")]["absrel_80"]) for run in RUNS]
        delta = [b - s for b, s in zip(base, stereo)]
        item[f"{path}_base_mean"] = statistics.mean(base)
        item[f"{path}_stereo_mean"] = statistics.mean(stereo)
        item[f"{path}_base_minus_stereo_mean"] = statistics.mean(delta)
        for index, value in enumerate(delta):
            item[f"{path}_delta_seed{index}"] = value
    summary.append(item)

csv_path = HERE / "scene_differences.csv"
with csv_path.open("w", encoding="utf-8", newline="") as handle:
    writer = csv.DictWriter(handle, fieldnames=summary[0].keys())
    writer.writeheader()
    writer.writerows(summary)

raw = [item["raw_base_minus_stereo_mean"] * 1000 for item in summary]
matched = [item["matched_ra_base_minus_stereo_mean"] * 1000 for item in summary]
assert sum(value < 0 for value in matched) == 18
assert sum(value < 0 for value in raw) == 19
mirror_index = scenes.index("Mirror")
assert raw[mirror_index] < 0 < matched[mirror_index]
assert abs(raw[mirror_index] / 1000 - (-0.078067)) < 0.0000005
assert abs(matched[mirror_index] / 1000 - 0.000648) < 0.0000005

plt.rcParams.update({
    "font.family": "sans-serif", "font.sans-serif": ["Arial", "DejaVu Sans"],
    "font.size": 9, "axes.labelsize": 9, "xtick.labelsize": 9,
    "ytick.labelsize": 9, "svg.fonttype": "none", "pdf.fonttype": 42,
    "axes.linewidth": 0.7, "axes.spines.top": False,
    "axes.spines.right": False, "axes.spines.left": False,
})

# Both axes have exactly the same 98.75 mm plot height, giving 5.20 mm row pitch.
fig, axes = plt.subplots(1, 2, figsize=(174 / 25.4, 125 / 25.4), sharey=True)
fig.subplots_adjust(left=0.205, right=0.975, bottom=0.135, top=0.925, wspace=0.16)
color = "#D55E00"
limits = [(-83, 3), (-2.45, 0.95)]
ticks = [[-80, -60, -40, -20, 0], [-2, -1, 0, 0.5]]
for ax, values, panel, title, xlim, xticks in zip(
    axes, (raw, matched), ("a", "b"), ("Raw", "Matched RA"), limits, ticks
):
    assert min(values) > xlim[0] and max(values) < xlim[1]
    ax.axhspan(mirror_index - 0.47, mirror_index + 0.47, color="#FFF1E5", zorder=0)
    ax.set_axisbelow(True)
    ax.grid(axis="y", color="#E9E9E9", linewidth=0.5)
    ax.axvline(0, color="#616161", linewidth=0.8, zorder=1)
    ax.scatter(values, range(19), s=24, color=color, edgecolors="none", zorder=3)
    ax.set_xlim(xlim)
    ax.set_xticks(xticks)
    ax.set_ylim(18.5, -0.5)
    ax.set_yticks(range(19))
    ax.set_yticklabels(scenes)
    ax.tick_params(axis="y", length=0, pad=7)
    ax.tick_params(axis="x", length=3, color="#777777")
    ax.set_xlabel("ΔAbsRel × 10³", labelpad=6)
    negative_count = sum(value < 0 for value in values)
    ax.set_title(f"{title}: {negative_count}/19 negative", fontsize=10, pad=8)
    ax.text(0, 1.035, panel, transform=ax.transAxes, fontsize=11,
            fontweight="bold", ha="left", va="bottom")
axes[0].get_yticklabels()[mirror_index].set_fontweight("bold")
# Explicit positive sign distinguishes the matched panel's small adverse side.
axes[1].set_xticklabels(["−2", "−1", "0", "+0.5"])

fig.canvas.draw()
alignment = require_matplotlib_panel_alignment(
    fig, json_out=HERE / "scene_differences.alignment.json",
    tolerance_pt=1.5, gutter_tolerance_pt=1.5,
    require_panel_labels=True, strict=True,
)
fig.savefig(STEM.with_suffix(".pdf"), metadata={"Title": "Scene-wise Base-Risk minus Stereo-Err differences"})
fig.savefig(STEM.with_suffix(".svg"))
fig.savefig(STEM.with_suffix(".png"), dpi=600)
plt.close(fig)

provenance = {
    "source": SOURCE.relative_to(ROOT).as_posix(),
    "source_sha256": hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
    "execution": "original evaluation",
    "source_rows": len(rows), "scene_count": len(scenes), "configuration_count": 45,
    "source_field": "absrel_80", "retained_coverage": 0.80,
    "run_mapping": {f"seed{i}": run for i, run in enumerate(RUNS)},
    "method_mapping": {"Base-Risk": "r2_gate", "Stereo-Err": "r1"},
    "path_mapping": {"raw": "Raw", "matched RA": "Rel-Analytic"},
    "aggregation": "Use saved frame-aggregated scene risks; subtract matched scorer/run values, then average the three fixed run differences within each scene.",
    "order": "Same alphabetical order as Supplementary Table S8 in both panels.",
    "scene_order": scenes,
    "summary_csv": csv_path.name,
    "summary_csv_sha256": hashlib.sha256(csv_path.read_bytes()).hexdigest(),
    "display_multiplier": 1000,
    "horizontal_ranges": {"raw": limits[0], "matched_ra": limits[1]},
    "no_per_scene_intervals": True,
    "no_bootstrap_or_evaluation_executed": True,
    "matched_negative_count": sum(value < 0 for value in matched),
    "raw_negative_count": sum(value < 0 for value in raw),
    "sign_count_definition": "Signs of three-run-averaged scene means; no per-scene significance claim.",
    "mirror": summary[mirror_index],
    "cohort_mean_difference": {
        "raw": statistics.mean(raw) / 1000,
        "matched_ra": statistics.mean(matched) / 1000,
    },
    "figure_dimensions_mm": [174, 125],
    "plot_row_pitch_mm": 125 * (0.925 - 0.135) / 19,
    "alignment_verdict": alignment["verdict"],
    "figure_sha256": {
        ext: hashlib.sha256(STEM.with_suffix(ext).read_bytes()).hexdigest()
        for ext in (".pdf", ".svg", ".png")
    },
}
(HERE / "scene_differences.provenance.json").write_text(
    json.dumps(provenance, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"status": "PASS", "matched_negative_count": 18,
                  "mirror_raw": raw[mirror_index] / 1000,
                  "mirror_matched": matched[mirror_index] / 1000,
                  "alignment": alignment["verdict"]}, indent=2))
