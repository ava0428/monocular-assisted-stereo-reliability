# Scene differences figure

Question: how are the original raw and matched Base-Risk advantages distributed across the complete cohort?

The plot reads `results/canonical_summary/scene_metrics_19x45.csv`, field `absrel_80`. Its 855 rows cover all 19 scene-directory groups and all 45 configurations. The file is byte-identical to `data/scene_metrics_19x45.csv` in the existing S1 ZIP; see `scene_differences.s1_identity.json`. Differences use `r2_gate` minus `r1` with the same path and fixed run. The three run differences are averaged within each scene. Both panels use the alphabetical S8 order, with no exclusions.

`scene_differences.csv` contains the two methods' scene means, their difference, and all three actual run differences for both paths. `scene_differences.provenance.json` records source/output hashes, method/run mapping, aggregation and ranges. This is a saved-result reduction and plot export; no bootstrap, CAL fit, model inference or pixel evaluation was run.

## Checks actually completed

- Matched negative scene means: 18/19; Mirror is the sole positive mean. Mirror raw difference: -0.0780674636726596; matched RA difference: +0.0006479978367166193.
- All 19 scene means lie inside each panel's displayed range. The shared row order and independent ranges are explicit; no line connects the panels.
- Export is 174 × 125 mm; text is 9–11 pt and row pitch is 5.197 mm. At 164 mm manuscript width, smallest text is about 8.48 pt and row pitch about 4.90 mm.
- Rendered alignment PASS; PDF text audit minimum 9 pt; collision audit PASS, zero fails or warnings.
- Both panels and the complete PNG were visually inspected: scene labels, orange points, zero lines, Mirror highlight, units and panel headings are clear with no overlaps or cropping.
- Source audit: no failures. Three warnings were reviewed: TIFF is unnecessary for this vector point plot (PDF/SVG delivered, PNG600 preview); the width detector misreads the explicit `174 / 25.4` expression (actual PDF width is 174 mm); no error bars are intentional because the request specifies actual scene means, not per-scene confidence intervals.

## Suggested caption

Scene-wise Base-Risk minus Stereo-Err differences at rho = 0.80 in the original evaluation. Each point is a scene mean after averaging the three fixed runs, using raw ordering in (a) and matched RA ordering in (b). The panels share the same scene order and use different horizontal ranges; negative values favour Base-Risk. Eighteen of the nineteen matched scene means are negative, while Mirror reverses direction. The points do not represent per-scene confidence intervals. Values are drawn from the unrounded records underlying Supplementary Table S8.

## Rebuild

Run `python analysis_round8/plot_scenes.py` from the editable-source root with matplotlib installed. The bundled alignment helper is imported from the same folder. Output is written to `manuscript/figures/round8/scene_differences.{pdf,svg,png}`; regenerated summary and provenance remain beside the script.
