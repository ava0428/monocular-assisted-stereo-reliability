"""Render the synthetic ordering mechanism and saved offset-path contrasts.

This is a display-only entry: no model call, calibration fit or bootstrap.
Run with Python from any directory. The synthetic panel is explicitly labelled;
all empirical values are read at their saved precision, never from PDF tables.
"""
from pathlib import Path
import csv
import hashlib
import json

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from mechanism_alignment import require_matplotlib_panel_alignment


HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
OUT = ROOT / "manuscript" / "figures" / "round8"
BASE = OUT / "mechanism_offset"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    path_source = ROOT / "analysis_round3" / "execution_consistency.json"
    change_source = ROOT / "analysis_round5" / "paired_change.json"
    saved = json.loads(path_source.read_text(encoding="utf-8"))
    paths = {p["rule"]: p for p in saved["construction_paths"]}
    changes = json.loads(change_source.read_text(encoding="utf-8"))
    change = next(r for r in changes if r["execution"] == "additional"
                  and r["metric"] == "absrel_80")
    assert saved["bootstrap"]["replicates"] == 10000
    assert saved["bootstrap"]["CAL_refitted"] is False
    assert change["CAL_fixed"] is True and change["total_scenes"] == 19
    assert np.isclose(paths["h0/a"]["delta"], change["before_mean_delta"], rtol=0, atol=1e-17)
    assert np.isclose(paths["qd/a"]["delta"], change["after_mean_delta"], rtol=0, atol=1e-17)
    for p in paths.values():
        assert np.isclose(p["relative_reduction_percent"],
                          -100 * p["delta"] / p["stereo_mean"], rtol=0, atol=1e-12)
    # C is read from the direct paired-change result, not recomputed from paths.
    rows = []
    for key in ("h0/a", "qd/a"):
        p = paths[key]
        rows.append(dict(execution="additional", comparison="Base-Risk minus Stereo-Err",
                         path=key, rho=.80, tau=.90 if key == "qd/a" else "not applicable",
                         estimate=p["delta"], ci_low=p["ci_low"], ci_high=p["ci_high"],
                         stereo_mean=p["stereo_mean"], base_mean=p["base_mean"],
                         relative_reduction_percent=p["relative_reduction_percent"],
                         scene_count=19, fixed_runs=3, saved_CAL_fixed=True,
                         source="analysis_round3/execution_consistency.json#construction_paths"))
    rows.append(dict(execution="additional", comparison="direct paired change C", path="qd/a minus h0/a",
                     rho=.80, tau=.90, estimate=change["change_in_delta"],
                     ci_low=change["ci_low"], ci_high=change["ci_high"],
                     stereo_mean="", base_mean="", relative_reduction_percent="",
                     scene_count=19, fixed_runs=3, saved_CAL_fixed=True,
                     source="analysis_round5/paired_change.json#additional,absrel_80"))
    with (HERE / "mechanism_offset_summary.csv").open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    with (HERE / "mechanism_synthetic.csv").open("w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["data_identity", "pixel", "h0_native_px", "a_native_px", "delta_native_px", "score"])
        for pixel, h0, a in (("A", 1, 10), ("B", 8, 40)):
            for delta in (0., 4./3., 4., 4.5):
                writer.writerow(["synthetic illustration", pixel, h0, a, delta, (h0 + delta) / a])

    plt.rcParams.update({
        "font.family": "sans-serif", "font.sans-serif": ["Arial", "DejaVu Sans"],
        "font.size": 9.2, "axes.labelsize": 9.2, "xtick.labelsize": 9.1,
        "ytick.labelsize": 9.1, "pdf.fonttype": 42, "svg.fonttype": "none",
        "axes.spines.top": False, "axes.spines.right": False,
        "axes.linewidth": .7, "savefig.dpi": 600, "mathtext.fontset": "dejavusans",
    })
    width_mm, height_mm = 174, 95
    fig = plt.figure(figsize=(width_mm / 25.4, height_mm / 25.4))
    gs = fig.add_gridspec(1, 2, left=.105, right=.975, bottom=.30, top=.80, wspace=.40)
    a, b = [fig.add_subplot(gs[0, i]) for i in range(2)]
    for ax, panel in zip((a, b), ("a", "b")):
        ax.text(-.10, 1.24, panel, transform=ax.transAxes, fontsize=10.5, fontweight="bold")
    a.text(0, 1.24, "Offset changes score order", transform=a.transAxes, fontsize=10)
    a.text(0, 1.115, "Synthetic illustration", transform=a.transAxes, fontsize=9.2, color="#555555")
    a.text(0, 1.025, "Offset shared across pixels within a scorer", transform=a.transAxes,
           fontsize=9.2, color="#555555")
    b.text(0, 1.24, "Observed between-scorer gap", transform=b.transAxes, fontsize=10)
    b.text(0, 1.115, r"Additional re-evaluation; $\rho=0.80$", transform=b.transAxes, fontsize=9.2, color="#555555")

    delta = np.linspace(0, 4.5, 181)
    blue, gray, orange = "#2879AD", "#666666", "#D87923"
    a.plot(delta, (1 + delta) / 10, color=blue, linewidth=1.5)
    a.plot(delta, (8 + delta) / 40, color=gray, linestyle="--", linewidth=1.5)
    a.plot([0, 4], [.1, .5], "o", color=blue, markersize=4, clip_on=False)
    a.plot([0, 4], [.2, .3], "s", color=gray, markersize=4, clip_on=False)
    a.scatter([4 / 3], [7 / 30], color="white", edgecolors="#333333", s=22, zorder=5)
    a.text(.22, .555, r"A: $h_0=1,\ a=10$", color=blue, fontsize=9.2)
    a.text(.22, .485, r"B: $h_0=8,\ a=40$", color=gray, fontsize=9.2)
    a.annotate(r"$\delta=4/3$", xy=(4 / 3, 7 / 30), xytext=(1.9, .09),
               fontsize=9.2, arrowprops=dict(arrowstyle="-", color="#777777", linewidth=.7))
    a.set(xlim=(-.08, 4.5), ylim=(0, .6), xticks=[0, 1, 2, 3, 4],
          yticks=[0, .1, .2, .3, .4, .5, .6],
          xlabel=r"Offset $\delta$ (native disparity px)",
          ylabel="Relative-depth score (dimensionless)")
    a.text(.5, -.42, r"$r(\delta)=(h_0+\delta)/a$; lower scores rank first",
           transform=a.transAxes, ha="center", fontsize=9.2)

    b.axvline(0, color="#777777", linewidth=.8, linestyle=":")
    for y, key, label, marker in ((.77, "h0/a", r"Zero offset $h_0/a$", "o"),
                                 (.36, "qd/a", r"Fitted offset $q_d/a$ ($\tau=0.90$)", "s")):
        p = paths[key]
        mean, low, high = (1000 * p[k] for k in ("delta", "ci_low", "ci_high"))
        b.errorbar(mean, y, xerr=[[mean - low], [high - mean]], fmt=marker,
                   color=orange, elinewidth=1.5, markersize=5, capsize=3, capthick=1)
        b.text(-10, y + .13, label, fontsize=9.2, va="center")
        b.text(-10, y - .14, f'{p["relative_reduction_percent"]:.2f}% lower mean risk',
               color="#555555", fontsize=9.2, va="center")
    b.set(xlim=(-10, 1), ylim=(0, 1), xticks=[-10, -8, -6, -4, -2, 0], yticks=[],
          xlabel="Base-Risk − Stereo-Err\nΔAbsRel × 10³")
    b.xaxis.labelpad = 3
    b.spines["left"].set_visible(False)
    b.tick_params(axis="y", length=0)
    b.text(.5, -.36, r"$C=\Delta_{q_d/a}-\Delta_{h_0/a}$ (×10³)", transform=b.transAxes,
           ha="center", fontsize=11)
    b.text(.5, -.46, f'+{1000*change["change_in_delta"]:.4f} '
           f'[{1000*change["ci_low"]:+.4f}, {1000*change["ci_high"]:+.4f}]',
           transform=b.transAxes, ha="center", fontsize=9.2)
    b.text(.5, -.56, "Positive values indicate attenuation.", transform=b.transAxes,
           ha="center", fontsize=9.2, color="#555555")
    fig.canvas.draw()
    require_matplotlib_panel_alignment(
        fig, json_out=BASE.with_suffix(".alignment.json"),
        overlay_svg=BASE.with_suffix(".alignment.svg"), tolerance_pt=1.5,
        gutter_tolerance_pt=1.5, require_panel_labels=True, strict=True,
    )
    fig.savefig(BASE.with_suffix(".pdf"))
    fig.savefig(BASE.with_suffix(".svg"))
    fig.savefig(BASE.with_suffix(".png"), dpi=600)
    plt.close(fig)
    provenance = {
        "claim": "A common additive offset can reverse relative-depth order; the saved additional paths show a smaller Base-Risk–Stereo-Err gap after fitted offsets.",
        "archetype": "schematic-led composite", "size_mm": [174, 95],
        "panel_a": {"identity": "synthetic illustration", "equation": "r=(h0+delta)/a",
                    "A": {"h0": 1, "a": 10}, "B": {"h0": 8, "a": 40},
                    "delta_range": [0, 4.5], "intersection_delta": 4 / 3},
        "panel_b": {"execution": "additional", "rho": .8, "tau": .9,
                    "unit": "19 scene-directory groups after averaging three fixed runs within scene",
                    "interval": "existing 10000 paired scene-group resamples, unadjusted 95% descriptive percentile intervals",
                    "CAL": "saved fits fixed", "C": "Delta_(qd/a) minus Delta_(h0/a), read from the direct saved paired within-scene change; positive values indicate attenuation; not subtraction of marginal CI endpoints"},
        "sources": [{"path": str(p.relative_to(ROOT)).replace("\\", "/"), "sha256": sha(p)}
                    for p in (path_source, change_source)],
        "outputs": [{"path": str(BASE.with_suffix("." + ext).relative_to(ROOT)).replace("\\", "/"),
                     "sha256": sha(BASE.with_suffix("." + ext))} for ext in ("pdf", "svg", "png")],
        "new_model_forwards": 0, "new_CAL_fits": 0, "new_bootstrap_resamples": 0,
    }
    (HERE / "mechanism_provenance.json").write_text(json.dumps(provenance, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps({"figure": str(BASE), "saved_empirical_rows": len(rows), "status": "rendered"}))


if __name__ == "__main__":
    main()
