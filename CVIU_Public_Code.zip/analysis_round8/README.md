# Round8 display figures

Run the existing Python/NumPy/Matplotlib environment from the editable-source root:

```
python analysis_round8/plot_overview.py
python analysis_round8/plot_mechanism.py
python analysis_round8/plot_scenes.py
```

These scripts read supplied arrays and saved summaries; none runs model inference, CAL fitting, native evaluation or bootstrap. They write PDF/SVG/PNG figures to manuscript/figures/round8. The supplied alignment helpers are used for layout checks.

|Figure|Question|Exact display source|
|---|---|---|
|1, overview|Which frozen inputs and processing paths are compared?|overview_inputs.npz: real Mirror/im0 RGB, stereo disparity in scoring-grid pixels, mono prior in relative scale; provenance hashes and source mapping in overview_inputs.provenance.json|
|3, mechanism/offset|How can a common radius offset reorder relative scores, and how does the saved between-scorer gap change?|Synthetic pixel A/B equations are labelled and exported to mechanism_synthetic.csv; empirical estimates/intervals/percentages from analysis_round3/execution_consistency.json and direct C from analysis_round5/paired_change.json; full-precision rows in mechanism_offset_summary.csv|
|5, all19scenes|How are raw and matched differences distributed?|results/canonical_summary/scene_metrics_19x45.csv, byte-identical to S1 source; same-path same-run Base minus Stereo averaged within scene, all19 groups; scene_differences.csv retains means and three run differences|

Negative Δ favours Base-Risk. Positive C means the negative advantage is attenuated. Figure3 uses the additional execution; Figure5 the original. C is read directly with its saved interval; no marginal-interval subtraction is used. The scene plot creates no scene-specific intervals. Both plot scales use ΔAbsRel×10³; SI S16 uses×10⁴.

Figures2,4,6 are byte-identical to the prior contrast, coverage and pixel-case files in manuscript/figures/structural. Main Table3 is now the previous geometric-comparator table; exact offset-path risks/run SDs remain SI S11.

The new scripts were actually run from a fresh editable-source ZIP extraction. Summary CSVs and rendered figure pixels matched. Both manuscript PDFs compiled from that extracted source and matched delivered page text/rendering. This checks display/build portability within the recorded local runtime, not a clean-host full raw pipeline.
