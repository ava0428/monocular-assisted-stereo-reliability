# Mechanism and offset-path figure

This figure connects a synthetic ordering mechanism to the saved contraction of the Base-Risk–Stereo-Err gap. Panel a explains how the denominator makes a common radius offset capable of changing score order; panel b reports the additional re-evaluation, not the original raw→RA comparison.

## Entry and data

Run `python analysis_round8/plot_mechanism.py` from the source-package root (or call the script by full path). NumPy and Matplotlib are required; the copied `mechanism_alignment.py` is the render-time layout checker.

- `analysis_round3/execution_consistency.json`, `construction_paths`: unchanged full-precision path-specific differences, descriptive intervals, cohort means and percentage denominators.
- `analysis_round5/paired_change.json`, additional execution / `absrel_80`: unchanged directly paired change C and interval. The C interval is not derived from the two displayed path intervals.
- `mechanism_offset_summary.csv`: three full-precision empirical records; the last row is C, distinct from a between-scorer contrast under one path.
- `mechanism_synthetic.csv`: explicitly synthetic pixel parameters and selected score values. It is an equation illustration, not a saved experiment.
- `mechanism_provenance.json`: input/output SHA-256 and data identity.

No model forward, CAL fit, EVAL sorting or bootstrap is run by this plotting entry. C is read from the saved direct paired result. The existing percent reductions are checked against each path's Stereo-Err mean; they are not additive causal contributions.

## Final export checks

PDF/SVG/PNG are `manuscript/figures/round8/mechanism_offset.*` at 174 × 95 mm; PNG is 600 dpi. Text is editable, with embedded TrueType fonts in the PDF. The manuscript integration width of 164 mm gives a scale of 0.94253; ordinary labels/ticks are at least 8.58 pt after this scale. PDF math subscripts are 6.44 pt before scaling (6.07 pt after scaling).

- Rendered panel alignment: PASS, both plot areas have matching top/bottom edges and height.
- Source preflight: 0 FAIL, 2 reviewed WARNs. PNG is a preview alongside the requested vector PDF/SVG, so no TIFF is needed for this wholly vector figure. The static checker cannot infer the variable-based figure size; the PDF itself measures 174 × 95 mm.
- Rendered PDF text: PASS, minimum glyph 6.44 pt, no glyph below 5 pt.
- Rendered collision audit: PASS, 0 FAIL, 0 WARN; seven contained fill overlays are mathematical text elements/markers, visually inspected.
- Panel-by-panel visual inspection: PASS. Synthetic endpoint markers at delta=0 are fully visible; crossing is at 4/3. Both observed negative intervals remain left of the zero line. C is separate below the plot and has 7.47 pt clearance from the page bottom.
- Panel a carries no sampling uncertainty because it is a deterministic mathematical illustration. Panel b uses the existing 19 scene groups after three fixed runs are averaged within scene, with the saved 10,000 paired scene-group resamples and fixed CAL fits.

## Suggested caption

Additive offsets and relative-depth selection. (a) A two-pixel schematic illustrates how adding a common disparity-radius offset before division by pixel-dependent a can reverse the score order. The values are synthetic; h0, a and delta are in native disparity pixels. (b) Base-Risk minus Stereo-Err AbsRel differences for zero-offset and fitted-offset relative-depth orderings in the additional re-evaluation at rho=0.80. Negative differences favour Base-Risk. The percentages use Stereo-Err under the same path as their denominator. Points average the three fixed runs within each scene and then the 19 scene groups; bars show unadjusted 95% descriptive percentile intervals from the existing 10,000 paired scene-group resamples, conditional on saved CAL fits. The separately reported paired change C is computed directly from within-scene changes; positive C indicates attenuation. Full numerical results are in Supplementary Tables S11 and S16.
