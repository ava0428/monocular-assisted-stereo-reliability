from pathlib import Path
import json
H=Path(__file__).resolve().parent;A=H.parent
def load(p):return json.loads(p.read_text(encoding="utf-8"))
def out(n,x):(H/n).write_text(json.dumps(x,indent=2)+"\n")
contrasts=load(H/"paired_change.json");summary=load(H/"cal_cluster_summary.json")["summaries"]
# Derived percentages retain their explicitly different references.
co=load(A/'analysis_round3/execution_consistency.json');b=next(r['original_mean'] for r in co['cohort_means'] if r['family']=='r2_gate' and r['metric']=='absrel_80');depth=load(A/'results/canonical_summary/cohort_metrics.json')['rows']['Depth-Only']['absrel_80'];pct=100*(depth-b)/depth
out('reference_percentages.json',{'Base_vs_DepthOnly_percent':pct,'Base_original_matched_AbsRel80':b,'DepthOnly_AbsRel80':depth})
ls=[r'\begin{supplementtable}\centering\small',r'\caption{Paired change in the Base-Risk minus Stereo-Err contrast, after minus before processing. Positive values indicate attenuation of a negative Base-Risk advantage. Point estimates and 95\% descriptive paired-scene intervals are scaled by $10^4$. Runs are averaged within scene before the same 10,000 scene resamples; CAL fits are held fixed.}\label{tab:paired_change}',r'\begin{tabular}{llrr}\toprule Evaluation / path & Metric & Change $\times10^4$ & 95\% interval $\times10^4$\\\midrule']
for x in contrasts:ls.append(('Original: raw to RA' if x['execution']=='original' else r'Additional: $h_0/a$ to $q_d/a$')+' & '+('AbsRel@0.80' if x['metric']=='absrel_80' else 'AbsRel@0.90')+f" & {x['change_in_delta']*1e4:+.3f} & [{x['ci_low']*1e4:+.3f}, {x['ci_high']*1e4:+.3f}]"+r'\\')
ls+=[r'\bottomrule\end{tabular}\end{supplementtable}'];(H/'paired_change_table.tex').write_text('\n'.join(ls)+'\n')
ls=[r'\begin{supplementtable}\centering\small',r'\caption{CAL directory-group bootstrap at $\tau=0.90$: 2,000 shared resamples of 19 whole groups for Stereo-Err and Base-Risk. Offsets use native disparity pixels. Both numeric columns report median [P2.5, P97.5], where P2.5 and P97.5 are the 2.5th and 97.5th percentiles of the bootstrap distribution. OOB coverage uses omitted CAL groups and their original 8,192 sampled pixels per group; its distribution is not a confidence interval for independent-cohort performance. No EVAL risk was recomputed.}\label{tab:cal_cluster}',r'\begin{tabular}{llrr}\toprule Scorer & Run & Offset median [P2.5, P97.5] (px) & OOB radius coverage (\%)\\\midrule']
for x in summary:ls.append(('Stereo-Err' if x['family']=='r1' else 'Base-Risk')+f" & seed{x['seed']-20260910} & {x['delta_median']:.2f} [{x['delta_p025']:.2f}, {x['delta_p975']:.2f}] & {100*x['oob_coverage_median']:.2f} [{100*x['oob_coverage_p025']:.2f}, {100*x['oob_coverage_p975']:.2f}]"+r'\\')
ls+=[r'\bottomrule\end{tabular}\end{supplementtable}'];(H/'cal_cluster_table.tex').write_text('\n'.join(ls)+'\n')
macros={'BaseDepthPct':f'{pct:.2f}'}
for x in contrasts:
 key=('Raw' if x['execution']=='original' else 'Offset')+('Eighty' if x['metric']=='absrel_80' else 'Ninety')
 for f,suff in [('change_in_delta','Change'),('ci_low','Low'),('ci_high','High')]:macros[key+suff]=f"{x[f]:+.6f}"
(H/'display_macros.tex').write_text('\n'.join('\\newcommand{\\'+k+'}{'+v+'}' for k,v in macros.items())+'\n')
print(json.dumps({'paired_change':contrasts,'CAL_summary':summary,'BaseDepthPercent':pct},indent=2))
