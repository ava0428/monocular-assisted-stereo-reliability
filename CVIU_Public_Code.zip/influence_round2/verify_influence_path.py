"""2026-10-20 targeted CPU reductions; saved matrices only, no refit/inference.

Run: python influence_round2/verify_influence_path.py (from author_source).
The source matrix stores frame means per scene/configuration. Fixed runs are
averaged within each scene before the preserved paired scene bootstrap.
"""
from pathlib import Path
import ast
import csv
import hashlib
import json
import math
import numpy as np

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
CAN = ROOT / 'results/canonical_summary'
SUP = ROOT / 'review_support'

def rows(path):
    with path.open(encoding='utf-8') as handle:
        return list(csv.DictReader(handle))

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

matrix_path = CAN / 'scene_metrics_19x45.csv'
records = rows(matrix_path)
scenes = sorted({r['scene'] for r in records})
methods = sorted({r['method'] for r in records})
lookup = {(r['scene'], r['method']): r for r in records}
assert len(scenes) == 19 and len(methods) == 45
assert len(records) == len(lookup) == 855
assert set(lookup) == {(s, m) for s in scenes for m in methods}
assert all(np.isfinite(float(r['absrel_80'])) for r in records)
assert len({(s, int(lookup[s, m]['frames'])) for s in scenes for m in methods}) == 19
assert sum(int(lookup[s, methods[0]]['frames']) for s in scenes) == 108

preserved = SUP / 'sources/scripts/analyze_jise_exact_unified_v1.py'
node = next(n for n in ast.parse(preserved.read_text(encoding='utf-8')).body
            if isinstance(n, ast.FunctionDef) and n.name == 'paired_bootstrap')
scope = {'np': np}
exec(compile(ast.Module(body=[node], type_ignores=[]), str(preserved), 'exec'), scope)
bootstrap = scope['paired_bootstrap']
indices = np.random.default_rng(20260913).integers(0, 19, size=(10000, 19))
saved_bootstrap = rows(CAN / 'pair_bootstrap_10000.csv')
runs = (20260910, 20260911, 20260912)
exclude = {'Door', 'Mirror', 'Tablet'}
keep = np.array([s not in exclude for s in scenes])

def values(method):
    return np.array([float(lookup[s, method]['absrel_80']) for s in scenes])

ddcv = values('DDCV')
base = np.array([values(f'Rel-Analytic:r2_gate:{r}') for r in runs])
exact = values('Depth-Exact:r2_gate:20260910')[None, :]

def contrast(name, vals, saved_left, seed_scope):
    difference = vals - ddcv[None, :]
    scene_diff = difference.mean(axis=0)
    actual = bootstrap(difference, indices)
    matches = [r for r in saved_bootstrap if r['left'] == saved_left
               and r['right'] == 'DDCV' and r['seed_scope'] == seed_scope
               and r['metric'] == 'absrel_80']
    assert len(matches) == 1, (name, len(matches))
    saved = matches[0]
    for key in ('delta', 'ci_low', 'ci_high'):
        assert math.isclose(actual[key], float(saved[key]), rel_tol=5e-13, abs_tol=1e-14)
    return {
        'left': name, 'right': 'DDCV-LR', 'metric': 'AbsRel@0.80',
        'run_count': len(vals), 'direction': 'left minus DDCV-LR; negative favours left',
        'scene_mean_delta': actual['delta'], 'scene_median_delta': float(np.median(scene_diff)),
        'negative_scene_count': int((scene_diff < 0).sum()),
        'positive_scene_count': int((scene_diff > 0).sum()),
        'zero_scene_count': int((scene_diff == 0).sum()),
        'negative_scenes': [s for s, d in zip(scenes, scene_diff) if d < 0],
        'excluded_scenes': sorted(exclude), 'remaining_scene_count': int(keep.sum()),
        'remaining_scene_mean_delta': float(scene_diff[keep].mean()),
        'descriptive_95_interval': [actual['ci_low'], actual['ci_high']],
        'interval_crosses_zero': actual['ci_low'] < 0 < actual['ci_high'],
        'saved_bootstrap_record_agrees': True,
        'scene_differences': [{'scene': s, 'delta': float(d)} for s, d in zip(scenes, scene_diff)],
    }

contrasts = [contrast('Base-Risk RA', base, 'Rel-Analytic:r2_gate:{seed}',
                      'FIXED_3_SEED_MEAN_WITHIN_SCENE'),
             contrast('Depth-Exact seed0', exact, 'Depth-Exact:r2_gate:20260910', '20260910')]

path = {}
fixed = {r['method_group']: r for r in rows(CAN / 'fixed_seed_means.csv')}
for label, prefix in [('Raw', 'Raw:r2_gate'), ('Disp-Cal', 'DispCal:r2_gate'),
                      ('RA', 'Rel-Analytic:r2_gate')]:
    array = np.array([values(f'{prefix}:{r}') for r in runs])
    run_means = array.mean(axis=1)
    mean = float(run_means.mean())
    assert math.isclose(mean, float(fixed[prefix]['absrel_80']), rel_tol=5e-13, abs_tol=1e-14)
    path[label] = {'mean_absrel_80': mean, 'sample_sd': float(run_means.std(ddof=1)),
                   'run_means': run_means.tolist(), 'scene_means': array.mean(axis=0).tolist()}
path['differences'] = {
    'Disp-Cal minus Raw': path['Disp-Cal']['mean_absrel_80'] - path['Raw']['mean_absrel_80'],
    'RA minus Disp-Cal': path['RA']['mean_absrel_80'] - path['Disp-Cal']['mean_absrel_80'],
    'RA minus Raw': path['RA']['mean_absrel_80'] - path['Raw']['mean_absrel_80'],
}

fit_path = SUP / 'sources/outputs/jise_numeric_close_v1_synced_20261005/cal_fits_20261005.json'
fit_records = json.loads(fit_path.read_text(encoding='utf-8'))['fits']
identities = {r['path']: r['sha256'] for r in json.loads((SUP / 'source_identity.json').read_text(encoding='utf-8'))}
for source_path in (fit_path, preserved):
    assert digest(source_path) == identities[source_path.relative_to(SUP / 'sources').as_posix()]
fits = [r for r in fit_records if r['family'] in {'r1', 'r2_concat', 'r2_dis', 'r2_gate'}]
assert len(fits) == 12 and len({(r['family'], r['seed']) for r in fits}) == 12
desc_path = CAN / 'calibration_descriptives.json'
descs = json.loads(desc_path.read_text(encoding='utf-8'))['cohort_descriptions']
desc_lookup = {r['family_seed']: r for r in descs}
for row in fits:
    assert row['tau'] == .9 and row['n'] == 155648 and row['k'] == 140085
    assert row['delta'] > 0
    original = desc_lookup[f"{row['family']}:{row['seed']}"]
    assert row['delta'] == original['delta_native_disparity_px']
    assert original['calibrated_zero_count_total'] == 0
delta = {'count': 12, 'all_positive': True, 'unit': 'native disparity px',
         'min': min(r['delta'] for r in fits), 'max': max(r['delta'] for r in fits),
         'fits_equal_saved_calibration_descriptives': True,
         'recorded_calibrated_zero_count_all_fits': 0, 'records': fits}
inputs = [matrix_path, CAN / 'pair_bootstrap_10000.csv', CAN / 'fixed_seed_means.csv',
          preserved, fit_path, desc_path]
result = {
    'status': 'PASS_SAVED_MATRIX_CPU_CHECK', 'date': '2026-10-20',
    'scope': 'Existing unrounded frame-mean scene summaries; no pixel reevaluation, inference or CAL refit.',
    'metric': 'AbsRel@0.80; dimensionless',
    'aggregation': 'frame mean within scene already stored; scene equal; fixed runs averaged within scene',
    'bootstrap': {'replicates': 10000, 'generator': 'numpy.default_rng', 'seed': 20260913,
                  'scene_order': scenes, 'CI': 'percentile 2.5/97.5, descriptive, unadjusted',
                  'CAL_refit_uncertainty_included': False},
    'matrix_complete': {'scenes': 19, 'methods': 45, 'rows': 855, 'frames_per_method': 108},
    'external_contrasts': contrasts, 'base_risk_path': path, 'positive_deltas': delta,
    'input_identity': [{'path': str(p.relative_to(ROOT)).replace('\\', '/'), 'sha256': digest(p)}
                       for p in inputs],
    'scientific_limits': [
        'Three-scene exclusion is a post-hoc influence diagnostic; the main 19-scene cohort is unchanged.',
        'Base-Risk paths are conditional comparisons, not order-independent causal contribution fractions.',
        'Positive delta and h0 >= 0 imply qd=h0+delta and RA/delta=1/a+h0/(delta*a) in real arithmetic.',
        'Floating-point neighbouring scores can coalesce into ties; real-arithmetic monotonicity is not bitwise rank equality.',
        'Median radius share does not establish uniform small numerator variation or a performance-attribution ratio.'
    ],
}
(HERE / 'influence_and_path_results.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'status': result['status'], 'contrasts': [{k: v for k, v in c.items() if k != 'scene_differences'} for c in contrasts],
                  'path': {k: v for k, v in path.items() if k == 'differences'},
                  'path_means': {k: path[k]['mean_absrel_80'] for k in ('Raw', 'Disp-Cal', 'RA')},
                  'delta_range': [delta['min'], delta['max']]}, indent=2))
