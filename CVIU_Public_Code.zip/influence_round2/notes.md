# 本轮保存结果的场景影响与Base-Risk处理路径复核

2026-10-20；只读canonical并写本目录，未推理、未拟合CAL、未修改历史结果。CPU命令（在`author_source/`）：

```powershell
python influence_round2/verify_influence_path.py
```

已实际执行通过，完整未舍入输出为`influence_and_path_results.json`。输入SHA在JSON中；855条19×45组合完整，每配置对应108帧。先沿用保存的帧均值到场景值，再在场景内平均固定runs，19场景等权；原保存bootstrap函数、sorted scene顺序、NumPy default_rng(20260913)、10000次成对重采样不变。重算区间与`pair_bootstrap_10000.csv`对应原行吻合，未由表格显示值推断。

## 外部比较器异质性（AbsRel@0.80；left−DDCV-LR）

|left|19场景平均差|场景差中位数|负场景|删Door/Mirror/Tablet后16场景平均差|原政策95%描述性区间|
|---|---:|---:|---:|---:|---|
|Base-Risk RA（场景内三run均值）|−0.02189784914763141|+0.002738451644884402|5/19|+0.001603541438657123|[−0.050508503604285965, +0.000603059468358530]|
|Depth-Exact seed0|−0.021408881590249434|+0.003341802189384842|5/19|+0.002094274500423886|[−0.05010780402257561, +0.001162225419845307]|

两者有利场景均为Bottle、Door、Fridge、Mirror、Tablet，其余14个为正，无零差。均值有利并非多数场景优势；两条区间都跨零。删三场景为新增post-hoc影响诊断，不更换主队列，也不解释为材料区域机制。JSON保存19个逐场景差，不只呈现被排除组。

## Base-Risk路径（固定三run、19场景、AbsRel@0.80）

|处理|未舍入mean|
|---|---:|
|Raw|0.06111065076779327|
|Disp-Cal|0.061043174904879594|
|RA|0.020983544574501165|

- Disp-Cal−Raw = −0.00006747586291367541；正确六位显示是 **−0.000067**。
- RA−Disp-Cal = −0.04005963033037843；正确六位显示是 **−0.040060**。
- RA−Raw = −0.0401271061932921。

与用户从已舍入表格得到的−0.000068/−0.040059差异仅为先舍入再相减，不是真实结果错误。不能改源值迎合参考值；正文可用约`−6.75×10^-5`与`−0.04006`避免误读。三个路径均值已对照保存`fixed_seed_means.csv`通过。

执行源码证据：保存`review_support/sources/scripts/jise_exact_unified_eval_v1.py`第246–268行：raw直接投影，随后同一`q=max(0,base+delta)`供DispCal与Rel-Analytic使用；DispCal风险为q，Rel-Analytic调用`abs_rel_radius_bound(d,q,doffs)`。后者保存`src/taskspace/geometry.py`约150–185行在正有限分母上返回q/(d+doffs)。因此可以比较已校准半径给定后的除分母步骤；raw到Disp-Cal同时包含非线性前后投影差异，不能说只是加delta。差额是本路径、本指标的条件比较，不是四family机制证明或顺序无关因果比例。

## 12个正delta

读取实际保存fit文件`review_support/sources/outputs/jise_numeric_close_v1_synced_20261005/cal_fits_20261005.json`，验证其SHA与`source_identity.json`一致；选4个central families×3runs，均tau=.90、n155648、k140085。12个delta与canonical `calibration_descriptives.json`逐项数值完全相等，范围为 **76.24690341317115–79.99153072309447 native disparity px**，全部为正；记录的校准后零半径计数均0。

结合h0≥0，实数算术下qd=h0+delta，且RA/delta=1/a+h0/(delta·a)。本次12配置的截零不激活；加同一正常数在实数上保序，但有限精度可能产生并列，未在此复核像素级逐位排序。不能把0.95–0.96中位radius份额推广到每像素或解释为性能贡献比例。

## CQR及标题边界

当前原文CQR关联仍准确：对称端点非一致度代数对应e−h0；训练目标不是条件分位，未主张EVAL覆盖定理。本轮没有新增CQR文献核验或改变其引用。上述汇总路径解释没有将校准/插值/非线性分别干预，因此默认标题用`The Role of Score Processing and Coverage`更准确；是否另有新像素对照由主任务单独记录。
