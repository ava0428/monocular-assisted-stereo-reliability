# Public materials access and scope

Read README.md and THIRD_PARTY_NOTICES.md first. All entries below use saved
results or explicitly requested diagnostics; none implies a complete raw-data
model/pixel re-evaluation.

| Public payload | Entry from its extraction | Scope |
|---|---|---|
| CVIU_S1_Original_Evaluation.zip | `python reproduce.py --out NEW_DIRECTORY --plots` | Saved original scene/segment reductions and paired descriptive intervals |
| CVIU_S2_Evaluation_States.csv | CSV reader | Original state records |
| CVIU_S3_Implementation_Records_Public.zip | `python verify_review.py` | Retained-source/split checks; empirical saved-result and labelled synthetic checks; one disclosed upstream-source omission |
| CVIU_S4_Additional_Evaluation.zip | `python summarize_regenerated.py`; `python write_validation_tables.py` | Saved additional-execution reductions |
| CVIU_Analysis_Execution_Consistency.zip | `python analysis_round3/compare_evaluations.py` | Original/additional saved-result comparison |
| CVIU_Analysis_Calibration_Public.zip | `python reproduce.py summary`; explicit `python reproduce.py cal-bootstrap` | Saved paired-change replay; separately requested sampled CAL refits |
| CVIU_Checkpoints_Risk_Scorers.zip | checkpoint_manifest.json | Six-family, three-run source-selected checkpoints (18); no backbones |
| CVIU_Checkpoints_RelDirect.zip | checkpoint_manifest.json | Three source-selected checkpoints; legacy loader/environment dependencies remain |
| CVIU_Public_Code.zip | `python reproduce.py summary` | Current code and lightweight numeric inputs; excludes full manuscript and dataset-image assets |

Historical READMEs in byte-preserved companion archives predate public packaging;
current public distribution/licensing statements are in this README and the root
notices. Historical filenames and provenance records retain their original meaning.

Booster: https://amsacta.unibo.it/id/eprint/6876/ and DOI
https://doi.org/10.6092/unibo/amsacta/6876 . Exact CAL/EVAL frame identities are in
review_support/split_frames.csv; no new cohort is selected. Original RGB/GT,
geometry and large native arrays/prediction caches are not supplied.

RAFT-Stereo: https://github.com/princeton-vl/RAFT-Stereo . Retained SceneFlow
checkpoint SHA-256:
ba75bdcb379b4c3942d1e714565d0e66e6b2450a3da8129f54073302d67e0a6d .
Depth Anything V2-Small: https://github.com/DepthAnything/Depth-Anything-V2 .
Retained vits checkpoint SHA-256:
715fade13be8f229f8a70cc02066f656f2423a59effd0579197bbf57860e1378 .
Backbone source trees/checkpoints and dependencies remain external.

Full input regeneration follows the preserved generation_sources/ adapters and
builders, recorded normalization/configuration and exact split manifests. The
safe `reproduce.py prepare-inputs` entry requires already generated frozen
predictions and matching public RGB. Recorded analysis_round2 entries document
the prior score -> CAL -> native evaluation -> summary execution; that chain has
not been validated as a one-command clean-host rerun. Summary reproduction and
file-presence preflight are not substitutes for those stages.
