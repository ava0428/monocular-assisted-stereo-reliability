# Reproduction levels

1. `python reproduce.py summary`: consumes saved original/additional scene
   results, reproduces direct paired-change statistics and renders tables using
   the saved CAL diagnostic. No models, native sorting or CAL refits.
2. `python reproduce.py cal-bootstrap`: run from the separately extracted
   CVIU_Analysis_Calibration_Public.zip. Six sampled CAL operands; 2,000 common
   group draws; 18 direct materialization checks in the preserved algorithm.
   Refits offsets and omitted-group radius coverage; does not recompute EVAL
   ordering/selective risk. Explicit diagnostic, not independent-cohort evidence.
3. `python reproduce.py prepare-inputs --balanced-root PATH --prediction-root PATH
   --role EVAL --out NEW_DIRECTORY`: requires hash-matched public RGB and existing
   scoring-grid frozen stereo/mono caches. Reconstructed non-overwriting input
   packing entry, not historical backbone inference. Prior records document one
   existing-frame array agreement, not a newly executed clean-host full workflow.
4. `python reproduce.py preflight-raw --project-root PATH`: presence inventory
   only; does not verify all array bytes or execute models/evaluation.
5. Full additional re-evaluation: preserved analysis_round2 code describes the
   prior score-generation/CAL/native-evaluation chain, requiring complete raw
   dataset, geometry, checkpoints, compatible imports and caches. It is not a
   standalone validated raw rerun from this lightweight public bundle.

See MATERIALS_ACCESS.md for exact payload filenames and THIRD_PARTY_NOTICES.md for
data/code/weight scope. Original and additional execution identities stay separate.
