# Structural revision data and figure entries

This folder provides new figure-generation code and derived displays from the unchanged empirical record. `core_contrasts.csv/json` contains all 12 Raw/Matched x .80/.90 x Mono/Disag/Base paired comparisons; `matched_coverage_visualization_only.csv` is not an all-count integral. The two display NPZs contain real RGB, stride-four sampled AbsRel and retained-set labels for Door/Mirror im0, seed0. They can redraw the image figure but are not native raw-evaluation operands.

From the editable source archive root, with Python, NumPy and Matplotlib:

```
python analysis_revision/build_core_results_table.py
python analysis_revision/build_core_figures.py
python analysis_revision/plot_scene_examples.py
python analysis_revision/build_study_pipeline.py
```

The scripts resolve their bundled inputs relative to themselves. `audit_panel_alignment.py` is included. Scorer names/curve colors and full unrounded data are retained; no simulated empirical observations are used. Exact AURC remains in the original saved summaries.

The optional CPU pixel check requires separately retained project assets, as stated in `evidence_notes.md`:

```
python analysis_revision/prepare_scene_examples.py --project-root D:/stereo/project4
```

This locally executed two-frame check is a new post-hoc verification of hash-bound old predictions, not new inference or calibration. `scene_examples_verification.json` records source hashes, matched masks and numerical agreement. The root argument points to external original assets; the display NPZs cannot substitute for them.
