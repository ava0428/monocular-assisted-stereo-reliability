"""Regenerate the core table from unchanged unrounded cohort values."""
from pathlib import Path
import json,numpy as np
P=Path(__file__).resolve().parents[1]
M=P/"manuscript"
# Present the same unrounded source results in a compact core table.
cohort=json.loads((P/'results/canonical_summary/cohort_metrics.json').read_text(encoding='utf-8'))['rows']
rows=[r'\begingroup\small\setlength{\tabcolsep}{5pt}\renewcommand{\arraystretch}{1.2}',r'\begin{tabular}{llrrr}\toprule',r'Processing & Scorer & AbsRel@0.80 & AbsRel@0.90 & AbsRel-AURC\\\midrule']
for mode in ['Raw','Rel-Analytic']:
 for f,label in [('r1','Stereo-Err'),('r2_concat','Stereo+Mono'),('r2_dis','Stereo+Mono+Disag'),('r2_gate','Base-Risk')]:
  vals=[]
  for k in ['absrel_80','absrel_90','absrel_aurc']:
   v=np.array([cohort[f'{mode}:{f}:{seed}'][k] for seed in [20260910,20260911,20260912]],dtype=float)
   vals.append(f'${v.mean():.6f} \\pm {v.std(ddof=1):.6f}$')
  rows.append(('Raw' if mode=='Raw' else 'Matched RA')+' & '+label+' & '+' & '.join(vals)+r'\\')
 rows.append(r'\midrule')
rows.append('Geometry only & Depth-Only & '+' & '.join(f"{cohort['Depth-Only'][k]:.6f}" for k in ['absrel_80','absrel_90','absrel_aurc'])+r'\\\bottomrule\end{tabular}\endgroup')
(M/'figures/structural/core_results_table.tex').write_text('\n'.join(rows)+'\n',encoding='utf-8')
