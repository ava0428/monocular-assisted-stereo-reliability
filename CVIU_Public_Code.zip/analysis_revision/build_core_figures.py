"""CPU saved-result replay/figures; uses unrounded results, never models.

Figure contract: mono-assisted raw advantages shrink under matched processing;
coverage bounds that statement. Four-panel paired-effect grid and coverage grid.
Vector output at 174 mm wide, editable 9 pt text, descriptive scene intervals.
"""
from pathlib import Path
import csv, json, hashlib
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from audit_panel_alignment import require_matplotlib_panel_alignment

HERE=Path(__file__).resolve().parent
SRC=HERE.parent
DATA=SRC/'results/canonical_summary'
DEST=SRC/'manuscript/figures/structural'
DEST.mkdir(parents=True,exist_ok=True)
def load_csv(path):return list(csv.DictReader(path.open(encoding='utf-8')))
def csvout(path,rows):
    with path.open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
source=SRC/'review_support/sources/scripts/analyze_jise_exact_unified_v1.py'
rows=load_csv(DATA/'scene_metrics_19x45.csv')
scenes=sorted({r['scene'] for r in rows});seeds=[20260910,20260911,20260912]
assert len(rows)==855 and len(scenes)==19
lookup={(r['scene'],r['method']):r for r in rows}
names={'r1':'Stereo-Err','r2_concat':'Stereo+Mono','r2_dis':'Stereo+Mono+Disag','r2_gate':'Base-Risk'}
colors={'r1':'#555555','r2_concat':'#0072B2','r2_dis':'#009E73','r2_gate':'#D55E00','Depth-Only':'#8B6A9F'}
# Replay the saved original-evaluation intervals. Replotting must not launch a
# new bootstrap; hashes bind the saved intervals to their input and algorithm.
saved=json.loads((HERE/'core_contrasts.json').read_text(encoding='utf-8'))
assert saved['source_sha256']==sha(DATA/'scene_metrics_19x45.csv')
assert saved['bootstrap_source_sha256']==sha(source)
assert saved['bootstrap_seed']==20260913 and saved['replicates']==10000
stats=saved['rows']
saved_lookup={(r['mode'],r['coverage'],r['family']):r for r in stats}
assert len(stats)==12 and len(saved_lookup)==12
for mode in ['Raw','Rel-Analytic']:
    for coverage in [80,90]:
        key='absrel_'+str(coverage)
        ref=np.array([[float(lookup[s,mode+':r1:'+str(seed)][key]) for s in scenes] for seed in seeds])
        for fam in ['r2_concat','r2_dis','r2_gate']:
            x=np.array([[float(lookup[s,mode+':'+fam+':'+str(seed)][key]) for s in scenes] for seed in seeds])
            r=saved_lookup[mode,coverage,fam]
            checks=dict(mean=float(x.mean()),reference_mean=float(ref.mean()),run_sample_sd=float(x.mean(axis=1).std(ddof=1)),relative_reduction_percent=float(100*(ref.mean()-x.mean())/ref.mean()),delta=float((x-ref).mean(axis=0).mean()))
            for field,value in checks.items():
                assert np.isclose(r[field],value,rtol=1e-12,atol=1e-15),(mode,coverage,fam,field,r[field],value)
            assert r['scenes']==19 and r['ci_low']<=r['delta']<=r['ci_high']

plt.rcParams.update({'font.family':'sans-serif','font.sans-serif':['Arial','DejaVu Sans'],'font.size':9.6,'axes.titlesize':10.5,'axes.labelsize':9.6,'legend.fontsize':9.5,'xtick.labelsize':9.5,'ytick.labelsize':9.5,'pdf.fonttype':42,'svg.fonttype':'none','axes.spines.top':False,'axes.spines.right':False,'axes.linewidth':.65})
def save(fig,name):
    require_matplotlib_panel_alignment(fig,json_out=str(DEST/(name+'.alignment.json')),tolerance_pt=1.5,gutter_tolerance_pt=1.5,strict=True)
    fig.savefig(DEST/(name+'.pdf'))
    fig.savefig(DEST/(name+'.svg'))
    fig.savefig(DEST/(name+'.png'),dpi=300)
    plt.close(fig)

fig,axes=plt.subplots(2,2,figsize=(174/25.4,123/25.4))
fig.subplots_adjust(left=.22,right=.98,bottom=.15,top=.9,hspace=.65,wspace=.25)
for row,mode in enumerate(['Raw','Rel-Analytic']):
    for col,cov in enumerate([80,90]):
        ax=axes[row,col];scale=1e3 if mode=='Raw' else 1e4
        ax.axvline(0,color='#777777',lw=.7,zorder=0)
        subset=[r for r in stats if r['mode']==mode and r['coverage']==cov]
        for i,r in enumerate(subset):
            ax.errorbar(r['delta']*scale,2-i,xerr=np.array([[r['delta']-r['ci_low']],[r['ci_high']-r['delta']]])*scale,fmt='o',color=colors[r['family']],capsize=3,ms=4.5,lw=1.3)
            ax.annotate(f"{r['delta']*scale:+.2f}",(r['delta']*scale,2-i),xytext=((5,10) if r['delta']>=0 else (-5,10)),textcoords='offset points',ha=('left' if r['delta']>=0 else 'right'),va='bottom',fontsize=9.5,color=colors[r['family']])
        ax.set_yticks([2,1,0]);ax.set_yticklabels(['Stereo+Mono','Stereo+Mono+Disag','Base-Risk'] if col==0 else [])
        ax.set_ylim(-.6,2.6)
        ax.set_title(('Raw' if mode=='Raw' else 'Matched')+'; coverage '+f'{cov/100:.2f}')
        ax.set_xlabel('ΔAbsRel × '+('10³' if mode=='Raw' else '10⁴'))
        ax.text(-.03,1.16,chr(97+row*2+col),transform=ax.transAxes,fontweight='bold')
    limits=[ax.get_xlim() for ax in axes[row]];lo=min(x[0] for x in limits);hi=max(x[1] for x in limits)
    for ax in axes[row]:ax.set_xlim(lo,hi)
fig.text(.53,.015,'Difference from same-processing Stereo-Err; negative favors the scorer',ha='center',fontsize=9.5)
save(fig,'core_contrasts')

z=np.load(DATA/'plot_cohort_visualization_only_1001.npz');c=z['requested_coverage'];assert c.shape==(1001,) and np.all(np.diff(c)>0)
curves={f:np.mean([z['Rel-Analytic:'+f+':'+str(seed)] for seed in seeds],axis=0) for f in names}
curves['Depth-Only']=z['Depth-Only']
assert np.isclose(c[-1],1.0,rtol=0,atol=0)
for fam,y in curves.items():
    # At full coverage every ordering selects the same common valid domain.
    assert np.isclose(y[-1],curves['r1'][-1],rtol=1e-12,atol=1e-13),(fam,y[-1],curves['r1'][-1])
linestyles={'r1':'-','r2_concat':(0,(5,2)),'r2_dis':(0,(3,1.5,1,1.5)),'r2_gate':'-','Depth-Only':(0,(1,2))}
curve_rows=[]
for fam,y in curves.items():
    for i in [800,900]:
        if fam=='Depth-Only':expect=np.mean([float(lookup[s,fam]['absrel_'+str(i//10)]) for s in scenes])
        else:expect=np.mean([float(lookup[s,'Rel-Analytic:'+fam+':'+str(seed)]['absrel_'+str(i//10)]) for s in scenes for seed in seeds])
        assert np.isclose(y[i],expect,rtol=1e-12,atol=1e-13),(fam,i,y[i],expect)
    for ci,yi,di in zip(c,y,y-curves['r1']):curve_rows.append(dict(family=fam,requested_coverage=float(ci),absrel=float(yi),delta_vs_matched_stereo=float(di)))
csvout(HERE/'matched_coverage_visualization_only.csv',curve_rows)
fig,axes=plt.subplots(2,2,figsize=(174/25.4,128/25.4))
fig.subplots_adjust(left=.12,right=.98,bottom=.2,top=.94,hspace=.48,wspace=.32)
for row in range(2):
    for col in range(2):
        ax=axes[row,col]
        shown=(c>0) if col==0 else ((c>=.75)&(c<=.95))
        for fam,y in curves.items():
            val=y if row==0 else (y-curves['r1'])*1e4
            ax.plot(c[shown],val[shown],label=names.get(fam,fam),color=colors[fam],ls=linestyles[fam],lw=1.2 if fam!='r1' else .8)
        for v in [.8,.9]:ax.axvline(v,color='#999999',lw=.65,ls=':')
        ax.set_xlim((0,1) if col==0 else (.75,.95))
        if row==1:ax.axhline(0,color='#777777',lw=.65,zorder=0)
        ax.set_title(('Full coverage range' if col==0 else 'Coverage detail'))
        ax.set_xlabel('Retained coverage')
        ax.set_ylabel('AbsRel risk' if row==0 else 'ΔAbsRel × 10⁴')
        ax.text(-.12,1.1,chr(97+row*2+col),transform=ax.transAxes,fontweight='bold')
        if col==1:
            sel=(c>=.75)&(c<=.95)
            vals=np.concatenate([(y if row==0 else (y-curves['r1'])*1e4)[sel] for y in curves.values()]);span=vals.max()-vals.min();ax.set_ylim(vals.min()-.08*span,vals.max()+.08*span)
handles,labels=axes[0,0].get_legend_handles_labels()
fig.legend(handles,labels,loc='lower center',bbox_to_anchor=(.5,.025),ncol=3,frameon=False)
save(fig,'matched_coverage')
print(json.dumps(stats,indent=2))
