"""Explanatory study schematic; no empirical observations are generated."""
from pathlib import Path
import json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch,FancyArrowPatch

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'manuscript/figures/structural';OUT.mkdir(parents=True,exist_ok=True)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9.6,'pdf.fonttype':42,'svg.fonttype':'none'})
fig,ax=plt.subplots(figsize=(174/25.4,92/25.4),dpi=300)
fig.subplots_adjust(left=0,right=1,bottom=0,top=1);ax.set(xlim=(0,174),ylim=(0,92));ax.axis('off')
texts=[]
def box(x,y,w,h,title,body,color):
 ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0.2,rounding_size=1',lw=.7,ec='#536b78',fc=color))
 texts.append(ax.text(x+w/2,y+h-4,title,ha='center',va='center',weight='bold',fontsize=10.2))
 texts.append(ax.text(x+w/2,y+(h-6)/2,body,ha='center',va='center',fontsize=9.6,linespacing=1.5))
def arrow(points):
 for a,b in zip(points[:-2],points[1:-1]):ax.plot([a[0],b[0]],[a[1],b[1]],c='#536b78',lw=.9)
 ax.add_patch(FancyArrowPatch(points[-2],points[-1],arrowstyle='-|>',mutation_scale=10,lw=.9,color='#536b78'))
box(3,66,72,22,'Fixed inputs','Stereo disparity; mono map if used\nRGB images','#E7F0F5')
box(96,66,75,22,'Risk scorers','SceneFlow-trained, then frozen\nOutput: raw risk score $s$','#E7F3F0')
arrow([(75.5,77),(95.5,77)])
box(3,29,72,25,'Raw ordering','Project $s$ to the native grid\nRank by the projected score','#F1F3F5')
box(96,25,75,29,'Matched ordering','Convert radius; project and scale\nApply own CAL offset; clip radius\nDivide radius by $\hat d+d_{\mathrm{offs}}$','#EEEAF5')
arrow([(133.5,65.5),(133.5,61),(39,61),(39,54.5)])
arrow([(133.5,61),(133.5,54.5)])
texts.append(ax.text(128.5,63,r'$s$',ha='center',va='center',fontsize=9.6))
box(3,2,168,16,'Evaluate each ordering separately',r'Retain the lowest-risk fraction $\rho$; EVAL GT defines the common domain and loss','#FAF2E3')
arrow([(39,28.5),(39,18.5)]);arrow([(133.5,24.5),(133.5,18.5)])
fig.canvas.draw();ren=fig.canvas.get_renderer();bounds=[t.get_window_extent(ren) for t in texts]
assert not any(a.overlaps(b) for i,a in enumerate(bounds) for b in bounds[i+1:])
for ext in ['pdf','svg','png']:fig.savefig(OUT/('study_pipeline.'+ext),dpi=300)
(OUT/'study_pipeline_qa.json').write_text(json.dumps({'type':'explanatory schematic','dimensions_mm':[174,92],'minimum_base_font_pt':9.6,'text_pair_overlap':False,'panel_alignment':'not applicable: one schematic canvas','evidence':'Frozen protocol and scorer/CAL/EVAL roles; not a new quantitative result','source':'build_study_pipeline.py'},indent=2)+'\n')
