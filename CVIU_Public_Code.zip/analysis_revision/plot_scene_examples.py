"""Real fixed predictions and retained sets, with a display-only Mirror crop.
Contract: retain both complete frames; show how Base-Risk RA vs Depth-Only
selection differs. All reported risks come from the verified full-native record.
The third row enlarges the same explicit ROI in all modalities, never a new metric.
"""
from pathlib import Path
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap, BoundaryNorm
from matplotlib.patches import Patch, Rectangle
from audit_panel_alignment import require_matplotlib_panel_alignment

HERE = Path(__file__).resolve().parent
DEST = HERE.parent / 'manuscript/figures/structural'
plt.rcParams.update({'font.family':'sans-serif', 'font.sans-serif':['Arial','DejaVu Sans'],
                     'font.size':9.5, 'axes.titlesize':9.5,
                     'pdf.fonttype':42, 'svg.fonttype':'none'})
records = {r['scene']:r for r in json.loads((HERE/'scene_examples_verification.json').read_text())}
# Structural adaptation of the established genuine-data image plate.
fig, axes = plt.subplots(3, 3, figsize=(6.850393700787402, 7.480314960629922))
width = .29
height = width * 174 / 190 * 752 / 1028
for ri, bottom in enumerate([.70, .445, .19]):
    for ci, left in enumerate([.035, .355, .675]):
        axes[ri, ci].set_position([left, bottom, width, height])
        axes[ri, ci].set_axis_off()
cmap = ListedColormap(['#333333','#cccccc','#D55E00','#8B6A9F','#ffffff'])
norm = BoundaryNorm(np.arange(-.5,5),5)
# Display coordinates; native coordinates are 4 times these values.
# The box exposes the right-hand swap boundary, with no crop-level statistics.
roi = (600, 250, 900, 470)  # x0,y0,x1,y1; zero-based, upper-exclusive
roi_color = '#009E9A'
for ri, scene in enumerate(['Door', 'Mirror']):
    z = np.load(HERE/(scene+'_im0_display.npz'))
    assert z['rgb'].shape[:2] == (752,1028)
    axes[ri,0].imshow(z['rgb'],interpolation='none')
    im = axes[ri,1].imshow(z['absrel'],interpolation='none',cmap='magma',vmin=0,vmax=.2)
    axes[ri,2].imshow(z['selection'],interpolation='none',cmap=cmap,norm=norm)
    row = records[scene]
    delta = row['delta_base_minus_depthonly']
    header = (f"{scene} / im0, seed0   |   AbsRel@0.80: Base-Risk RA {row['metrics']['Base-Risk']:.6f}; "
              f"Depth-Only {row['metrics']['Depth-Only']:.6f}")
    fig.text(.035, [.923,.650][ri], header, fontsize=9.5, ha='left',va='bottom')
    axes[ri,2].text(.5,-.055,f"Δ = {delta:+.6f};  IoU = {row['mask_iou']:.4f}",
                    transform=axes[ri,2].transAxes,ha='center',va='top',fontsize=9.5)
    for ci, ax in enumerate(axes[ri]):
        ax.text(.015,.97,chr(97+ri*3+ci),transform=ax.transAxes,fontweight='bold',
                color='black',va='top',fontsize=10,
                bbox={'facecolor':'white','edgecolor':'none','alpha':.85,'pad':1.5})
    if scene == 'Mirror':
        x0,y0,x1,y1 = roi
        for ax in axes[ri]:
            ax.add_patch(Rectangle((x0-.5,y0-.5),x1-x0,y1-y0,fill=False,
                                   edgecolor=roi_color,lw=1.2))
        native_roi = np.load(HERE/'Mirror_im0_native_roi.npz')
        assert native_roi['rgb'].shape[:2] == (880,1200)
        assert np.array_equal(native_roi['absrel'][::4,::4], z['absrel'][y0:y1,x0:x1], equal_nan=True)
        assert np.array_equal(native_roi['selection'][::4,::4], z['selection'][y0:y1,x0:x1])
        zooms = [native_roi['rgb'], native_roi['absrel'], native_roi['selection']]
        axes[2,0].imshow(zooms[0],interpolation='none',aspect='equal')
        axes[2,1].imshow(zooms[1],interpolation='none',cmap='magma',vmin=0,vmax=.2,aspect='equal')
        axes[2,2].imshow(zooms[2],interpolation='none',cmap=cmap,norm=norm,aspect='equal')
        for ci, ax in enumerate(axes[2]):
            ax.text(.015,.97,chr(103+ci),transform=ax.transAxes,fontweight='bold',
                    color='black',va='top',fontsize=10,
                    bbox={'facecolor':'white','edgecolor':'none','alpha':.85,'pad':1.5})

for ci, title in enumerate(['RGB', 'Fixed-prediction AbsRel', 'Base-Risk RA vs\nDepth-Only']):
    fig.text([.18,.50,.82][ci],.969,title,ha='center',va='center',fontsize=10)
fig.text(.035,.413,'Mirror inset: same ROI; metrics refer to the full frame.',
         fontsize=9.5,ha='left',va='bottom',color='#006F6B')
fig.text(.5,.163, 'Full-frame coverage ρ = 0.80', ha='center', fontsize=9.5)
labels = ['Neither retained','Shared','Base-Risk RA only','Depth-Only only','Outside GT-valid domain']
handles = [Patch(facecolor=cmap(i),edgecolor='#777777' if i==4 else 'none',
                 linewidth=.6,label=label) for i,label in enumerate(labels)]
fig.legend(handles=handles,loc='lower center',bbox_to_anchor=(.5,.015),ncol=3,
           fontsize=9.5,frameon=False,columnspacing=1.3,handlelength=1.4,handletextpad=.55)
cbax = fig.add_axes([.35,.13,.3,.012])
cb = fig.colorbar(im,cax=cbax,orientation='horizontal',extend='max')
cb.set_label('AbsRel (display saturated at 0.20)',fontsize=9.5,labelpad=3)
cb.ax.tick_params(labelsize=9.5,pad=2)
require_matplotlib_panel_alignment(fig,json_out=str(DEST/'scene_examples.alignment.json'),
                                  tolerance_pt=1.5,gutter_tolerance_pt=1.5,strict=True)
cb.solids.set_rasterized(False)
cb.solids.set_edgecolor("face")
fig.savefig(DEST/'scene_examples.pdf', dpi=500)
fig.savefig(DEST/'scene_examples.svg')
fig.savefig(DEST/'scene_examples.png',dpi=500)
fig.savefig(DEST/'scene_examples.tiff',dpi=500,pil_kwargs={'compression':'tiff_lzw'})
plt.close(fig)


