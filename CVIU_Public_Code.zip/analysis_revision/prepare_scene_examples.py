"""CPU-only two-frame verification; no model forward or calibration fit.
Fixed illustrative selection: Door and Mirror, lexically first EVAL frame im0,
first retained run (seed0). This post-hoc selection is not a cohort estimate.
Use --project-root only to locate archived native operands outside light bundle.
"""
from pathlib import Path
import argparse,json,hashlib,math,time
import numpy as np
import cv2
HERE=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--project-root',type=Path,required=True);args=p.parse_args()
OUT=args.project_root/'outputs';OLD=OUT/'jise_numeric_close_v1_synced_20261005';EXTRA=OUT/'ddcv_rel_cal_validation_20261012'
def load(p):return json.loads(p.read_text(encoding='utf-8'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
fits={f"{x['family']}:{x['seed']}":x['delta'] for x in load(OLD/'cal_fits_20261005.json')['fits']}
iproot=OUT/'jise_mono_ablation_booster_inputs_20261005';gproot=OUT/'jise_mono_ablation_booster_eval_operands_20261005'
im={x['scene']+'_'+x['frame']:x for x in load(iproot/'manifest.json')['frames']}
gm={x['scene']:x for x in load(gproot/'manifest.json')['records']}
records=[]
for scene in ['Door','Mirror']:
    t=time.perf_counter();stem=scene+'_im0'
    original=load(OLD/'jise_numeric_close_v1_full_20261005/frames'/(stem+'.json'))
    ip=iproot/im[stem]['input_npz'];gp=gproot/gm[scene]['operand_npz'];rp=EXTRA/'baseRA_maps/r2_gate_seed20260910'/(stem+'.npy')
    hashes={'input':sha(ip),'gt_operand':sha(gp),'raw_score':sha(rp),'frame_record':sha(OLD/'jise_numeric_close_v1_full_20261005/frames'/(stem+'.json'))}
    assert hashes['input']==im[stem]['input_sha256']==original['source']['input_npz_sha256']
    assert hashes['gt_operand']==gm[scene]['operand_sha256']==original['source']['operand_npz_sha256']
    assert hashes['raw_score']==original['source']['scores']['r2_gate:20260910']['score_sha256']
    with np.load(ip) as z:rgb=z['left_rgb'];d0=np.asarray(z['stereo_disparity'],dtype=np.float64)
    with np.load(gp) as z:gt=z['gt_disparity']
    shape=gt.shape;u=np.isfinite(gt)&(gt>0);valid=np.flatnonzero(u);n=int(u.sum());k=math.ceil(.8*n)
    # Verbatim operations of the bound evaluator, native float64, bilinear resize.
    d=cv2.resize(d0,(shape[1],shape[0]),interpolation=cv2.INTER_LINEAR)*4
    offs=gm[scene]['geometry']['doffs'];a=d[u]+offs
    raw=np.asarray(np.load(rp),dtype=np.float64)
    base=np.maximum(np.expm1(raw),0);base[~np.isfinite(raw)]=np.nan
    q=np.maximum(0,cv2.resize(base,(shape[1],shape[0]),interpolation=cv2.INTER_LINEAR)[u]*4+fits['r2_gate:20260910'])
    risk=q/a;depthrisk=1/a
    # Positive-depth AbsRel identity, evaluated on the fixed GT-valid universe.
    loss=np.abs(d[u]-gt[u])/a
    masks=[]
    for r in [risk,depthrisk]:
        ix=np.argsort(r,kind='stable');m=np.zeros(n,dtype=bool);m[ix[:k]]=True;masks.append(m);del ix
    bm,dm=masks
    saved=np.load(EXTRA/'failure_diagnostics'/(stem+'.baseRA.masks.npz'))
    assert np.array_equal(bm,np.unpackbits(saved['20260910'])[:n].astype(bool))
    saved2=np.load(EXTRA/'failure_diagnostics'/(stem+'.masks.npz'))
    assert np.array_equal(valid,saved2['valid_native_indices'])
    assert np.array_equal(dm,np.unpackbits(saved2['Depth-Only'])[:n].astype(bool))
    refs={r['method']:r for r in original['rows']}
    metrics={'Base-Risk':float(loss[bm].mean()),'Depth-Only':float(loss[dm].mean())}
    for name,meth in [('Base-Risk','Rel-Analytic:r2_gate:20260910'),('Depth-Only','Depth-Only')]:
        assert np.isclose(metrics[name],refs[meth]['absrel_80'],rtol=5e-11,atol=1e-11),(scene,name)
    state=np.zeros(n,dtype=np.uint8);state[bm&dm]=1;state[bm&~dm]=2;state[dm&~bm]=3
    spatial=np.full(shape,4,dtype=np.uint8);spatial.flat[valid]=state
    spatialloss=np.full(shape,np.nan,dtype=np.float32);spatialloss.flat[valid]=loss
    # Native-coordinate nearest sampling solely for displayed pixels, not metrics.
    np.savez_compressed(HERE/(stem+'_display.npz'),rgb=rgb,absrel=spatialloss[::4,::4],selection=spatial[::4,::4])
    records.append({'scene':scene,'frame':'im0','run':'seed0','historical_seed':20260910,'native_shape':list(shape),'n_common':n,'k80':k,'hashes':hashes,'cal_fits_sha256':sha(OLD/'cal_fits_20261005.json'),'source_score_sha_bound':True,'recomputed_masks_equal_saved':True,'recomputed_risk_equal_v1':True,'metrics':metrics,'delta_base_minus_depthonly':metrics['Base-Risk']-metrics['Depth-Only'],'mask_iou':float((bm&dm).sum()/(bm|dm).sum()),'display_native_stride':4,'cpu_elapsed_seconds':time.perf_counter()-t})
    print(scene,records[-1]['metrics'],flush=True)
    del d,gt,a,base,q,risk,depthrisk,loss,spatial,spatialloss,bm,dm,masks,saved,saved2,valid,u
(HERE/'scene_examples_verification.json').write_text(json.dumps(records,indent=2)+'\n')
