# 本轮数据图与有限像素复核

本目录为2026-10-20的新分析/作图代码；历史源码仍在 `review_support/sources`，没有改写旧记录。

## 实际完成

1. 从 `results/canonical_summary/scene_metrics_19x45.csv` 的855行未舍入结果重算12组 raw/matched × 0.80/0.90 × Mono/Disag/Base 相对相同处理Stereo的均值差、相对降幅和区间。沿用原 `paired_bootstrap`：每个场景先平均3个固定run，19个目录组配对重采样10000次，RNG20260913，未校正95%描述性百分位区间。结果在 `core_contrasts.json/csv`。图仅突出Mono、Base两个主要对比，Disag保留数据。
2. `plot_cohort_visualization_only_1001.npz`确实含四个matched family×3runs和Depth-Only。新的 `matched_coverage` 图保留完整0–1范围及0.75–0.95局部，显示风险与相对Stereo差。曲线0.80/0.90点与场景矩阵逐项一致。1001点用于显示，未用其近似重算全计数AURC；coverage0沿用档案中每帧首个保留像素显示规则。
3. 在已记录Door/Mirror两个诊断目录中预定使用字典序首帧im0及首个固定run(seed0)，未按像素结果选择帧/种子。找到10/12保存的原始Base-Risk数组，与10/5当前v1 frame receipt逐项SHA匹配；输入、GT操作数也匹配。CPU重算原native projection、q/a和1/a的stable排序，0.80 masks逐位等于保存mask，风险与原始frame JSON一致。仅两个帧，未改全队列结果。核验见 `scene_examples_verification.json`。
4. 真实场景图由RGB、固定预测AbsRel误差及两规则保留集合产生。Door BaseRA 0.015543410124819143 vs Depth-Only 0.03229966604258079；Mirror 0.0680387924594443 vs 0.06609098242182077。后者为实际反例。误差色标0–0.20以上饱和，仅影响显示；native场景完整，不裁剪；显示每4像素取1点，所有统计仍native全域。显示NPZ可独立重画，但不冒充原始评价操作数。

## 7项可选补分析的可行性

盘点采用manifest逐项路径检查，没有扫描海量缓存；见 `operand_availability.json`。

| 项目 | 实际材料与本轮处理 |
|---|---|
| raw/h0/h0/a/q/a/1/a | 108 EVAL inputs和19 GT操作数在本地，但六family完整score目录各只有324 JSON receipt，0个npy。另有Base-Risk在Door/Mirror/Tablet共54原始npy。可有限两帧复核，不能据此宣布四family全队列构造消融完成。 |
| tau .80/.90/.95 | 120 CAL inputs与legacy shared score存在，但这不等于四family当前checkpoint的CAL raw-score/残差操作数；只保存的delta不能refit。当前未新增tau结果。 |
| Random/Shuffled matched | 各324 EVAL receipt，原数组缺失；CAL拟合操作数未恢复；权重身份存在不等于score数组存在。不运行模型补造，未完成。 |
| delta/半径/覆盖/集合重合 | 现有 `calibration_descriptives.json` 有12配置delta及半径统计；`table_matched_ra.csv` median share可直接引用。没有将其解释为性能贡献。两个真实帧完成BaseRA/DepthOnly集合及风险复核；未声称CAL/EVAL经验覆盖全矩阵或CAL扰动。 |
| oracle/随机参照 | 两帧GT误差实际可得，完整四family主张不因此成立；本轮聚焦保留集合复核，未报告新oracle全队列表。Random Mono仍不是random ranking。 |
| 深度内相同coverage/材质 | 已有 `depth_strata_scene_metrics.csv` 是全局.80后分箱诊断，不是分箱重新选择；没有把两者互换。官方mask文件存在不自动证明标签语义与对齐已核验。本轮不新增材质主张。 |
| 成本 | CPU脚本秒数只反映本轮复核，不能视为模型端到端推理时间；没有模型前向或延迟基准。 |

不能称“像素数据全部缺失”；缺失的是完整family×run×CAL/EVAL的当前score数组，而一部分真实图像、GT、冻结预测和54个Base-Risk score可访问。本轮没有使用新目录中的ETH3D、新DDCV或新backbone结果。

## 图注建议（英文）

**Core contrasts.** Differences in AbsRel relative to Stereo-Err under the same processing, at retained coverages 0.80 and 0.90. Points average the three fixed runs within each of 19 scene-directory groups; bars are unadjusted descriptive 95% paired scene-bootstrap intervals (10,000 resamples). Negative values favor the monocular-assisted scorer. Raw panels use a 10³ multiplier and matched panels a 10⁴ multiplier; columns share their row's scale. The raw-to-matched change is descriptive, rather than a causal decomposition of calibration or geometry.

**Matched coverage.** Mean AbsRel risk (a,b) and difference from matched Stereo-Err (c,d) for the four matched scorer families and Depth-Only. Left panels show the complete coverage range; right panels expand 0.75–0.95. Dotted lines mark 0.80 and 0.90. Curves average the three fixed runs and use the saved frame-then-scene-equal 1,001-point visualization samples; these plotted samples are not used to calculate exact all-count AURC. Coverage zero displays the first retained pixel per frame. Depth-Only is the shared deterministic ordering. Curves are descriptive means, without bootstrap bands.

**Examples of changed retained sets.** RGB, fixed-prediction AbsRel and retained-set comparison for Door and Mirror, using frame im0 and seed0 at global coverage 0.80. Orange denotes pixels retained only by matched Base-Risk; blue denotes pixels retained only by Depth-Only; grey denotes shared retention, dark grey neither, and white pixels outside the common GT-valid domain. The same frozen prediction produces every error map. Colors saturate above AbsRel 0.20 for display only, and native maps are nearest-sampled by a factor of four for display; risks use the full native domain. The post-hoc examples use the first frame of each named diagnostic group and first fixed run. Mirror is an adverse example: its retained risk increases from 0.066091 to 0.068039. These examples illustrate set changes and do not isolate the causal contribution of monocular inputs.

## 可移植重画入口

```powershell
python analysis_revision/build_core_figures.py
python analysis_revision/plot_scene_examples.py
```

需要NumPy/matplotlib；alignment helper随脚本。原native像素核验需要另有项目操作数：

```powershell
python analysis_revision/audit_available_operands.py --project-root D:/stereo/project4
python analysis_revision/prepare_scene_examples.py --project-root D:/stereo/project4
```

后两个入口明确读取外部原始资产，轻量display NPZ不能替代这些资产。

## 图形质量检查

三图均生成PDF/SVG/300dpi PNG，174mm宽；PNG是预览，矢量PDF/SVG为正文图。已执行render-time panel alignment并通过，人工查看全部panel，修复scene图colorbar和图例间距。静态检查的`default_rng`提示为真实场景bootstrap，不是模拟数据；宽度提示为表达式静态解析误读，实际174mm。可视化曲线无误差带，明确为均值；核心差值全部有真实区间。使用可用的Python3.12/PyMuPDF执行三图最终碰撞检查，均0 fail/0 warn；scene图两个contained image overlays为故意置于RGB内的Door/Mirror名称。PDF字形检查最低8.5pt，全部字体嵌入。报告位于图目录的`.alignment.json/.collision.json/.text.json`。
