"""Recover display-only native Mirror ROI; no model, sort, CAL or risk re-evaluation."""
from pathlib import Path
import argparse,json,hashlib
import numpy as np,cv2
from PIL import Image
H=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--project-root',type=Path,required=True);args=p.parse_args();ROOT=args.project_root
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
records=json.loads((H/'scene_examples_verification.json').read_text());rec=next(x for x in records if x['scene']=='Mirror')
inputs=ROOT/'outputs/jise_mono_ablation_booster_inputs_20261005';ir=next(x for x in json.loads((inputs/'manifest.json').read_text())['frames'] if x['scene']=='Mirror' and x['frame']=='im0')
ip=inputs/ir['input_npz'];gp=ROOT/'outputs/jise_mono_ablation_booster_eval_operands_20261005/Mirror.npz';rgbp=ROOT/'outputs/v4_booster_eval_recovery_142/Mirror/camera_00/im0.png'
assert sha(ip)==rec['hashes']['input'] and sha(gp)==rec['hashes']['gt_operand'] and sha(rgbp)==ir['left_sha256']
with np.load(ip,allow_pickle=False) as z:d0=z['stereo_disparity'].astype(np.float64);rgbq=z['left_rgb']
with np.load(gp,allow_pickle=False) as z:gt=z['gt_disparity']
rgb=np.asarray(Image.open(rgbp).convert('RGB'));assert rgb.shape==(3008,4112,3)
valid=np.flatnonzero(np.isfinite(gt)&(gt>0));n=len(valid);assert n==rec['n_common']
maskroot=ROOT/'outputs/ddcv_rel_cal_validation_20261012/failure_diagnostics';bp=maskroot/'Mirror_im0.baseRA.masks.npz';dp=maskroot/'Mirror_im0.masks.npz'
with np.load(bp,allow_pickle=False) as z:bm=np.unpackbits(z['20260910'],bitorder=str(z['bitorder']))[:n].astype(bool)
with np.load(dp,allow_pickle=False) as z:
 assert np.array_equal(valid,z['valid_native_indices']);dm=np.unpackbits(z['Depth-Only'],bitorder=str(z['bitorder']))[:n].astype(bool)
assert int(bm.sum())==int(dm.sum())==rec['k80']
state=np.full(gt.shape,4,np.uint8);v=np.zeros(n,np.uint8);v[bm&dm]=1;v[bm&~dm]=2;v[dm&~bm]=3;state.flat[valid]=v
# Restore pixelwise display loss using the same frozen native projection. No mean/ranking is computed.
d=cv2.resize(d0,(4112,3008),interpolation=cv2.INTER_LINEAR)*4
geometry=json.loads((ROOT/'outputs/jise_mono_ablation_booster_eval_operands_20261005/manifest.json').read_text())['records'];g=next(x for x in geometry if x['scene']=='Mirror')['geometry'];den=d.ravel()[valid]+g['doffs'];assert np.all(den>0)
error=np.full(gt.shape,np.nan,np.float32);error.flat[valid]=np.abs(d.ravel()[valid]-gt.ravel()[valid])/den
with np.load(H/'Mirror_im0_display.npz',allow_pickle=False) as old:
 assert np.array_equal(rgbq,old['rgb']) and np.array_equal(state[::4,::4],old['selection'])
 assert np.array_equal(error[::4,::4],old['absrel'],equal_nan=True)
x0,y0,x1,y1=2400,1000,3600,1880
out=H/'Mirror_im0_native_roi.npz';np.savez_compressed(out,rgb=rgb[y0:y1,x0:x1],absrel=error[y0:y1,x0:x1],selection=state[y0:y1,x0:x1])
result={'scope':'display ROI recovery only; no forward, sorting, CAL refit or aggregate metric recomputation','scene':'Mirror','frame':'im0','run':'seed0','old_display_roi':[600,250,900,470],'native_roi':[x0,y0,x1,y1],'native_roi_shape':[880,1200],'RGB_native_sha256':sha(rgbp),'input_sha256':sha(ip),'gt_operand_sha256':sha(gp),'saved_Base_mask_sha256':sha(bp),'saved_Depth_mask_sha256':sha(dp),'full_display_error_and_mask_stride4_equal':True,'mask_counts_equal_saved_k':True,'output_sha256':sha(out),'original_metric_record_sha256':sha(H/'scene_examples_verification.json'),'metrics_and_IoU':'quoted unchanged from original verification record','numpy':np.__version__,'opencv':cv2.__version__}
(H/'native_roi_round6_provenance.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
