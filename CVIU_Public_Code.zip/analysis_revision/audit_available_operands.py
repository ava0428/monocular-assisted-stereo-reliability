"""Bounded manifest-driven availability inventory; no recursive cache scan."""
from pathlib import Path
import argparse,json,csv
HERE=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--project-root',type=Path,required=True);args=p.parse_args();out=args.project_root/'outputs'
def load(p):return json.loads(p.read_text(encoding='utf-8'))
def count(root,rows,key):return {'expected':len(rows),'present':sum((root/r[key]).is_file() for r in rows),'manifest_present':True}
ev=out/'jise_mono_ablation_booster_inputs_20261005';cal=out/'jise_mono_ablation_booster_cal_inputs_20261005';gt=out/'jise_mono_ablation_booster_eval_operands_20261005'
frames=load(ev/'manifest.json')['frames'];cals=load(cal/'manifest.json')['records'];gts=load(gt/'manifest.json')['records']
r={'eval_inputs':count(ev,frames,'input_npz'),'cal_inputs':count(cal,cals,'input_npz'),'eval_gt':count(gt,gts,'operand_npz')}
score=out/'jise_mono_ablation_target_metrics_20261005/component_scores_20261005_a5/raw_scores'
for fam in ['r1','r2_concat','r2_dis','r2_gate','n_random','n_shuffle']:
    pp=[score/(fam+'_seed'+str(s))/(f['scene']+'_'+f['frame']+'.npy') for f in frames for s in [20260910,20260911,20260912]]
    r[fam+'_full_eval_raw']={'expected':len(pp),'npy_present':sum(x.is_file() for x in pp),'receipt_json_present':sum(x.with_suffix('.json').is_file() for x in pp)}
extra=out/'ddcv_rel_cal_validation_20261012';saved=list(csv.DictReader((extra/'missing_base_risk_raw_assets.csv').open()))
r['base_risk_recovered_failure_subset']={'expected':len(saved),'present':sum((extra/'baseRA_maps'/Path(x['relative_path']).relative_to('raw_scores')).is_file() for x in saved),'scenes':['Door','Mirror','Tablet'],'scope':'same original Booster v1; excludes other studies in surrounding directory'}
r['cal_original_legacy_scores']={'expected':len(cals),'present':sum((out/'v4_booster_cal_scores_129_run1/frames'/(x['scene']+'_'+x['frame']+'.npz')).is_file() for x in cals),'limitation':'legacy shared NPZ is not six-family component raw score ledger'}
r['curves']={'cohort_plot_samples':1001,'four_matched_families':True,'depthonly':True,'sparse_samples_not_exact_aurc':True}
(HERE/'operand_availability.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
