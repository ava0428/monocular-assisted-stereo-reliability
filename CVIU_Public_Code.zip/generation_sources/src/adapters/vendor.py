from __future__ import annotations

import contextlib
import sys
from pathlib import Path
from typing import Iterator


@contextlib.contextmanager
def import_vendor_root(root: Path, package: str) -> Iterator[None]:
    """Import a vendored absolute-import package from exactly one source root."""
    root = root.resolve()
    prefix = package + "."
    stale = [name for name in sys.modules if name == package or name.startswith(prefix)]
    for name in stale:
        del sys.modules[name]
    value = str(root)
    sys.path.insert(0, value)
    try:
        yield
    finally:
        try:
            sys.path.remove(value)
        except ValueError:
            pass
