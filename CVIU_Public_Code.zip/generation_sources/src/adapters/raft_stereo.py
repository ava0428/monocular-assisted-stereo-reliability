from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from types import SimpleNamespace
from typing import Any, Iterator

import numpy as np
import torch
import torch.nn.functional as F

from src.adapters.vendor import import_vendor_root
from src.utils.files import sha256_file, sha256_tree


@dataclass(frozen=True)
class StereoPrediction:
    disparity: np.ndarray
    metadata: dict[str, Any]


def _strip_data_parallel_prefix(state: dict[str, torch.Tensor]) -> dict[str, torch.Tensor]:
    return {key.removeprefix("module."): value for key, value in state.items()}


class StereoAdapter:
    def __init__(
        self,
        source_root: Path,
        checkpoint: Path,
        config: dict[str, Any],
        device: str | torch.device = "cuda",
    ) -> None:
        self.source_root = source_root.resolve()
        self.checkpoint = checkpoint.resolve()
        self.config = config
        self.device = torch.device(device)
        if sha256_file(self.checkpoint) != config["checkpoint_sha256"]:
            raise ValueError(f"RAFT checkpoint SHA-256 mismatch: {self.checkpoint}")
        if sha256_tree(self.source_root / "core") != config["source_sha256"]:
            raise ValueError(f"RAFT source tree SHA-256 mismatch: {self.source_root / 'core'}")
        if self.device.type == "cuda" and not torch.cuda.is_available():
            raise RuntimeError("CUDA was requested for RAFT-Stereo but is unavailable")
        with import_vendor_root(self.source_root, "core"):
            from core.raft_stereo import RAFTStereo
        args = SimpleNamespace(
            hidden_dims=config["hidden_dims"],
            corr_implementation=config["corr_implementation"],
            shared_backbone=config["shared_backbone"],
            corr_levels=config["corr_levels"],
            corr_radius=config["corr_radius"],
            n_downsample=config["n_downsample"],
            context_norm=config["context_norm"],
            slow_fast_gru=config["slow_fast_gru"],
            n_gru_layers=config["n_gru_layers"],
            mixed_precision=bool(config["mixed_precision"] and self.device.type == "cuda"),
        )
        self.model = RAFTStereo(args)
        state = torch.load(self.checkpoint, map_location="cpu")
        if not isinstance(state, dict):
            raise TypeError(f"Unexpected RAFT checkpoint type: {type(state).__name__}")
        self.model.load_state_dict(_strip_data_parallel_prefix(state), strict=True)
        self.model.requires_grad_(False).to(self.device).eval()

    @staticmethod
    def _validate_image(image: np.ndarray, name: str) -> None:
        if image.dtype != np.uint8 or image.ndim != 3 or image.shape[2] != 3:
            raise ValueError(f"{name} must be RGB uint8 HxWx3")

    def predict(self, left: np.ndarray, right: np.ndarray) -> StereoPrediction:
        self._validate_image(left, "left")
        self._validate_image(right, "right")
        if left.shape != right.shape:
            raise ValueError("Left and right images must have identical shapes")
        height, width = left.shape[:2]
        left_array = np.array(left, dtype=np.uint8, order="C", copy=True)
        right_array = np.array(right, dtype=np.uint8, order="C", copy=True)
        left_tensor = torch.from_numpy(left_array).permute(2, 0, 1).float()[None].to(self.device)
        right_tensor = torch.from_numpy(right_array).permute(2, 0, 1).float()[None].to(self.device)
        divisor = int(self.config["pad_divisor"])
        pad_height = (divisor - height % divisor) % divisor
        pad_width = (divisor - width % divisor) % divisor
        padding = [pad_width // 2, pad_width - pad_width // 2, pad_height // 2, pad_height - pad_height // 2]
        left_tensor = F.pad(left_tensor, padding, mode="replicate")
        right_tensor = F.pad(right_tensor, padding, mode="replicate")
        with torch.inference_mode():
            _, flow = self.model(
                left_tensor,
                right_tensor,
                iters=int(self.config["valid_iters"]),
                test_mode=True,
            )
        top, bottom = padding[2], flow.shape[-2] - padding[3]
        left_edge, right_edge = padding[0], flow.shape[-1] - padding[1]
        disparity = -flow[0, 0, top:bottom, left_edge:right_edge].float().cpu().numpy()
        if disparity.shape != (height, width):
            raise RuntimeError(f"RAFT output shape {disparity.shape} does not match {(height, width)}")
        return StereoPrediction(
            disparity=np.ascontiguousarray(disparity, dtype=np.float32),
            metadata={
                "input_shape": [height, width],
                "padded_shape": list(left_tensor.shape[-2:]),
                "padding_left_right_top_bottom": [padding[0], padding[1], padding[2], padding[3]],
                "pad_mode": "replicate",
                "pad_divisor": divisor,
                "iterations": int(self.config["valid_iters"]),
                "correlation": self.config["corr_implementation"],
                "mixed_precision": bool(self.model.args.mixed_precision),
                "raw_flow_sign": "x_right_minus_x_left",
                "output_sign": "positive_x_left_minus_x_right",
                "output_unit": "pixels",
                "resized": False,
            },
        )
