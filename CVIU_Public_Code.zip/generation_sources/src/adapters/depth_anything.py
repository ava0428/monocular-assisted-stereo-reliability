# PUBLIC RELEASE COPY: provenance notice added; executable code unchanged.
# Preprocessing sequence adapted from Depth Anything V2, depth_anything_v2/dpt.py
# (DepthAnything/Depth-Anything-V2), licensed under Apache-2.0.
# See root LICENSE-Apache-2.0.txt and THIRD_PARTY_NOTICES.md.
# Project changes: adapter API, hash-bound loading and RGB-input handling.
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterator

import cv2
import numpy as np
import torch
import torch.nn.functional as F
from torchvision.transforms import Compose

from src.adapters.vendor import import_vendor_root
from src.utils.files import sha256_file, sha256_tree


@dataclass(frozen=True)
class MonoPrediction:
    relative_depth: np.ndarray
    metadata: dict[str, Any]


class MonoAdapter:
    def __init__(
        self,
        source_root: Path,
        checkpoint: Path,
        config: dict[str, Any],
        device: str | torch.device = "cuda",
    ) -> None:
        self.source_root = source_root.resolve()
        self.checkpoint = checkpoint.resolve()
        self.config = config
        self.device = torch.device(device)
        if sha256_file(self.checkpoint) != config["checkpoint_sha256"]:
            raise ValueError(f"DA-V2 checkpoint SHA-256 mismatch: {self.checkpoint}")
        if sha256_tree(self.source_root / "depth_anything_v2") != config["source_sha256"]:
            raise ValueError(
                f"DA-V2 source tree SHA-256 mismatch: {self.source_root / 'depth_anything_v2'}"
            )
        if self.device.type == "cuda" and not torch.cuda.is_available():
            raise RuntimeError("CUDA was requested for Depth Anything V2 but is unavailable")
        with import_vendor_root(self.source_root, "depth_anything_v2"):
            from depth_anything_v2.dpt import DepthAnythingV2
            from depth_anything_v2.util.transform import NormalizeImage, PrepareForNet, Resize
        self.model = DepthAnythingV2(
            encoder=config["encoder"],
            features=int(config["features"]),
            out_channels=config["out_channels"],
        )
        state = torch.load(self.checkpoint, map_location="cpu")
        if not isinstance(state, dict):
            raise TypeError(f"Unexpected DA-V2 checkpoint type: {type(state).__name__}")
        self.model.load_state_dict(state, strict=True)
        self.model.requires_grad_(False).to(self.device).eval()
        input_size = int(config["input_size"])
        self.transform = Compose(
            [
                Resize(
                    width=input_size,
                    height=input_size,
                    resize_target=False,
                    keep_aspect_ratio=True,
                    ensure_multiple_of=14,
                    resize_method="lower_bound",
                    image_interpolation_method=cv2.INTER_CUBIC,
                ),
                NormalizeImage(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
                PrepareForNet(),
            ]
        )

    def predict(self, left: np.ndarray) -> MonoPrediction:
        if left.dtype != np.uint8 or left.ndim != 3 or left.shape[2] != 3:
            raise ValueError("left must be RGB uint8 HxWx3")
        height, width = left.shape[:2]
        transformed = self.transform({"image": left.astype(np.float32) / 255.0})["image"]
        tensor = torch.from_numpy(transformed).unsqueeze(0).to(self.device)
        with torch.inference_mode():
            depth = self.model(tensor)
            restored = F.interpolate(
                depth[:, None],
                (height, width),
                mode="bilinear",
                align_corners=True,
            )[0, 0]
        relative_depth = restored.float().cpu().numpy()
        return MonoPrediction(
            relative_depth=np.ascontiguousarray(relative_depth, dtype=np.float32),
            metadata={
                "input_shape": [height, width],
                "network_input_shape": list(tensor.shape[-2:]),
                "input_size": int(self.config["input_size"]),
                "resize_method": "lower_bound_keep_aspect_ratio_multiple_of_14",
                "resize_interpolation": "opencv_cubic",
                "restore_interpolation": "torch_bilinear_align_corners_true",
                "normalization_mean": [0.485, 0.456, 0.406],
                "normalization_std": [0.229, 0.224, 0.225],
                "output": "raw_relative_depth",
                "output_shape": [height, width],
            },
        )
