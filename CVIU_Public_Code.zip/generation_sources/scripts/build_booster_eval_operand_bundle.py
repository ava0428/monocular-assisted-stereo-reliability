from pathlib import Path
import json,hashlib,shutil,numpy as np
ROOT=Path(__file__).resolve().parents[1]; OUT=ROOT/'outputs/jise_mono_ablation_booster_eval_operands_20261005'
if OUT.exists(): shutil.rmtree(OUT)
OUT.mkdir(parents=True); frames=ROOT/'outputs/v4_booster_eval_run_145/inputs.json'; inputs=json.loads(frames.read_text())
def sha(p):
 h=hashlib.sha256();
 with open(p,'rb') as f:
  for b in iter(lambda:f.read(1<<20),b''):h.update(b)
 return h.hexdigest()
records=[]
for s in inputs:
 scene=s['scene']; gt=Path(s['gt']['path']); arr=np.asarray(np.load(gt),dtype=np.float32); out=OUT/f'{scene}.npz'; np.savez_compressed(out,gt_disparity=arr)
 records.append({'scene':scene,'operand_npz':out.name,'operand_sha256':sha(out),'source_gt_sha256':sha(gt),'shape':list(arr.shape),'geometry':s['geometry']})
(OUT/'manifest.json').write_text(json.dumps({'schema':'jise-booster-eval-operands-20261005','scene_count':len(records),'gt_included':True,'records':records},indent=2)+'\n')
print({'scenes':len(records),'bytes':sum(p.stat().st_size for p in OUT.glob('*.npz'))})
