from __future__ import annotations
import hashlib,json
from pathlib import Path
import cv2,numpy as np
from PIL import Image
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'outputs/jise_mono_ablation_booster_inputs_20261005'
if OUT.exists():
 import shutil; shutil.rmtree(OUT)
FRAMES=OUT/'frames'; FRAMES.mkdir(parents=True)
inputs=json.loads((ROOT/'outputs/v4_booster_eval_run_145/inputs.json').read_text())
def sha(p):
 h=hashlib.sha256();
 with open(p,'rb') as f:
  for b in iter(lambda:f.read(1<<20),b''):h.update(b)
 return h.hexdigest()
records=[]
for scene_rec in inputs:
 scene=scene_rec['scene']
 for fr in scene_rec['frames']:
  frame=fr['frame']; score_path=ROOT/f'outputs/v4_booster_eval_run_145/scores/{scene}_{frame}.npz'
  left_path=Path(fr['left']['path']); right_path=Path(fr['right']['path'])
  with np.load(score_path,allow_pickle=False) as z:
   d=np.asarray(z['stereo_disparity'],dtype=np.float32); m=np.asarray(z['mono_relative_depth'],dtype=np.float32)
  left=np.asarray(Image.open(left_path).convert('RGB'),dtype=np.uint8); right=np.asarray(Image.open(right_path).convert('RGB'),dtype=np.uint8)
  target=(d.shape[1],d.shape[0]); left_q=cv2.resize(left,target,interpolation=cv2.INTER_AREA); right_q=cv2.resize(right,target,interpolation=cv2.INTER_AREA)
  if left_q.shape[:2]!=d.shape or right_q.shape[:2]!=d.shape: raise RuntimeError((scene,frame,left_q.shape,d.shape))
  out=FRAMES/f'{scene}_{frame}.npz'; np.savez_compressed(out,left_rgb=left_q,right_rgb=right_q,stereo_disparity=d,mono_relative_depth=m)
  records.append({'scene':scene,'frame':frame,'input_npz':str(out.relative_to(OUT)).replace('\\','/'),'input_sha256':sha(out),'source_score_npz_sha256':sha(score_path),'left_sha256':sha(left_path),'right_sha256':sha(right_path),'source_shape':list(left.shape[:2]),'score_shape':list(d.shape),'scale':4.0,'interpolation':'cv2.INTER_AREA'})
manifest={'schema':'jise-booster-component-input-bundle-20261005','frames':records,'frame_count':len(records),'gt_included':False,'resize_rule':'cv2.INTER_AREA from 4112x3008 to 1028x752','source_scores':'stereo_disparity + mono_relative_depth only'}
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'out':str(OUT),'frames':len(records),'bytes':sum((FRAMES/x.name).stat().st_size for x in [Path(r['input_npz']) for r in records])},indent=2))
