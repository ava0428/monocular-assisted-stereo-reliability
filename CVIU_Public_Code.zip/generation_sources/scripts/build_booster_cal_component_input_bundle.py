from pathlib import Path
import json,hashlib,shutil,numpy as np,cv2
from PIL import Image
ROOT=Path(__file__).resolve().parents[1]; OUT=ROOT/'outputs/jise_mono_ablation_booster_cal_inputs_20261005'
if OUT.exists(): shutil.rmtree(OUT)
(OUT/'frames').mkdir(parents=True)
d=json.loads((ROOT/'manifests/v4_booster_cal_frames_125.json').read_text())
def sha(p):
 h=hashlib.sha256();
 with open(p,'rb') as f:
  for b in iter(lambda:f.read(1<<20),b''):h.update(b)
 return h.hexdigest()
rows=[]
for s in d['scenes']:
 scene=s['scene']; base=ROOT/'outputs/v4_booster_cal_range_116'/scene
 for f in s['frames']:
  name=f['frame']; score=ROOT/f"outputs/v4_booster_cal_scores_129_run1/frames/{scene}_{name}.npz"; left=ROOT/f['left']['path']; right=ROOT/f['right']['path']
  with np.load(score,allow_pickle=False) as z: disp=np.asarray(z['stereo_disparity'],np.float32); mono=np.asarray(z['mono_relative_depth'],np.float32)
  l=np.asarray(Image.open(left).convert('RGB'),np.uint8); r=np.asarray(Image.open(right).convert('RGB'),np.uint8); target=(disp.shape[1],disp.shape[0]); lq=cv2.resize(l,target,interpolation=cv2.INTER_AREA); rq=cv2.resize(r,target,interpolation=cv2.INTER_AREA)
  out=OUT/'frames'/f'{scene}_{name}.npz'; np.savez_compressed(out,left_rgb=lq,right_rgb=rq,stereo_disparity=disp,mono_relative_depth=mono)
  rows.append({'scene':scene,'frame':name,'role':'CAL','input_npz':f'frames/{scene}_{name}.npz','input_sha256':sha(out),'source_score_npz_sha256':sha(score),'left_sha256':sha(left),'right_sha256':sha(right),'source_shape':list(l.shape[:2]),'score_shape':list(disp.shape),'scale':4.0,'interpolation':'cv2.INTER_AREA'})
(OUT/'manifest.json').write_text(json.dumps({'schema':'jise-booster-cal-component-inputs-20261005','frame_count':len(rows),'gt_included':False,'records':rows},indent=2)+'\n')
print(len(rows),sum(p.stat().st_size for p in (OUT/'frames').glob('*.npz')))
