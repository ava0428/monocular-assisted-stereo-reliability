# Public release derivative

This archive is a separately identified public derivative. Historical
research records and original archive remain unchanged locally. Public
licensing notices supersede pre-release wording about pending external
delivery or author licensing decisions in preserved historical READMEs.

Run `python verify_review.py` from this extracted archive root. It
reports its single deliberate upstream-source exclusion; all retained
sources and empirical/synthetic checks remain separately identified.
See DDCV_UPSTREAM_SOURCE.md. This is not a raw model/pixel rerun.
