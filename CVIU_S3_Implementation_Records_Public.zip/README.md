# Supplementary Data S3: implementation and review support

Prepared review attachment for the CVIU manuscript. No public deposit or completed submission is claimed. Use together with Supplementary Data S1 (`JISE_light_offline_review_20261006.zip`) and S2 (`CVIU_state_records.csv`). S1 retains its historical filename and bytes.

## Run the CPU summary/contract check

Requires Python 3.9+ and NumPy. From any directory:

```text
python /path/to/extracted/S3/verify_review.py
```

The script resolves inputs relative to itself and writes `verification_result.json`. It verifies the supplied source-file identities, the complete split, all four matched families' saved AbsRel@.90 means, sample SDs, paired differences and 10,000-resample intervals, plus a synthetic sorting/metric/CAL-arithmetic fixture. Fixed runs are averaged within each scene before scene resampling. The resampling generator is 20260913, intervals are descriptive percentile intervals without multiplicity adjustment. No checkpoint or network is loaded, no original CAL fit or pixel evaluation is rerun. The verifier was **reconstructed on 2026-10-11**; it is not represented as the original evaluation entry. The metric fixture executes only the AST-extracted `exact_metrics` arithmetic function from the preserved evaluator.

S1's existing `reproduce.py --out <directory> --plots` remains the entry for the full 45-configuration summary, paired-scene and plotting replay. S3 complements it rather than replacing it.

## File-to-claim map

| File | Content / grain |
|---|---|
| `split_frames.csv` | 228 CAL/EVAL frame-pair records; `role`, original `scene`, normalized `physical_scene_id`, `frame_id`, `pair_id`, RGB archive members, stored left/right/GT SHA values |
| `split_scenes.csv` | 38 scene-directory groups; `role`, `scene`, normalized ID, frame count and salted group SHA |
| `split_contract.json` | Official archive URL, TRAIN/balanced camera pair, exact split rule, verified counts and limits |
| `data/scene_metrics_19x45.csv` | 855 scene/configuration records, frame-averaged metrics, same bytes as S1 |
| `data/cohort_metrics.json` | Equal-scene aggregate cross-check |
| `data/pair_bootstrap_10000.csv` | Archived paired-scene comparisons used for cross-check |
| `coverage90.json` | Unrounded four-family mean, sample SD, difference, interval and relative reduction; derived from the scene matrix |
| `synthetic_contract_example.json` | Artificial arithmetic operands with expected outputs; **not empirical data or a new experiment** |
| `sources/` | Preserved feature/model/normalization, CAL, sorting/metric, geometry, DDCV, source-selection, manifest and receipt files |
| `source_identity.json` | Per-file hash, origin and historical expected hash when recovered. Null expected hash means a preserved record, not independently established execution binding |
| `checkpoint_availability.json` | Matches of 18 retained six-family checkpoint hashes to local files. Checkpoint bytes are not included |

Display seed0/seed1/seed2 map to retained model-run IDs 20260910/20260911/20260912. Original evidence files keep their historical IDs. Noise, shuffle and resampling generators are distinct roles, not extra model runs.

## Input/output contracts (preserved implementations)

1. **Frozen scoring inputs.** RGB uint8 H×W×3 and disparity H×W in scoring-grid pixel units; SceneFlow source cache 960×540 and Booster scoring 1028×752 (width×height). `stereo_evidence_gpu.py` builds the 11-channel tensor; `normalization.py` and `configs/normalization_sceneflow_train.json` define the frozen transformations. `mono_evidence.py`, `r2_inputs.py` and `risk_predictor.py` specify mono/disagreement channel order and gate fusion. Output is an unrestricted scalar raw risk map, not a corrected disparity map.
2. **CAL.** `src/taskspace/booster_calibration.py::frame_quotas` partitions 8,192 samples **per scene** among its sorted frames. `sampled_operands` takes native GT plus quarter-grid disparity and raw score, applies `max(expm1(s),0)` before bilinear radius resize and ×4 unit conversion, and returns absolute disparity residuals, base radii and deterministic GT-valid indices. `fit_sampled_c1d` calls `fit_c1d(...,0.90)`: n=155,648, k=ceil((n+1)τ)=140,085, residual e−h0, delta is the kth ordered residual. `scripts/v4_booster_cal_fit_130.py` is the preserved production Base-Risk driver; it is not a stand-alone driver for all twelve matched fits. The saved matched fits are in `sources/outputs/jise_numeric_close_v1_synced_20261005/cal_fits_20261005.json`. The exact historical helper execution digest is not recovered merely by distributing helper source.
3. **Native construction and evaluation.** `scripts/jise_exact_unified_eval_v1.py` and `src/taskspace/geometry.py` are the saved unified execution snapshot. Native inputs include GT, camera parameters, frozen disparity and all raw-score maps plus the per-scorer fits. Nonlinear radius conversion precedes native projection; add delta and clip, then construct relative/depth rules. The common domain is finite positive GT. Stable ascending row-major risk order is used. `exact_metrics(score, losses, chunk)` returns fixed-coverage/full-integral/state fields and sampled curves; sampled curves are for display only. It permits +inf scores, separately flags NaN/−inf and rejects nonfinite common losses. Full raw execution requires operands absent here.
4. **Summary reduction.** `scripts/analyze_jise_exact_unified_v1.py` is preserved summary code. `verify_review.py` imports only its reusable summary/bootstrap function. S1 supplies the already-tested complete summary/plot entry; data do not reconstruct original frame arrays.
5. **DDCV-LR.** `src/baselines/ddcv_reference.py`, `ddcv.py`, `shared_reference_inputs.py` and the hash-bound `src/taskspace/middlebury_scores.py` document the actual voting and right-disparity/LR adapter. The inspected upstream `loss_fuction.py` is preserved under `sources/upstream_ddcv/`; upstream commit/threshold evidence is in `sources/reports/V4_DDCV_UPSTREAM_THRESHOLD_128.md`. This is an adapted comparator, not upstream network reproduction.

## Identity and remaining limits

Some sources were recovered from Git blobs matching recorded hashes; others are saved execution snapshots or present-day copies matching a historical manifest. These statuses are distinct in `source_identity.json`. Drivers retain their original absolute/project-relative assumptions and are evidence snapshots, not a turnkey runtime. Do not run the historical inference/training drivers to perform the lightweight checks.

The split check proves disjoint recorded scene-directory IDs, pair IDs and stored RGB/GT hashes for CAL 19/120 and EVAL 19/108. It neither accesses a new image cohort nor establishes independently annotated semantic separation of real rooms/objects. The full original Booster ZIP digest was not computed historically.

Raw score/GT operands, inference caches, checkpoint bytes, original right-disparity intermediates, voting-only/LR-only maps and full native curves are not included. Complete historical training dependency/cache/loader provenance and the exact CAL helper execution digest remain incomplete. Summary agreement and the artificial fixture are not substitutes for model inference, original CAL refitting or original pixel reevaluation. No claim of independent external validation, isolated gate causality or guaranteed submission readiness follows.
