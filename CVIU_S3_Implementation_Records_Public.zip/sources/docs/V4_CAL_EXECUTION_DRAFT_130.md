# CAL execution draft 130 — for integrated review

Not an execution authorization. No new results have been observed to choose these settings.

## Raw inference

Use all 120 pairs in frozen CAL manifest 125, quarter RGB input (INTER_AREA), existing frozen RAFT and DA-V2, and nine bound heads in 127. Save 13 float32 maps per pair. Total cap 5,000,000,000 bytes, work timeout 7,200 seconds including setup; termination cleanup may take up to ten more seconds. Outputs stay under D:/stereo/project4/outputs. No GT enters raw inference. No automatic restart after failure; retain partial evidence.

DDCV uses report 128's full-image LR quantile and exact upstream coordinate/border convention in the new adapter. Plane-sweep retains the documented edge-replication convention. Shared stereo cost is six forwards per pair; reports must not count the shared zero-shift prediction twice. Raw inference is not a CAL accuracy comparison or method-selection stage.

## Proposed C1_d fitting policy

Use only the 19 CAL scenes, separately per r2_gate seed, nominal tau=.90 (V3 primary level). Rho=.80 is the primary retained fraction and is a separate quantity. Grel-direct and R1 retain raw rankings. No Booster fitting changes weights or source normalization.

For a bounded, scene-balanced empirical calibration sample, take exactly 8,192 pixels per scene. Divide that quota equally among the scene's sorted frame names, assigning remainder one pixel at a time to the earliest names. In each frame, select evenly spaced row-major indices from the GT-positive-finite universe: index floor((j+0.5)*N/q), j=0..q-1. Require N>=q. Pixel selection uses GT validity, never model residual magnitude. Invalid predicted operands at selected indices fail the fit rather than silently deleting samples. This is a prospective V4 sampling convention; it is not the historical all-pixel V3 fit.

Convert raw r2 log score to `max(expm1(u),0)` on the inference grid first. Bilinearly resize that radius and disparity to the native GT grid (OpenCV INTER_LINEAR), multiplying both by the horizontal size ratio (4 for the fixed Booster grids). Thus C1_d bases and errors both use full-grid pixel units. Do not interpolate the log score and then exponentiate or forget radius scaling. Apply the fitted delta in native pixel units in evaluation using the identical transform order. Fit the existing additive C1_d residual quantile with its finite-sample order statistic. Record sample indices, per-scene quotas, seed, tau, delta, n, k and input identities. This empirical pixel calibration does not establish exchangeable-scene coverage guarantees.

Apply frozen fits only to disjoint EVAL scenes after separate EVAL authorization. Do not score these same CAL frames with their own fit and present that as held-out accuracy. Primary evaluation is scene-equal AbsRel@.80, with paired scene-difference intervals; no missing-cell dropping or selection of favorable seeds.

## Before execution

Complete and test the fit implementation and transform order; review combined code and this prospective policy once through the existing ChatGPT project4 review connection. Pin the resulting code package and request a concrete local GPU run. Current CLI remains closed.
