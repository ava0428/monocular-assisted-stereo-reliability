"""Shared R2 predictor input assembly — the production input path.

``scripts/train_r2.py::build_inputs`` is the frozen training-time definition of
what each R2 variant sees. That script is part of the archived Week 4 execution
snapshot (``trainer implementation`` sha256 ``41ca82b9…`` in
``docs/WEEK4_R2_CHECKPOINT_FREEZE.md``), so this phase deliberately **does not
edit it**. Instead the same semantics are expressed here, and
``tests/test_week5_r2_inputs.py`` asserts bit-identical output against the
frozen script for every variant on synthetic tensors.

That parity test is what prevents the copy from drifting. Editing the frozen
trainer to import this module would have been the tidier extraction, and was
rejected because it would invalidate a recorded digest of an executed artefact.

The production Week 5 path uses only the ``r2_gate`` branch.
"""
from __future__ import annotations

import torch

from src.evidence.mono_evidence import MONO_CHANNELS, r2_evidence
from src.evidence.normalization import NormalizationConstants, normalize_features_torch
from src.evidence.negative_controls import random_control_channels
from src.evidence.stereo_evidence_gpu import r1_features_gpu

#: Variants this module reproduces, matching ``scripts/train_r2.py``.
VARIANTS = ("m_only", "r2_concat", "r2_dis", "r2_gate", "n_random", "n_shuffle")

#: The only variant Week 5 runs.
PRODUCTION_VARIANT = "r2_gate"


def build_inputs(variant: str, left, right, disparity, mono, constants: NormalizationConstants):
    """Assemble the frozen predictor inputs for one batch.

    Semantics are those of the frozen Week 4 protocol: the R1 channels take the
    frozen SceneFlow normalization; the mono and disagreement channels are
    analytically bounded and are deliberately not normalized, so no statistic is
    fitted at any point. No ground truth enters.
    """
    r1 = normalize_features_torch(r1_features_gpu(left, right, disparity), constants)
    block = r2_evidence(disparity, mono)
    if variant == "m_only":
        return (block[:, : len(MONO_CHANNELS)],)
    if variant == "r2_concat":
        return (torch.cat([r1, block[:, : len(MONO_CHANNELS)]], dim=1),)
    if variant in ("r2_dis", "n_shuffle"):
        return (torch.cat([r1, block], dim=1),)
    if variant == "n_random":
        random_block = (
            random_control_channels(block.shape[-2:], device=block.device, dtype=block.dtype)
            .unsqueeze(0)
            .expand(block.shape[0], -1, -1, -1)
            .contiguous()
        )
        return (torch.cat([r1, random_block], dim=1),)
    if variant == "r2_gate":
        return (r1, block, block[:, : len(MONO_CHANNELS)])
    raise ValueError(f"unknown variant {variant!r}")
