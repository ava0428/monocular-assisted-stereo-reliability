"""Intentionally lightweight stereo-only reliability predictors (R0 / R1).

The architecture is deliberately minimal: it is an instrument for the Week 3
research question, not a contribution. Higher output means higher risk
(less reliable), matching the frozen risk direction.

Equal-capacity design. Both variants share an identical trunk and output head;
they differ only in the 1x1 input projection, which adapts the channel count.
With ``hidden=32`` the total parameter difference is under 1%.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import torch
import torch.nn as nn

from src.evidence.mono_evidence import (
    DISAGREEMENT_CHANNELS,
    MONO_CHANNELS,
    R2_CONCAT_CHANNELS,
    R2_DIS_CHANNELS,
)
from src.evidence.stereo_evidence import R0_CHANNELS, R1_CHANNELS


@dataclass(frozen=True)
class PredictorSpec:
    name: str
    input_channels: int
    hidden_channels: int
    trunk_layers: int = 2
    kernel_size: int = 3

    @property
    def receptive_field(self) -> int:
        return 1 + self.trunk_layers * (self.kernel_size - 1)


class StereoRiskPredictor(nn.Module):
    """1x1 projection -> small 3x3 trunk -> 1x1 risk head."""

    def __init__(self, spec: PredictorSpec) -> None:
        super().__init__()
        self.spec = spec
        hidden = spec.hidden_channels
        layers: list[nn.Module] = [
            nn.Conv2d(spec.input_channels, hidden, kernel_size=1),
            nn.ReLU(inplace=True),
        ]
        for _ in range(spec.trunk_layers):
            layers.append(
                nn.Conv2d(hidden, hidden, kernel_size=spec.kernel_size, padding=spec.kernel_size // 2)
            )
            layers.append(nn.ReLU(inplace=True))
        layers.append(nn.Conv2d(hidden, 1, kernel_size=1))
        self.net = nn.Sequential(*layers)

    def forward(self, features: torch.Tensor) -> torch.Tensor:
        if features.dim() != 4 or features.shape[1] != self.spec.input_channels:
            raise ValueError(
                f"{self.spec.name} expects [B,{self.spec.input_channels},H,W], got {tuple(features.shape)}"
            )
        return self.net(features)  # [B,1,H,W], higher = higher risk

    @property
    def input_channels(self) -> int:
        return self.spec.input_channels

    def parameter_count(self) -> int:
        return int(sum(p.numel() for p in self.parameters() if p.requires_grad))

    def estimate_macs(self, height: int, width: int) -> int:
        """Rough multiply-accumulate estimate for one image."""
        spec = self.spec
        hidden = spec.hidden_channels
        macs = spec.input_channels * hidden * height * width
        for _ in range(spec.trunk_layers):
            macs += hidden * hidden * spec.kernel_size * spec.kernel_size * height * width
        macs += hidden * 1 * height * width
        return int(macs)

    def describe(self, height: int = 540, width: int = 960) -> dict[str, Any]:
        return {
            "name": self.spec.name,
            "input_channels": self.spec.input_channels,
            "hidden_channels": self.spec.hidden_channels,
            "trunk_layers": self.spec.trunk_layers,
            "kernel_size": self.spec.kernel_size,
            "receptive_field": self.spec.receptive_field,
            "trainable_parameters": self.parameter_count(),
            "estimated_macs_per_image": self.estimate_macs(height, width),
            "output_shape_per_image": [1, height, width],
        }


def build_r0(hidden_channels: int = 32) -> StereoRiskPredictor:
    return StereoRiskPredictor(
        PredictorSpec(name="R0", input_channels=len(R0_CHANNELS), hidden_channels=hidden_channels)
    )


def build_r1(hidden_channels: int = 32) -> StereoRiskPredictor:
    return StereoRiskPredictor(
        PredictorSpec(name="R1", input_channels=len(R1_CHANNELS), hidden_channels=hidden_channels)
    )


# ---------------------------------------------------------------------------
# Week 4 — capacity specification
#
# The analytical formulas below ARE the Week 4 equal-capacity rule. They read
# the topology and nothing else — never a metric — and
# ``tests/test_risk_predictor.py`` asserts each one equals the corresponding
# instantiated trainable parameter count *exactly*.
#
# Single-branch variants keep the frozen R0/R1 topology verbatim: one 1x1
# projection, two 3x3 trunk convolutions, and a single 1x1 head. There is no
# head hidden width and no second head layer. The original Week 4 draft
# specified a two-layer head (``Conv2d(W,H,1) -> ReLU -> Conv2d(H,1,1)``);
# that layer does not exist in the frozen R1 implementation, so introducing it
# would have changed the head architecture while claiming an equal-capacity
# match. The input channel count ``C`` is therefore the only thing that varies
# across M-only / R2-concat / R2-dis, which is exactly what the R1 -> R2
# single-variable comparison requires.
# ---------------------------------------------------------------------------

#: Mono channels the R2-gate reliability branch consumes (``mono5``).
GATE_MONO_CHANNELS = 5

#: Frozen single-branch hidden width — identical to R0/R1.
SINGLE_BRANCH_HIDDEN = 32


def single_branch_parameter_count(
    input_channels: int, hidden_channels: int = SINGLE_BRANCH_HIDDEN
) -> int:
    """Trainable parameters of the frozen single-branch topology."""
    w = hidden_channels
    projection = input_channels * w + w
    trunk = 2 * (9 * w * w + w)
    head = w + 1
    return projection + trunk + head


def gate_parameter_count(hidden_channels: int, gate_channels: int) -> int:
    """Trainable parameters of the frozen R2-gate topology.

    Two independent trunks (11 and 8 input channels), the mono-reliability
    gate over ``concat(h_s, mono5)``, and one head per branch — weights are not
    shared between branches.
    """
    w, wg = hidden_channels, gate_channels
    stereo_trunk = (11 * w + w) + 2 * (9 * w * w + w)
    disagreement_trunk = (8 * w + w) + 2 * (9 * w * w + w)
    gate = (w + GATE_MONO_CHANNELS + 2) * wg + 1
    heads = 2 * (w + 1)
    return stereo_trunk + disagreement_trunk + gate + heads


def search_gate_widths(
    reference: int,
    hidden_range: range = range(8, 65),
    gate_range: range = range(8, 129),
) -> list[tuple[int, int, int]]:
    """Every ``(hidden, gate, params)`` solution, best first.

    The objective reads **only** the parameter count: minimise
    ``abs(params - reference)``, then ``hidden``, then ``gate``. No metric may
    ever enter this function.
    """
    solutions = [
        (w, wg, gate_parameter_count(w, wg))
        for w in hidden_range
        for wg in gate_range
    ]
    solutions.sort(key=lambda s: (abs(s[2] - reference), s[0], s[1]))
    return solutions


@dataclass(frozen=True)
class GateSpec:
    name: str
    stereo_channels: int = 11
    #: Width of the mono/disagreement trunk: mono5 + disagreement3 = 8.
    mono_disagreement_channels: int = 8
    hidden_channels: int = 21
    gate_channels: int = 88
    trunk_layers: int = 2
    kernel_size: int = 3

    @property
    def receptive_field(self) -> int:
        return 1 + self.trunk_layers * (self.kernel_size - 1)


def _make_trunk(
    input_channels: int, hidden: int, trunk_layers: int, kernel_size: int
) -> nn.Sequential:
    layers: list[nn.Module] = [
        nn.Conv2d(input_channels, hidden, kernel_size=1),
        nn.ReLU(inplace=True),
    ]
    for _ in range(trunk_layers):
        layers.append(nn.Conv2d(hidden, hidden, kernel_size=kernel_size, padding=kernel_size // 2))
        layers.append(nn.ReLU(inplace=True))
    return nn.Sequential(*layers)


class GateRiskPredictor(nn.Module):
    """R2-gate: R1-style stereo branch + disagreement branch + reliability gate.

    ``risk = head_s(h_s) + sigmoid(G(concat(h_s, mono5))) * head_d(h_d)``.
    The two branches do not share weights, and both heads are the frozen R1
    head — a single 1x1 convolution (:meth:`gate_parameter_count` counts two of
    them, one per branch). Training and data wiring belong to Phase I; this
    class exists so the Week 4 capacity rule is checkable against a real
    instantiation rather than a hand-computed formula.
    """

    def __init__(self, spec: GateSpec) -> None:
        super().__init__()
        self.spec = spec
        hidden = spec.hidden_channels
        self.stereo_trunk = _make_trunk(
            spec.stereo_channels, hidden, spec.trunk_layers, spec.kernel_size
        )
        self.disagreement_trunk = _make_trunk(
            spec.mono_disagreement_channels, hidden, spec.trunk_layers, spec.kernel_size
        )
        self.gate = nn.Sequential(
            nn.Conv2d(hidden + GATE_MONO_CHANNELS, spec.gate_channels, kernel_size=1),
            nn.ReLU(inplace=True),
            nn.Conv2d(spec.gate_channels, 1, kernel_size=1),
        )
        self.head_stereo = nn.Conv2d(hidden, 1, kernel_size=1)
        self.head_disagreement = nn.Conv2d(hidden, 1, kernel_size=1)

    def forward(
        self, stereo: torch.Tensor, mono_disagreement: torch.Tensor, mono: torch.Tensor
    ) -> torch.Tensor:
        """``stereo`` = R1(11); ``mono_disagreement`` = mono5 + dis3 (8); ``mono`` = mono5 (5)."""
        h_s = self.stereo_trunk(stereo)
        h_d = self.disagreement_trunk(mono_disagreement)
        gate = torch.sigmoid(self.gate(torch.cat([h_s, mono], dim=1)))
        return self.head_stereo(h_s) + gate * self.head_disagreement(h_d)

    @property
    def input_channels(self) -> tuple[int, int, int]:
        return (
            self.spec.stereo_channels,
            self.spec.mono_disagreement_channels,
            GATE_MONO_CHANNELS,
        )

    def parameter_count(self) -> int:
        return int(sum(p.numel() for p in self.parameters() if p.requires_grad))

    def describe(self) -> dict[str, Any]:
        return {
            "name": self.spec.name,
            "stereo_channels": self.spec.stereo_channels,
            "mono_disagreement_channels": self.spec.mono_disagreement_channels,
            "hidden_channels": self.spec.hidden_channels,
            "gate_channels": self.spec.gate_channels,
            "trunk_layers": self.spec.trunk_layers,
            "kernel_size": self.spec.kernel_size,
            "receptive_field": self.spec.receptive_field,
            "trainable_parameters": self.parameter_count(),
        }


def build_r2_gate(hidden_channels: int = 21, gate_channels: int = 88) -> GateRiskPredictor:
    return GateRiskPredictor(
        GateSpec(
            name="R2-gate",
            hidden_channels=hidden_channels,
            gate_channels=gate_channels,
        )
    )


def _build_single_branch(
    name: str, channels: tuple[str, ...], hidden_channels: int
) -> StereoRiskPredictor:
    return StereoRiskPredictor(
        PredictorSpec(name=name, input_channels=len(channels), hidden_channels=hidden_channels)
    )


def build_m_only(hidden_channels: int = SINGLE_BRANCH_HIDDEN) -> StereoRiskPredictor:
    """``M-only``: mono5 alone, without R1 stereo evidence (V3 §14.4)."""
    return _build_single_branch("M-only", MONO_CHANNELS, hidden_channels)


def build_r2_concat(hidden_channels: int = SINGLE_BRANCH_HIDDEN) -> StereoRiskPredictor:
    """``R2-concat``: R1(11) + mono5, with no explicit disagreement (V3 §14.4)."""
    return _build_single_branch("R2-concat", R2_CONCAT_CHANNELS, hidden_channels)


def build_r2_dis(hidden_channels: int = SINGLE_BRANCH_HIDDEN) -> StereoRiskPredictor:
    """``R2-dis``: R1(11) + mono5 + disagreement3 (V3 §14.4)."""
    return _build_single_branch("R2-dis", R2_DIS_CHANNELS, hidden_channels)
