from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable

import numpy as np
from sklearn.metrics import average_precision_score


FROZEN_COVERAGES = (1.0, 0.95, 0.90, 0.80, 0.70, 0.50)


@dataclass(frozen=True)
class RiskCoveragePoint:
    requested_coverage: float
    actual_coverage: float
    risk: float
    retained: int


def _flatten_valid(
    risk: np.ndarray,
    error: np.ndarray,
    valid_mask: np.ndarray,
) -> tuple[np.ndarray, np.ndarray]:
    if risk.shape != error.shape or risk.shape != valid_mask.shape:
        raise ValueError("Risk, error, and valid mask must have identical shapes")
    valid = valid_mask.astype(bool)
    if not valid.any():
        raise ValueError("No valid pixels")
    if not np.isfinite(risk[valid]).all() or not np.isfinite(error[valid]).all():
        raise ValueError("Valid pixels must have finite risk and error")
    flat_risk = risk[valid].astype(np.float64)
    flat_error = error[valid].astype(np.float64)
    if np.any(flat_error < 0):
        raise ValueError("Errors must be non-negative")
    return flat_risk, flat_error


def risk_coverage_points(
    risk: np.ndarray,
    error: np.ndarray,
    valid_mask: np.ndarray,
    coverages: Iterable[float] = FROZEN_COVERAGES,
) -> list[RiskCoveragePoint]:
    flat_risk, flat_error = _flatten_valid(risk, error, valid_mask)
    order = np.argsort(flat_risk, kind="stable")
    ordered_error = flat_error[order]
    cumulative = np.cumsum(ordered_error)
    count = flat_error.size
    points = []
    for coverage in coverages:
        if not 0 < coverage <= 1:
            raise ValueError(f"Coverage must be in (0, 1], got {coverage}")
        retained = min(count, max(1, int(np.ceil(coverage * count))))
        points.append(
            RiskCoveragePoint(
                requested_coverage=float(coverage),
                actual_coverage=retained / count,
                risk=float(cumulative[retained - 1] / retained),
                retained=retained,
            )
        )
    return points


def empirical_risk_curve(
    risk: np.ndarray,
    error: np.ndarray,
    valid_mask: np.ndarray,
) -> tuple[np.ndarray, np.ndarray]:
    flat_risk, flat_error = _flatten_valid(risk, error, valid_mask)
    ordered_error = flat_error[np.argsort(flat_risk, kind="stable")]
    retained = np.arange(1, ordered_error.size + 1, dtype=np.float64)
    return retained / ordered_error.size, np.cumsum(ordered_error) / retained


def aurc(risk: np.ndarray, error: np.ndarray, valid_mask: np.ndarray) -> float:
    return float(empirical_risk_curve(risk, error, valid_mask)[1].mean())


def oracle_risk(error: np.ndarray) -> np.ndarray:
    return np.asarray(error, dtype=np.float64)


def random_risk(shape: tuple[int, ...], seed: int) -> np.ndarray:
    count = int(np.prod(shape))
    scores = np.empty(count, dtype=np.float64)
    scores[np.random.default_rng(seed).permutation(count)] = np.arange(count, dtype=np.float64)
    return scores.reshape(shape)


def ause(risk: np.ndarray, error: np.ndarray, valid_mask: np.ndarray) -> float:
    _, method_curve = empirical_risk_curve(risk, error, valid_mask)
    _, oracle_curve = empirical_risk_curve(oracle_risk(error), error, valid_mask)
    return float(np.maximum(method_curve - oracle_curve, 0.0).mean())


def bad2_auprc(risk: np.ndarray, error: np.ndarray, valid_mask: np.ndarray) -> float:
    flat_risk, flat_error = _flatten_valid(risk, error, valid_mask)
    labels = flat_error > 2.0
    if labels.all() or (~labels).all():
        raise ValueError("Bad2 AUPRC requires both positive and negative examples")
    return float(average_precision_score(labels, flat_risk))
