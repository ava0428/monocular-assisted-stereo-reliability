"""C0, the C1 split-conformal additive radius, and the C1-constant ablation.

All three formulas were frozen by `PROTOCOL_AMENDMENT_WEEK5_010` before any
Week 5 calibration number existed. V3 did not contain them; see
``src/calibration/spec.py`` for the gap each one closes.

```
C0            h0 = maximum(expm1(s), 0)
C1            a_i = e_i - h0_i            on the fold's cal-role valid pixels
              delta_alpha = sorted(a)[k-1],  k = ceil((n+1)*(1-alpha))
              h1 = maximum(0, h0 + delta_alpha)
C1-constant   a_i = e_i
              h  = sorted(a)[k-1]
```

Every one of them is an explicit 1-based order statistic: no interpolation and
no library quantile whose default semantics could change between versions.
"""
from __future__ import annotations

import math
from abc import ABC, abstractmethod

import numpy as np

from src.calibration.spec import (
    C1_ABLATION,
    UNRESOLVED,
    CalibrationSpec,
    SpecBlocked,
)


class CalibrationInputError(ValueError):
    """A fit or prediction input violated a frozen rule."""


def _finite(name: str, values, *, non_negative: bool = False) -> np.ndarray:
    array = np.asarray(values, dtype=np.float64).reshape(-1)
    if array.size == 0:
        raise CalibrationInputError(f"{name} is empty; an empty set is a hard failure")
    if not np.isfinite(array).all():
        bad = int((~np.isfinite(array)).sum())
        raise CalibrationInputError(f"{name} contains {bad} non-finite value(s)")
    if non_negative and (array < 0).any():
        raise CalibrationInputError(f"{name} contains negative values")
    return array


def c0_radius(scores) -> np.ndarray:
    """``h0 = maximum(expm1(s), 0)`` — the frozen C0 radius.

    The predictor is trained on ``log1p(|disparity error|)``, so ``expm1`` is the
    unit-restoring inverse and the result is already in disparity pixels. Three
    things are deliberate and asserted by test:

    * ``|s|`` is never used;
    * ``s`` is never clipped or squashed before the transform;
    * only a *negative inverse* is set to zero, and no epsilon is added.
    """
    s = _finite("scores", scores)
    # Overflow is reported by the finiteness check below, not by a warning.
    with np.errstate(over="ignore", invalid="ignore"):
        inverse = np.expm1(s)
    if not np.isfinite(inverse).all():
        raise CalibrationInputError(
            "expm1(scores) is not finite; the raw score is outside the range the "
            "unit-restoring inverse can represent"
        )
    return np.maximum(inverse, 0.0)


def conformal_rank(count: int, coverage: float) -> int:
    """``k = ceil((n+1)*(1-alpha))`` — the frozen split-conformal rank.

    Exposed separately so a run can report ``n`` and ``k`` for every
    (seed, fold, level) without re-deriving them.
    """
    if count < 1:
        raise CalibrationInputError("conformal rank needs at least one calibration sample")
    if not 0.0 < coverage < 1.0:
        raise ValueError(f"Coverage must lie in (0, 1), got {coverage}")
    return math.ceil((count + 1) * coverage)


def conformal_order_statistic(values, coverage: float) -> float:
    """``sorted(a)[k-1]`` with ``k = ceil((n+1)*(1-alpha))``.

    The finite-sample correction is applied, the rank is 1-based, and ``k > n``
    is a hard failure: an uncertifiable level is reported, never silently capped
    to ``n`` and never approximated by the asymptotic ``ceil(n*(1-alpha))``.
    Negative values are legitimate here — the C1 conformity score is
    ``e_i - h0_i`` and may be negative.
    """
    array = _finite("conformity scores", values)
    if not 0.0 < coverage < 1.0:
        raise ValueError(f"Coverage must lie in (0, 1), got {coverage}")
    count = array.size
    rank = conformal_rank(count, coverage)
    if rank > count:
        raise CalibrationInputError(
            f"conformal rank k={rank} exceeds n={count} at coverage {coverage}: the level is "
            f"not certifiable from this calibration set, and k is not capped to n"
        )
    return float(np.sort(array)[rank - 1])


class Calibrator(ABC):
    """Common interface. A calibrator turns a raw score into a half-width."""

    name: str = "calibrator"

    #: Whether the calibrator computes a conformal rank. C0 does not: it fits
    #: nothing and its half-width is a per-pixel function, not a fitted scalar.
    supports_rank: bool = False

    @property
    def fit_size(self) -> int:
        """Calibration samples consumed. C0 consumes none."""
        return 0

    @property
    @abstractmethod
    def fitted_parameters(self) -> int:
        """How many parameters were fitted from calibration data."""

    @abstractmethod
    def half_width(self, scores) -> np.ndarray:
        """``q_d`` per input score, so the interval is ``[d - q_d, d + q_d]``."""

    @abstractmethod
    def provenance(self) -> dict:
        """Everything needed to reproduce the fitted state."""


class C0RawScore(Calibrator):
    """``C0: Raw score / raw error estimate, 不校准`` (V3 §17).

    Zero fitted parameters. The half-width is ``maximum(expm1(s), 0)`` and is
    independent of the nominal level: an uncalibrated score enforces no coverage,
    so its record at 90 % and at 95 % is the same number.

    The raw score itself is exposed unchanged by :meth:`raw_score` and keeps
    driving the ranking metrics — the radius transform never replaces it.
    """

    name = "C0"
    RULE = "expm1_raw_score_radius"

    def __init__(self, rule: str = UNRESOLVED) -> None:
        if rule in (UNRESOLVED, None):
            raise SpecBlocked(
                "c0_interval_rule has no frozen value; reopen it only with an explicit "
                "protocol amendment."
            )
        if rule != self.RULE:
            raise SpecBlocked(f"c0_interval_rule={rule!r} is not the frozen rule {self.RULE!r}")
        self.rule = rule

    def raw_score(self, scores) -> np.ndarray:
        """The pass-through: C0 is the raw score, unchanged."""
        return np.asarray(scores, dtype=np.float64).copy()

    def half_width_for(self, coverage: float, scores) -> np.ndarray:
        """Level-independent by construction; ``coverage`` is accepted and ignored."""
        return c0_radius(scores)

    def half_width(self, scores) -> np.ndarray:
        return c0_radius(scores)

    @property
    def fitted_parameters(self) -> int:
        return 0

    def provenance(self) -> dict:
        return {
            "calibrator": self.name,
            "rule": self.rule,
            "formula": "h0 = maximum(expm1(s), 0)",
            "fitted_parameters": 0,
            "calibration_data_used": False,
            "level_dependent": False,
            "source": "V3 17 (C0) + PROTOCOL_AMENDMENT_WEEK5_010 (the radius rule)",
        }


class SplitConformalAdditiveRadius(Calibrator):
    """C1: additive split-conformal correction of the C0 radius.

    ``a_i = e_i - h0_i`` on the fold's cal-role valid pixels;
    ``delta_alpha`` is the explicit ``k``-th order statistic of ``a`` with
    ``k = ceil((n+1)*(1-alpha))``; the evaluated half-width is
    ``maximum(0, h0 + delta_alpha)``. Endpoints are never clipped.

    Fit once per (seed, fold): the caller must pass only that fold's cal-role
    pixels. ``calibration_scenes`` is recorded so the pooled-pixel confound is
    visible in the provenance.
    """

    name = "C1"
    supports_rank = True

    def __init__(self, fit_unit: str = UNRESOLVED, nominal_coverages=(0.90, 0.95)) -> None:
        from src.calibration.spec import C1_FIT_UNIT

        if fit_unit in (UNRESOLVED, None):
            raise SpecBlocked(
                "c1_fit_unit has no frozen value; reopen it only with an explicit protocol "
                "amendment."
            )
        if fit_unit != C1_FIT_UNIT:
            raise SpecBlocked(f"c1_fit_unit={fit_unit!r} is not the frozen unit {C1_FIT_UNIT!r}")
        self.fit_unit = fit_unit
        self.nominal_coverages = tuple(float(c) for c in nominal_coverages)
        self._delta: dict[float, float] | None = None
        self._fit_size = 0
        self._scene_pixel_counts: dict[str, int] = {}

    def fit(self, scores, residuals, cal_scenes=None) -> "SplitConformalAdditiveRadius":
        s = _finite("scores", scores)
        e = _finite("residuals", residuals, non_negative=True)
        if s.size != e.size:
            raise CalibrationInputError(
                f"scores and residuals must be paired, got {s.size} and {e.size}"
            )
        conformity = e - c0_radius(s)
        self._delta = {
            coverage: conformal_order_statistic(conformity, coverage)
            for coverage in self.nominal_coverages
        }
        self._fit_size = int(e.size)
        if cal_scenes is not None:
            scenes = list(cal_scenes)
            if len(scenes) != e.size:
                raise CalibrationInputError(
                    "cal_scenes must have one entry per calibration pixel, so the pooled-pixel "
                    f"confound can be reported; got {len(scenes)} for {e.size} pixels"
                )
            counts: dict[str, int] = {}
            for scene in scenes:
                counts[str(scene)] = counts.get(str(scene), 0) + 1
            self._scene_pixel_counts = counts
        return self

    @property
    def fitted_parameters(self) -> int:
        if self._delta is None:
            raise CalibrationInputError("calibrator has not been fitted")
        return len(self._delta)

    def delta(self, coverage: float) -> float:
        if self._delta is None:
            raise CalibrationInputError("calibrator has not been fitted")
        if coverage not in self._delta:
            raise KeyError(f"coverage {coverage} was not fitted; fitted {sorted(self._delta)}")
        return self._delta[coverage]

    def rank(self, coverage: float) -> int:
        """``k`` for this fit; reported alongside ``n`` and ``delta_alpha``."""
        if self._delta is None:
            raise CalibrationInputError("calibrator has not been fitted")
        return conformal_rank(self._fit_size, coverage)

    @property
    def fit_size(self) -> int:
        return self._fit_size

    def half_width_for(self, coverage: float, scores) -> np.ndarray:
        """``maximum(0, h0 + delta_alpha)``: never negative, never endpoint-clipped."""
        if self._delta is None:
            raise CalibrationInputError("calibrator has not been fitted")
        base = c0_radius(scores)
        return np.maximum(0.0, base + self.delta(coverage))

    def half_width(self, scores) -> np.ndarray:
        return self.half_width_for(self.nominal_coverages[0], scores)

    def provenance(self) -> dict:
        return {
            "calibrator": self.name,
            "family": "split_conformal_additive_radius",
            "conformity_score": "a = residual - maximum(expm1(score), 0)",
            "formula": "h1 = maximum(0, h0 + delta_alpha)",
            "quantile_rule": "explicit 1-based order statistic, no interpolation",
            "finite_sample_correction": "k = ceil((n+1)*(1-alpha))",
            "fit_unit": self.fit_unit,
            "nominal_coverages": list(self.nominal_coverages),
            "delta_alpha": None if self._delta is None else dict(self._delta),
            "fit_pixels": self._fit_size,
            "calibration_scene_pixel_counts": dict(self._scene_pixel_counts),
            "fitted_parameters": None if self._delta is None else self.fitted_parameters,
            "guarantee_claimed": False,
            "guarantee_note": (
                "no distribution-free guarantee is claimed: calibration pixels are spatially "
                "correlated and the 15 scenes are not exchangeable (V3 17)"
            ),
            "source": "V3 17 + PROTOCOL_AMENDMENT_WEEK5_010",
        }


class ConstantRadiusAblation(Calibrator):
    """``C1-constant``: marginal empirical-residual split-conformal interval.

    The same conformal rank applied to the raw residual, giving a constant
    half-width that is independent of the per-pixel R2 risk. It exists only to
    show whether the risk score buys any interval adaptation.

    It is **not** a Checkpoint 3 gate, it may never replace the primary C1, and
    it is reported for every seed.
    """

    name = C1_ABLATION
    supports_rank = True

    def __init__(self, nominal_coverages=(0.90, 0.95)) -> None:
        self.nominal_coverages = tuple(float(c) for c in nominal_coverages)
        self._half_widths: dict[float, float] | None = None
        self._fit_size = 0

    def fit(self, scores, residuals) -> "ConstantRadiusAblation":
        e = _finite("residuals", residuals, non_negative=True)
        self._half_widths = {
            coverage: conformal_order_statistic(e, coverage) for coverage in self.nominal_coverages
        }
        self._fit_size = int(e.size)
        return self

    @property
    def fitted_parameters(self) -> int:
        if self._half_widths is None:
            raise CalibrationInputError("ablation has not been fitted")
        return len(self._half_widths)

    def half_width_for(self, coverage: float, scores) -> np.ndarray:
        if self._half_widths is None:
            raise CalibrationInputError("ablation has not been fitted")
        if coverage not in self._half_widths:
            raise KeyError(f"coverage {coverage} was not fitted")
        shape = _finite("scores", scores).shape
        return np.full(shape, self._half_widths[coverage], dtype=np.float64)

    def half_width(self, scores) -> np.ndarray:
        return self.half_width_for(self.nominal_coverages[0], scores)

    def rank(self, coverage: float) -> int:
        if self._half_widths is None:
            raise CalibrationInputError("ablation has not been fitted")
        return conformal_rank(self._fit_size, coverage)

    @property
    def fit_size(self) -> int:
        return self._fit_size

    def provenance(self) -> dict:
        return {
            "calibrator": self.name,
            "definition": "marginal empirical-residual split-conformal interval",
            "conformity_score": "a = |d_pred - d_gt|",
            "half_widths": None if self._half_widths is None else dict(self._half_widths),
            "fit_pixels": self._fit_size,
            "is_gate": False,
            "may_replace_primary": False,
            "source": "PROTOCOL_AMENDMENT_WEEK5_010 (single frozen ablation)",
        }


def build_calibrators(spec: CalibrationSpec) -> dict[str, Calibrator]:
    """Build C0, the primary C1 and the frozen ablation from a resolved spec.

    The ablation is returned under its own key and is never consulted by the
    Checkpoint 3 evaluator, which reads only ``C0`` and ``C1``.
    """
    from src.calibration.spec import C1_FAMILY, C1_INTERVAL_MODE

    if spec.c1_family != C1_FAMILY or spec.c1_interval_mode != C1_INTERVAL_MODE:
        raise SpecBlocked(
            f"c1_family={spec.c1_family!r} / c1_interval_mode={spec.c1_interval_mode!r} are not "
            f"the frozen pair ({C1_FAMILY!r}, {C1_INTERVAL_MODE!r}); no substitution is made."
        )
    return {
        "C0": C0RawScore(spec.c0_interval_rule),
        "C1": SplitConformalAdditiveRadius(
            fit_unit=spec.c1_fit_unit, nominal_coverages=spec.nominal_coverages
        ),
        C1_ABLATION: ConstantRadiusAblation(nominal_coverages=spec.nominal_coverages),
    }
