"""Week 4 R2 dataset: the frozen RAFT cache joined to the frozen mono cache.

The two caches are joined on ``sample_id`` and the join is required to be
**exact**: a sample present in one cache and not the other is an error rather
than a silent skip, because a missing or mismatched mono map would silently
change what R2 sees relative to what was frozen.

The RAFT cache keeps GT and the valid mask behind ``read_record`` for the
supervision target and loss mask only; the mono cache holds one array and no
target information at all (see ``src/data/mono_cache.py``).
"""
from __future__ import annotations

from pathlib import Path

import numpy as np
import torch
from torch.utils.data import Dataset

from src.data.mono_cache import load_mono_index, read_mono_record
from src.data.sceneflow import SceneFlowDataset
from src.data.sceneflow_cache import load_index as load_raft_index
from src.data.sceneflow_cache import read_record as read_raft_record

#: The logical split name each dataset split must map to.
SPLIT_NAMES = {"train": "train", "validation": "validation"}


class SceneFlowR2Dataset(Dataset):
    """Yields ``(left_rgb, right_rgb, disparity, gt_disparity, valid_mask, mono_relative_depth)``."""

    def __init__(self, root: Path, raft_cache: Path, mono_cache: Path, split: str) -> None:
        if split not in SPLIT_NAMES:
            raise ValueError(f"unknown split {split!r}")
        self.dataset = SceneFlowDataset(root, split=split)
        self.by_id = {sample.sample_id: sample for sample in self.dataset.samples}
        self.raft_cache = Path(raft_cache)
        self.mono_cache = Path(mono_cache)
        self.raft = load_raft_index(self.raft_cache / "index.jsonl")
        self.mono = load_mono_index(self.mono_cache / "index.jsonl")

        raft_only = sorted(set(self.raft) - set(self.mono))
        mono_only = sorted(set(self.mono) - set(self.raft))
        if raft_only or mono_only:
            raise RuntimeError(
                f"cache mismatch for split {split!r}: {len(raft_only)} raft-only "
                f"(e.g. {raft_only[:3]}), {len(mono_only)} mono-only (e.g. {mono_only[:3]})"
            )
        unknown = sorted(set(self.raft) - set(self.by_id))
        if unknown:
            raise RuntimeError(f"{len(unknown)} cached samples are not in the dataset: {unknown[:3]}")

        # Namespace isolation: every joined sample must belong to this split.
        expected = SPLIT_NAMES[split]
        foreign = [sample_id for sample_id in self.raft if self.by_id[sample_id].split != expected]
        if foreign:
            raise RuntimeError(
                f"{len(foreign)} samples from another split leaked into {split!r}: {foreign[:3]}"
            )

        self.ids = sorted(self.raft)
        if not self.ids:
            raise RuntimeError(f"no shared samples for split {split!r}")

    def __len__(self) -> int:
        return len(self.ids)

    def __getitem__(self, position: int):
        sample_id = self.ids[position]
        left, right = self.by_id[sample_id].load_images()
        raft = read_raft_record(self.raft_cache / self.raft[sample_id].record)
        mono = read_mono_record(self.mono_cache / self.mono[sample_id].record)["mono_relative_depth"]
        return (
            left,
            right,
            raft["disparity"],
            raft["gt_disparity"],
            raft["valid_mask"],
            mono,
        )


def collate_r2(batch):
    """BCHW tensors, matching ``src.training.data.collate`` plus the mono map."""
    left = torch.from_numpy(np.stack([item[0] for item in batch])).permute(0, 3, 1, 2).contiguous()
    right = torch.from_numpy(np.stack([item[1] for item in batch])).permute(0, 3, 1, 2).contiguous()
    disparity = torch.from_numpy(np.stack([item[2] for item in batch])).unsqueeze(1)
    gt = torch.from_numpy(np.stack([item[3] for item in batch])).unsqueeze(1)
    mask = torch.from_numpy(np.stack([item[4] for item in batch])).unsqueeze(1)
    mono = torch.from_numpy(np.stack([item[5] for item in batch])).unsqueeze(1)
    return left, right, disparity, gt, mask, mono
