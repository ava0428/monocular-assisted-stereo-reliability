"""Shared operand-first loss used by the corrected Week 3/4 trainers."""
from __future__ import annotations

import torch
import torch.nn.functional as F


def masked_log_error_smooth_l1(
    prediction: torch.Tensor,
    disparity: torch.Tensor,
    gt: torch.Tensor,
    valid_mask: torch.Tensor,
) -> torch.Tensor:
    """Mean SmoothL1 over the frozen valid operand only."""
    if not (prediction.shape == disparity.shape == gt.shape == valid_mask.shape):
        raise RuntimeError(
            "masked loss inputs must have identical shapes: "
            f"prediction={tuple(prediction.shape)} disparity={tuple(disparity.shape)} "
            f"gt={tuple(gt.shape)} mask={tuple(valid_mask.shape)}"
        )
    operand = valid_mask.to(dtype=torch.bool)
    if not bool(operand.any()):
        raise RuntimeError("masked loss has no valid supervision operand")
    prediction_operand = prediction[operand]
    disparity_operand = disparity[operand]
    gt_operand = gt[operand]
    target_operand = torch.log1p(torch.abs(disparity_operand - gt_operand))
    if not bool(torch.isfinite(prediction_operand).all()):
        raise RuntimeError("non-finite prediction inside the supervision operand")
    if not bool(torch.isfinite(target_operand).all()):
        raise RuntimeError("non-finite target inside the supervision operand")
    return F.smooth_l1_loss(
        prediction_operand,
        target_operand,
        beta=1.0,
        reduction="mean",
    )
