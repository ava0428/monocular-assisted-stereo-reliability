from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

import numpy as np
from PIL import Image


IMAGE_SIZE = (960, 540)  # width, height for the canonical SceneFlow renders
IMAGE_EXTENSIONS = (".png", ".jpg", ".jpeg")


@dataclass(frozen=True)
class SceneFlowSample:
    sample_id: str
    subset: str
    split: str
    left_path: Path
    right_path: Path
    disparity_path: Path

    def load_left_image(self) -> np.ndarray:
        """Read only the left image.

        The Week 4 mono cache needs the left view alone; reading the right view
        as well would touch stereo data that the mono path must not depend on.
        """
        return np.asarray(Image.open(self.left_path).convert("RGB"), dtype=np.uint8)

    def load_images(self) -> tuple[np.ndarray, np.ndarray]:
        left = np.asarray(Image.open(self.left_path).convert("RGB"), dtype=np.uint8)
        right = np.asarray(Image.open(self.right_path).convert("RGB"), dtype=np.uint8)
        if left.shape != right.shape:
            raise ValueError(f"Image shapes differ for {self.sample_id}: {left.shape} vs {right.shape}")
        return left, right

    def load_disparity(self) -> np.ndarray:
        return read_sceneflow_pfm(self.disparity_path)

    def validate(self) -> dict[str, object]:
        left, right = self.load_images()
        disparity = self.load_disparity()
        if left.shape[:2] != disparity.shape:
            raise ValueError(
                f"Image/disparity shapes differ for {self.sample_id}: {left.shape[:2]} vs {disparity.shape}"
            )
        finite = np.isfinite(disparity)
        valid = finite & (disparity > 0)
        if not valid.any():
            raise ValueError(f"No positive disparity pixels for {self.sample_id}")
        if left.shape[:2] != (IMAGE_SIZE[1], IMAGE_SIZE[0]):
            raise ValueError(f"Unexpected SceneFlow shape for {self.sample_id}: {left.shape[:2]}")
        return {
            "sample_id": self.sample_id,
            "subset": self.subset,
            "split": self.split,
            "shape": list(left.shape),
            "disparity_shape": list(disparity.shape),
            "image_dtype": str(left.dtype),
            "disparity_dtype": str(disparity.dtype),
            "finite_fraction": float(finite.mean()),
            "valid_fraction": float(valid.mean()),
            "disparity_min": float(disparity[finite].min()),
            "disparity_max": float(disparity[finite].max()),
            "disparity_mean": float(disparity[finite].mean()),
            "disparity_sign": "positive_x_left_minus_x_right",
            "resized": False,
            "crop": None,
        }


def read_sceneflow_pfm(path: Path) -> np.ndarray:
    """Read canonical SceneFlow PFM disparity without applying a scale factor.

    SceneFlow disparity files use a ``-1.0`` PFM marker and store disparity in
    pixel units. The sign is not a negative disparity convention; the negative
    header selects little-endian float32 payloads.
    """
    with path.open("rb") as handle:
        header = handle.readline().decode("ascii").strip()
        if header != "Pf":
            raise ValueError(f"SceneFlow disparity must be grayscale Pf: {path}")
        dimensions = handle.readline().decode("ascii").strip().split()
        if len(dimensions) != 2:
            raise ValueError(f"Invalid PFM dimensions: {path}")
        width, height = map(int, dimensions)
        scale = float(handle.readline().decode("ascii").strip())
        if not np.isfinite(scale) or scale == 0:
            raise ValueError(f"Invalid PFM scale {scale}: {path}")
        if not np.isclose(abs(scale), 1.0):
            raise ValueError(f"Unexpected SceneFlow PFM scale {scale}: {path}")
        dtype = np.dtype("<f4" if scale < 0 else ">f4")
        payload = handle.read()
    values = np.frombuffer(payload, dtype=dtype)
    if values.size != width * height:
        raise ValueError(f"PFM payload has {values.size}, expected {width * height}: {path}")
    return np.flipud(values.reshape(height, width)).astype(np.float32, copy=False)


def _disparity_for_image(image_path: Path) -> Path:
    return Path(str(image_path).replace("frames_finalpass", "disparity")).with_suffix(".pfm")


def _sample_id(root: Path, image_path: Path) -> str:
    return image_path.relative_to(root).with_suffix("").as_posix().replace("/", "::")


def _paired_image(image_path: Path, side: str) -> Path:
    parts = list(image_path.parts)
    try:
        index = parts.index(side)
    except ValueError as exc:
        raise ValueError(f"Image path has no {side} component: {image_path}") from exc
    parts[index] = "right" if side == "left" else "left"
    return Path(*parts)


def _make_sample(root: Path, subset: str, split: str, left: Path) -> SceneFlowSample:
    right = _paired_image(left, "left")
    disparity = _disparity_for_image(left)
    return SceneFlowSample(
        sample_id=_sample_id(root, left),
        subset=subset,
        split=split,
        left_path=left,
        right_path=right,
        disparity_path=disparity,
    )


class SceneFlowDataset:
    """Deterministic scene-level enumeration of the frozen SceneFlow layout."""

    def __init__(self, root: Path, split: str | None = None, verify_paths: bool = True) -> None:
        self.root = root.resolve()
        if not self.root.exists():
            raise FileNotFoundError(f"SceneFlow root does not exist: {self.root}")
        if split not in (None, "train", "validation", "all"):
            raise ValueError(f"Unknown split: {split}")
        self.split = split or "all"
        self.samples = self._enumerate()
        if verify_paths:
            self._verify_unique_and_complete()

    def _enumerate(self) -> list[SceneFlowSample]:
        samples: list[SceneFlowSample] = []
        samples.extend(self._enumerate_flyingthings("TRAIN", "train"))
        samples.extend(self._enumerate_flyingthings("TEST", "validation"))
        samples.extend(self._enumerate_subset("Monkaa", "train", "train"))
        samples.extend(self._enumerate_subset("Driving", "train", "train"))
        if self.split == "train":
            return [sample for sample in samples if sample.split == "train"]
        if self.split == "validation":
            return [sample for sample in samples if sample.split == "validation"]
        return samples

    def _enumerate_flyingthings(self, split_dir: str, logical_split: str) -> list[SceneFlowSample]:
        root = self.root / "FlyingThings3D" / "frames_finalpass" / split_dir
        left_paths = sorted(root.glob("*/*/left/*")) if root.exists() else []
        return [
            _make_sample(self.root, "FlyingThings3D", logical_split, path)
            for path in left_paths
            if path.suffix.lower() in IMAGE_EXTENSIONS
        ]

    def _enumerate_subset(self, subset: str, physical_split: str, logical_split: str) -> list[SceneFlowSample]:
        root = self.root / subset / "frames_finalpass"
        if subset == "Monkaa":
            left_paths = sorted(root.glob("*/left/*")) if root.exists() else []
        elif subset == "Driving":
            left_paths = sorted(root.glob("*/*/*/left/*")) if root.exists() else []
        else:
            raise ValueError(f"Unsupported SceneFlow subset: {subset}")
        return [
            _make_sample(self.root, subset, logical_split, path)
            for path in left_paths
            if path.suffix.lower() in IMAGE_EXTENSIONS
        ]

    def _verify_unique_and_complete(self) -> None:
        sample_ids = [sample.sample_id for sample in self.samples]
        if len(sample_ids) != len(set(sample_ids)):
            raise ValueError("Duplicate SceneFlow sample IDs")
        paths: set[Path] = set()
        for sample in self.samples:
            if sample.left_path in paths or sample.right_path in paths or sample.disparity_path in paths:
                raise ValueError(f"Duplicate SceneFlow path in {sample.sample_id}")
            paths.update((sample.left_path, sample.right_path, sample.disparity_path))
            for path in (sample.left_path, sample.right_path, sample.disparity_path):
                if not path.exists():
                    raise FileNotFoundError(f"Missing SceneFlow asset for {sample.sample_id}: {path}")

    def validate_samples(self, indices: Iterable[int]) -> list[dict[str, object]]:
        return [self.samples[index].validate() for index in indices]

    def __len__(self) -> int:
        return len(self.samples)

    def __getitem__(self, index: int) -> SceneFlowSample:
        return self.samples[index]

    @property
    def scene_ids(self) -> tuple[str, ...]:
        return tuple(sorted({SceneFlowDataset.scene_id(sample) for sample in self.samples}))

    @staticmethod
    def scene_id(sample: SceneFlowSample) -> str:
        """Return subset-local sequence identity, excluding frame number."""
        parts = sample.left_path.parts
        try:
            frames_index = parts.index("frames_finalpass")
        except ValueError as exc:
            raise ValueError(f"Unexpected SceneFlow path: {sample.left_path}") from exc
        relative = parts[frames_index + 1 :]
        if sample.subset == "FlyingThings3D":
            # relative = [TRAIN|TEST, A|B|C, sequence, left, frame]
            return f"{sample.subset}/{relative[0]}/{relative[1]}/{relative[2]}"
        if sample.subset == "Monkaa":
            return f"{sample.subset}/{relative[0]}"
        return f"{sample.subset}/{relative[0]}/{relative[1]}/{relative[2]}"


def sample_manifest_record(sample: SceneFlowSample, root: Path) -> dict[str, str]:
    """Return a deterministic, root-relative manifest record."""
    return {
        "sample_id": sample.sample_id,
        "scene_id": SceneFlowDataset.scene_id(sample),
        "subset": sample.subset,
        "split": sample.split,
        "left": sample.left_path.relative_to(root).as_posix(),
        "right": sample.right_path.relative_to(root).as_posix(),
        "disparity": sample.disparity_path.relative_to(root).as_posix(),
    }


def build_manifest(dataset: SceneFlowDataset) -> dict[str, object]:
    """Build a deterministic manifest without reading image payloads."""
    samples = [sample_manifest_record(sample, dataset.root) for sample in dataset.samples]
    samples.sort(key=lambda record: record["sample_id"])
    counts: dict[str, int] = {}
    split_counts: dict[str, int] = {}
    scene_counts: dict[str, int] = {}
    for record in samples:
        counts[record["subset"]] = counts.get(record["subset"], 0) + 1
        split_counts[record["split"]] = split_counts.get(record["split"], 0) + 1
        scene_counts[record["scene_id"]] = scene_counts.get(record["scene_id"], 0) + 1
    return {
        "schema_version": "sceneflow-manifest-1",
        "dataset": "SceneFlow",
        "canonical_origin": "LMB/Freiburg Scene Flow Datasets",
        "transport_mirror": "Hugging Face aeolusguan/SceneFlow",
        "root": str(dataset.root),
        "image_pass": "frames_finalpass",
        "disparity_format": "PFM float32 pixels, positive x_left_minus_x_right",
        "image_size": {"width": IMAGE_SIZE[0], "height": IMAGE_SIZE[1]},
        "counts_by_subset": counts,
        "counts_by_split": split_counts,
        "scene_count": len(scene_counts),
        "sample_count": len(samples),
        "samples": samples,
    }


def manifest_sha256(manifest: dict[str, object]) -> str:
    payload = json.dumps(manifest, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def write_manifest(dataset: SceneFlowDataset, path: Path) -> str:
    manifest = build_manifest(dataset)
    digest = manifest_sha256(manifest)
    manifest["manifest_sha256"] = digest
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return digest


def validate_scene_disjoint(train: SceneFlowDataset, validation: SceneFlowDataset) -> None:
    overlap = set(train.scene_ids) & set(validation.scene_ids)
    if overlap:
        raise ValueError(f"SceneFlow train/validation scene leakage: {sorted(overlap)[:5]}")
