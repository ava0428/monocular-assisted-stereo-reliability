"""Shared disparity and mono inputs for V4 reference scorers; no file access."""

import numpy as np

from src.baselines.ddcv_reference import ddcv_full_reference
from src.baselines.plane_sweep import DEFAULT_SHIFTS, plane_sweep_profile, plane_sweep_unreliability


def shared_reference_inputs(left, right, stereo_predict, mono_predict):
    """Callbacks return maps; caller owns model loading, authorization and timing.

    Exactly five sweep forwards plus one flip-swapped right forward. The zero
    sweep map is the shared left disparity, never a separate seventh forward.
    """
    profiles = plane_sweep_profile(left, right, stereo_predict)
    disparity = profiles[DEFAULT_SHIFTS.index(0)]
    right_disparity = np.fliplr(stereo_predict(
        np.ascontiguousarray(np.fliplr(right)), np.ascontiguousarray(np.fliplr(left))))
    mono = np.asarray(mono_predict(left))
    return {
        "left_rgb": left, "right_rgb": right,
        "stereo_disparity": disparity, "mono_relative_depth": mono,
        "plane_sweep": plane_sweep_unreliability(profiles, DEFAULT_SHIFTS),
        "ddcv_full_reference": ddcv_full_reference(disparity, right_disparity, mono),
    }
