from __future__ import annotations

import numpy as np


def kernel_grid_weight(i: int, j: int, sigma: float) -> float:
    """Spatial weight from kernel-grid coordinates, independent of dilation."""
    return float(np.exp(-(i * i + j * j) / (sigma ** 2)))


def gradient_window(values: np.ndarray, rad: int = 1) -> np.ndarray:
    """Official ``gradient_window`` parity.

    Mirrors ``torch.nn.Unfold(kernel_size=3, dilation=1, stride=1)`` with
    replicate padding: each pixel yields ``N = 9`` neighborhood samples
    (including the center), and ``grad = unfold - input``. The center entry is
    therefore exactly zero. The return shape is ``[H, W, 9]``; callers apply
    ``abs(.).mean()`` for the gamma scale (``abs=False`` here).
    """
    values = values.astype(np.float64)
    height, width = values.shape
    kernel = 2 * rad + 1
    padded = np.pad(values, rad, mode="edge")
    unfolded = np.empty((height, width, kernel * kernel), dtype=np.float64)
    index = 0
    for dy in range(-rad, rad + 1):
        for dx in range(-rad, rad + 1):
            unfolded[:, :, index] = padded[rad + dy : rad + dy + height, rad + dx : rad + dx + width]
            index += 1
    return unfolded - values[:, :, None]


def ddcv_core(
    disparity: np.ndarray,
    depth: np.ndarray,
    rad: int = 6,
    dilation: int = 4,
    spatial_sigma: float = 10.0,
) -> np.ndarray:
    """DDCV core risk (official source behavior, no LR override, no extra forward).

    Returns per-pixel risk in ``[0, 1]``; 0 = confident, 1 = unconfident.

    ``gamma = mean(|gradient_window(depth,1)|) / mean(|gradient_window(disp,1)|)``.
    For each pixel, votes are collected from a ``13x13`` neighborhood sampled
    with ``dilation=4`` (``49x49`` footprint); only ``disparity > 0`` neighbors
    are valid. A neighbor is ``bad`` when:

    - ``bad_RC  = (|ΔM| > 0.67γ) and (ΔM·ΔD < 0)``
    - ``bad_VC1 = (|ΔM| > 2γ)    and (|ΔD| < 1)``
    - ``bad_VC2 = (|ΔM| < γ)     and (|ΔD| > 2)``

    The spatial weight uses **kernel-grid** coordinates: ``exp(-(i²+j²)/σ²)``
    with ``i,j ∈ {-rad..rad}``, NOT the dilation-scaled physical offsets.
    """
    if disparity.shape != depth.shape:
        raise ValueError("disparity and depth must have identical shapes")
    disparity = disparity.astype(np.float64)
    depth = depth.astype(np.float64)

    depth_grad = gradient_window(depth, rad=1)
    disp_grad = gradient_window(disparity, rad=1)
    gamma = float(np.abs(depth_grad).mean() / (np.abs(disp_grad).mean() + 1e-12))

    height, width = disparity.shape
    pad = rad * dilation
    disparity_pad = np.pad(disparity, pad, mode="edge")
    depth_pad = np.pad(depth, pad, mode="edge")

    risk = np.zeros((height, width), dtype=np.float64)
    weight_sum = np.zeros((height, width), dtype=np.float64)
    for i in range(-rad, rad + 1):
        for j in range(-rad, rad + 1):
            dy = i * dilation
            dx = j * dilation
            depth_q = depth_pad[pad + dy : pad + dy + height, pad + dx : pad + dx + width]
            disp_q = disparity_pad[pad + dy : pad + dy + height, pad + dx : pad + dx + width]

            delta_depth = depth - depth_q
            delta_disp = disparity - disp_q
            abs_depth = np.abs(delta_depth)
            abs_disp = np.abs(delta_disp)

            bad_rc = (abs_depth > 0.67 * gamma) & (delta_depth * delta_disp < 0)
            bad_vc1 = (abs_depth > 2.0 * gamma) & (abs_disp < 1.0)
            bad_vc2 = (abs_depth < gamma) & (abs_disp > 2.0)
            bad = bad_rc | bad_vc1 | bad_vc2

            # kernel-grid spatial weight, independent of dilation
            weight = kernel_grid_weight(i, j, spatial_sigma)
            valid = disp_q > 0
            risk += weight * bad * valid
            weight_sum += weight * valid

    return risk / (weight_sum + 1e-12)


def ddcv_proxy_lrc(
    disparity: np.ndarray,
    depth: np.ndarray,
    lr_error: np.ndarray,
    noc_ratio: float = 0.85,
    rad: int = 6,
    dilation: int = 4,
    spatial_sigma: float = 10.0,
) -> np.ndarray:
    """``ddcv_core`` plus this project's forward-warp pseudo-right LRC override.

    This is a **proxy**, not the official full reproduction: the official
    pipeline derives the right disparity from a second (flip-swapped) stereo
    forward. Here ``lr_error`` is the forward-warp consistency residual; pixels
    above the ``noc_ratio`` quantile have risk forced to 1.
    """
    risk = ddcv_core(disparity, depth, rad=rad, dilation=dilation, spatial_sigma=spatial_sigma)
    threshold = float(np.percentile(lr_error, noc_ratio * 100))
    return np.where(lr_error > threshold, 1.0, risk)
