"""V4 single-frame LR adapter matching upstream ddf2f57 tensor_warp."""

import numpy as np
import torch
import torch.nn.functional as F

from src.baselines.ddcv import ddcv_core


def reference_lr_residual(left: np.ndarray, right: np.ndarray) -> np.ndarray:
    """Right map is already unflipped from the flip-swapped stereo forward.

    Preserve upstream disparity/W with align_corners=True, including its
    effective (W-1)/W displacement and zero padding; no GT inputs.
    """
    left = np.asarray(left, dtype=np.float32)
    right = np.asarray(right, dtype=np.float32)
    if (left.ndim != 2 or right.shape != left.shape or min(left.shape) < 2
            or not np.isfinite(left).all() or not np.isfinite(right).all()):
        raise ValueError("LR maps must be finite matching 2D grids of size >=2")
    h, w = left.shape
    d = torch.from_numpy(left.copy()) / w
    if d.mean() > 0:
        d = -d
    x = torch.linspace(0, 1, w).repeat(h, 1)
    y = torch.linspace(0, 1, h).unsqueeze(1).repeat(1, w)
    grid = torch.stack((x + d, y), dim=-1).unsqueeze(0)
    warped = F.grid_sample(torch.from_numpy(right.copy())[None, None],
                           2 * grid - 1, mode="bilinear",
                           padding_mode="zeros", align_corners=True)
    return np.abs(warped[0, 0].numpy() - left)


def ddcv_full_reference(left: np.ndarray, right: np.ndarray, mono: np.ndarray) -> np.ndarray:
    """Existing vote core plus upstream whole-frame 0.85 LR quantile."""
    residual = reference_lr_residual(left, right)
    if np.shape(mono) != np.shape(left) or not np.isfinite(mono).all():
        raise ValueError("mono must be finite and match the disparity grid")
    threshold = torch.quantile(torch.from_numpy(residual), 0.85).item()
    return np.where(residual > threshold, 1.0, ddcv_core(left, mono))
