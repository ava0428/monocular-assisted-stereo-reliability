"""Frozen input normalization for the R0/R1 reliability predictors.

Frozen by the Week 3 pre-training protocol clarification. Statistics come from
SceneFlow TRAIN only; validation, Middlebury and ETH3D must reuse these
constants and must never refit them.

Rules:
  RGB (already in [0,1])      x' = 2x - 1                       (no fitting)
  signed  (disparity, grads)  t  = sign(x) * log1p(|x|), then z-score
  nonneg  (photo, profiles)   t  = log1p(x),             then z-score
  z = (t - mean_train) / (std_train + 1e-6)
"""
from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable, Mapping

import numpy as np

from src.evidence.stereo_evidence import R0_CHANNELS, R1_CHANNELS

RGB_CHANNELS = ("rgb_0", "rgb_1", "rgb_2")
SIGNED_CHANNELS = ("disparity", "grad_x", "grad_y")
NONNEG_CHANNELS = (
    "photo_error",
    "profile_min_cost",
    "profile_margin",
    "profile_sharpness",
    "profile_ambiguity",
)
ZSCORED_CHANNELS = SIGNED_CHANNELS + NONNEG_CHANNELS

EPSILON = 1e-6
NORMALIZATION_SCHEMA = "sceneflow-r0r1-normalization-1"

assert set(RGB_CHANNELS) | set(SIGNED_CHANNELS) | set(NONNEG_CHANNELS) == set(R1_CHANNELS)
assert set(R0_CHANNELS) == set(RGB_CHANNELS) | set(SIGNED_CHANNELS)


def forward_transform(name: str, values: np.ndarray) -> np.ndarray:
    """Monotone transform applied before z-scoring (float64 preserved)."""
    if name in RGB_CHANNELS:
        return 2.0 * values - 1.0
    if name in SIGNED_CHANNELS:
        return np.sign(values) * np.log1p(np.abs(values))
    if name in NONNEG_CHANNELS:
        return np.log1p(values)
    raise KeyError(f"No frozen normalization rule for channel {name!r}")


@dataclass(frozen=True)
class NormalizationConstants:
    schema_version: str
    dataset: str
    split: str
    sample_count: int
    mean: dict[str, float]
    std: dict[str, float]

    def as_dict(self) -> dict[str, Any]:
        return {
            "schema_version": self.schema_version,
            "dataset": self.dataset,
            "split": self.split,
            "sample_count": self.sample_count,
            "epsilon": EPSILON,
            "rgb_rule": "x' = 2x - 1 (no fitting)",
            "signed_rule": "t = sign(x)*log1p(|x|) then z-score",
            "nonneg_rule": "t = log1p(x) then z-score",
            "zscore": "z = (t - mean_train) / (std_train + 1e-6)",
            "channels": {
                name: {"mean": self.mean[name], "std": self.std[name]} for name in ZSCORED_CHANNELS
            },
        }

    def digest(self) -> str:
        payload = json.dumps(self.as_dict(), sort_keys=True, separators=(",", ":")).encode("utf-8")
        return hashlib.sha256(payload).hexdigest()

    def save(self, path: Path) -> str:
        path.parent.mkdir(parents=True, exist_ok=True)
        payload = self.as_dict()
        digest = self.digest()
        payload["normalization_sha256"] = digest
        path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        return digest

    @staticmethod
    def load(path: Path) -> "NormalizationConstants":
        return NormalizationConstants.from_bytes(Path(path).read_bytes())

    @staticmethod
    def from_bytes(raw: bytes) -> "NormalizationConstants":
        """Parse from bytes, so a committed blob can be used instead of a file."""
        payload = json.loads(raw.decode("utf-8"))
        channels = payload["channels"]
        return NormalizationConstants(
            schema_version=payload["schema_version"],
            dataset=payload["dataset"],
            split=payload["split"],
            sample_count=int(payload["sample_count"]),
            mean={name: float(channels[name]["mean"]) for name in ZSCORED_CHANNELS},
            std={name: float(channels[name]["std"]) for name in ZSCORED_CHANNELS},
        )


class StreamingMoments:
    """float64 streaming accumulator for log-space mean and standard deviation."""

    def __init__(self, channels: Iterable[str]) -> None:
        self.channels = tuple(channels)
        self._sum = {name: 0.0 for name in self.channels}
        self._sumsq = {name: 0.0 for name in self.channels}
        self._count = {name: 0 for name in self.channels}
        self.nan_count = {name: 0 for name in self.channels}
        self.inf_count = {name: 0 for name in self.channels}

    def update(self, channel: str, values: np.ndarray) -> None:
        transformed = forward_transform(channel, np.asarray(values, dtype=np.float64))
        finite = np.isfinite(transformed)
        self.nan_count[channel] += int(np.isnan(transformed).sum())
        self.inf_count[channel] += int(np.isinf(transformed).sum())
        kept = transformed[finite]
        if kept.size == 0:
            return
        self._sum[channel] += float(kept.sum())
        self._sumsq[channel] += float(np.square(kept).sum())
        self._count[channel] += int(kept.size)

    def merge(self, other: "StreamingMoments") -> None:
        for name in self.channels:
            self._sum[name] += other._sum[name]
            self._sumsq[name] += other._sumsq[name]
            self._count[name] += other._count[name]
            self.nan_count[name] += other.nan_count[name]
            self.inf_count[name] += other.inf_count[name]

    def means(self) -> dict[str, float]:
        return {name: self._sum[name] / self._count[name] for name in self.channels}

    def stds(self) -> dict[str, float]:
        out = {}
        for name in self.channels:
            n = self._count[name]
            mean = self._sum[name] / n
            variance = max(self._sumsq[name] / n - mean * mean, 0.0)
            out[name] = float(np.sqrt(variance))
        return out


def forward_transform_torch(name: str, values):
    """Torch mirror of :func:`forward_transform` for on-device normalization."""
    import torch

    if name in RGB_CHANNELS:
        return 2.0 * values - 1.0
    if name in SIGNED_CHANNELS:
        return torch.sign(values) * torch.log1p(torch.abs(values))
    if name in NONNEG_CHANNELS:
        return torch.log1p(values)
    raise KeyError(f"No frozen normalization rule for channel {name!r}")


def normalize_features_torch(features, constants: NormalizationConstants):
    """Apply the frozen normalization to a ``[B, C, H, W]`` torch tensor.

    R0's channels are a strict prefix of R1's and share the same rules, so the
    channel set is selected from the tensor width.
    """
    import torch

    width = features.shape[1]
    if width == len(R0_CHANNELS):
        channels = R0_CHANNELS
    elif width == len(R1_CHANNELS):
        channels = R1_CHANNELS
    else:
        raise ValueError(f"Expected {len(R0_CHANNELS)} or {len(R1_CHANNELS)} channels, got {width}")
    normalized = []
    for index, name in enumerate(channels):
        transformed = forward_transform_torch(name, features[:, index])
        if name in RGB_CHANNELS:
            normalized.append(transformed)
        else:
            mean = constants.mean[name]
            std = constants.std[name]
            normalized.append((transformed - mean) / (std + EPSILON))
    return torch.stack(normalized, dim=1)


def normalize_features(features: np.ndarray, constants: NormalizationConstants) -> np.ndarray:
    """Apply the frozen normalization channel-by-channel (float32 output)."""
    if features.shape[0] != len(R1_CHANNELS):
        raise ValueError(f"Expected {len(R1_CHANNELS)} channels, got {features.shape[0]}")
    out = np.empty_like(features, dtype=np.float32)
    for index, name in enumerate(R1_CHANNELS):
        transformed = forward_transform(name, features[index].astype(np.float64))
        if name in RGB_CHANNELS:
            out[index] = transformed.astype(np.float32)
        else:
            z = (transformed - constants.mean[name]) / (constants.std[name] + EPSILON)
            out[index] = z.astype(np.float32)
    return out
