"""Week 4 mono5 + disagreement3 evidence — the frozen R2 feature specification.

Implements ``docs/WEEK4_R2_PROTOCOL.md`` §3 (mono 5 channels), §4 (the shared
neighbourhood and window definitions) and §7 (the three disagreement channels),
and nothing else. The channel set, the operators and the constants are frozen:
this module may not add a sixth mono channel, a fourth disagreement, or a second
neighbourhood.

Every new channel is **analytically bounded**, so no dataset statistic is fitted
anywhere — there is no mean/std, no percentile, no winsorization and no
per-image fitted scale in this file.

Geometry, frozen (§4):

    N(p)     16 neighbours = 8 compass directions x radii {1, 2}
    W5(p)    5x5 box
    Sobel    3x3
    padding  REFLECT_101  (PyTorch ``mode="reflect"``, which does not repeat
             the edge sample — identical to ``cv2.BORDER_REFLECT_101``)
    eps      1e-6

Two numerical conventions are not fixed by the protocol text and are resolved
here **from the repository's own frozen convention, never from a metric**:

1. **Sobel scale.** ``cv2.Sobel(..., ksize=3)`` uses the standard 3x3 Sobel
   kernel at scale 1 (8x the analytic derivative), which is exactly the operator
   behind the frozen R0/R1 ``grad_x``/``grad_y`` channels in
   :mod:`src.evidence.stereo_evidence`. The same convention is used here so the
   stereo and mono structural channels are computed by one operator. It cancels
   in every ratio except ``mono_boundary_strength`` / ``D_boundary``, where it
   sets the gradient-vs-range scale.
2. **Mono polarity.** The frozen DA-V2-Small relative model returns a
   disparity-like map — the vendor demo labels its raw output "can be
   considered as disparity" (``third_party/Depth-Anything-V2-main/app.py``), and
   the frozen config records ``output: raw_relative_depth``. Larger therefore
   means nearer, matching the frozen ``positive_left_disparity`` convention, and
   **no flip or inversion is applied**.
"""
from __future__ import annotations

from typing import Final

import torch
import torch.nn.functional as F

from src.evidence.stereo_evidence import R1_CHANNELS

#: The five frozen mono channels, in frozen order.
MONO_CHANNELS: Final[tuple[str, ...]] = (
    "mono_grad_x_norm",
    "mono_grad_y_norm",
    "mono_boundary_strength",
    "mono_rank_stability",
    "mono_multiscale_stability",
)

#: The three frozen disagreement channels, in frozen order (V3 §9.2–§9.4).
DISAGREEMENT_CHANNELS: Final[tuple[str, ...]] = ("D_order", "D_grad", "D_boundary")

#: ``R2-concat`` = R1(11) + mono5.
R2_CONCAT_CHANNELS: Final[tuple[str, ...]] = R1_CHANNELS + MONO_CHANNELS

#: ``R2-dis`` = R1(11) + mono5 + disagreement3.
R2_DIS_CHANNELS: Final[tuple[str, ...]] = R1_CHANNELS + MONO_CHANNELS + DISAGREEMENT_CHANNELS

#: ``R2-gate`` input widths: stereo branch R1(11), mono/disagreement branch 8.
R2_GATE_STEREO_CHANNELS: Final[int] = len(R1_CHANNELS)
R2_GATE_MONO_DIS_CHANNELS: Final[int] = len(MONO_CHANNELS) + len(DISAGREEMENT_CHANNELS)

#: The 8 compass directions as (name, drow, dcol).
COMPASS: Final[tuple[tuple[str, int, int], ...]] = (
    ("E", 0, 1),
    ("NE", -1, 1),
    ("N", -1, 0),
    ("NW", -1, -1),
    ("W", 0, -1),
    ("SW", 1, -1),
    ("S", 1, 0),
    ("SE", 1, 1),
)
NEIGHBOUR_RADII: Final[tuple[int, ...]] = (1, 2)
LOCAL_WINDOW: Final[int] = 5
EPS: Final[float] = 1e-6

# The frozen 3x3 Sobel kernels at scale 1 — the same operator behind the frozen
# R0/R1 grad_x/grad_y channels (src.evidence.stereo_evidence._gradients).
_SOBEL_X: Final[torch.Tensor] = torch.tensor(
    [[-1.0, 0.0, 1.0], [-2.0, 0.0, 2.0], [-1.0, 0.0, 1.0]]
).view(1, 1, 3, 3)
_SOBEL_Y: Final[torch.Tensor] = torch.tensor(
    [[-1.0, -2.0, -1.0], [0.0, 0.0, 0.0], [1.0, 2.0, 1.0]]
).view(1, 1, 3, 3)


def _check_single_channel(x: torch.Tensor, name: str) -> None:
    if not isinstance(x, torch.Tensor):
        raise TypeError(f"{name} must be a torch.Tensor, got {type(x).__name__}")
    if x.dim() != 4 or x.shape[1] != 1:
        raise ValueError(f"{name} must be [B,1,H,W], got {tuple(x.shape)}")
    if not x.is_floating_point():
        raise ValueError(f"{name} must be floating point, got {x.dtype}")


def _pad_reflect(x: torch.Tensor, pad: int) -> torch.Tensor:
    """REFLECT_101 padding — identical to ``cv2.BORDER_REFLECT_101``."""
    if pad == 0:
        return x
    height, width = x.shape[-2:]
    if height <= pad or width <= pad:
        raise ValueError(
            f"REFLECT_101 needs both spatial dims > pad ({pad}), got {(height, width)}"
        )
    return F.pad(x, (pad, pad, pad, pad), mode="reflect")


def sobel(x: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
    """3x3 Sobel, REFLECT_101, matching the frozen ``cv2.Sobel`` convention."""
    _check_single_channel(x, "sobel input")
    padded = _pad_reflect(x, 1)
    kernel_x = _SOBEL_X.to(device=x.device, dtype=x.dtype)
    kernel_y = _SOBEL_Y.to(device=x.device, dtype=x.dtype)
    return (
        F.conv2d(padded, kernel_x),
        F.conv2d(padded, kernel_y),
    )


def box5(x: torch.Tensor) -> torch.Tensor:
    """5x5 box mean over W5(p), REFLECT_101."""
    _check_single_channel(x, "box5 input")
    return F.avg_pool2d(_pad_reflect(x, LOCAL_WINDOW // 2), kernel_size=LOCAL_WINDOW, stride=1)


def local_range5(x: torch.Tensor) -> torch.Tensor:
    """R5(p) = max - min over W5(p), REFLECT_101."""
    _check_single_channel(x, "local_range5 input")
    padded = _pad_reflect(x, LOCAL_WINDOW // 2)
    maximum = F.max_pool2d(padded, kernel_size=LOCAL_WINDOW, stride=1)
    minimum = -F.max_pool2d(-padded, kernel_size=LOCAL_WINDOW, stride=1)
    return maximum - minimum


def neighbour(x: torch.Tensor, drow: int, dcol: int, radius: int) -> torch.Tensor:
    """The neighbour of every pixel at ``(drow, dcol) * radius``, REFLECT_101."""
    _check_single_channel(x, "neighbour input")
    if radius not in NEIGHBOUR_RADII or (drow, dcol) == (0, 0):
        raise ValueError(f"({drow}, {dcol}) at radius {radius} is not in the frozen set")
    reach = max(NEIGHBOUR_RADII)
    padded = _pad_reflect(x, reach)
    height, width = x.shape[-2:]
    top = reach + drow * radius
    left = reach + dcol * radius
    return padded[:, :, top : top + height, left : left + width]


def mono_features(mono_relative_depth: torch.Tensor) -> torch.Tensor:
    """The frozen mono5 channels, ``[B,1,H,W] -> [B,5,H,W]``.

    ``m`` is the raw frozen DA-V2-Small relative-depth output (disparity-like:
    larger means nearer). Every channel is alignment-free and analytically
    bounded, so no statistic is fitted and no affine alignment is needed.
    """
    _check_single_channel(mono_relative_depth, "mono_relative_depth")
    mono = mono_relative_depth

    grad_x, grad_y = sobel(mono)
    # S(p) = local RMS gradient magnitude (V3 §3).
    gradient_scale = torch.sqrt(box5(grad_x * grad_x) + box5(grad_y * grad_y))
    range5 = local_range5(mono)
    smoothed = box5(mono)
    grad_x2, grad_y2 = sobel(smoothed)

    mono_grad_x_norm = grad_x / (grad_x.abs() + gradient_scale + EPS)
    mono_grad_y_norm = grad_y / (grad_y.abs() + gradient_scale + EPS)
    mono_boundary_strength = gradient_scale / (gradient_scale + range5 + EPS)

    agree = torch.zeros_like(mono)
    for _name, drow, dcol in COMPASS:
        near = torch.sign(mono - neighbour(mono, drow, dcol, 1))
        far = torch.sign(mono - neighbour(mono, drow, dcol, 2))
        agree = agree + (near == far).to(mono.dtype)
    mono_rank_stability = agree / float(len(COMPASS))

    numerator = (grad_x * grad_x2 + grad_y * grad_y2).abs()
    denominator = (
        torch.sqrt(grad_x * grad_x + grad_y * grad_y)
        * torch.sqrt(grad_x2 * grad_x2 + grad_y2 * grad_y2)
        + EPS
    )
    mono_multiscale_stability = numerator / denominator

    return torch.cat(
        [
            mono_grad_x_norm,
            mono_grad_y_norm,
            mono_boundary_strength,
            mono_rank_stability,
            mono_multiscale_stability,
        ],
        dim=1,
    )


def disagreement_features(
    disparity: torch.Tensor,
    mono_relative_depth: torch.Tensor,
    mono: torch.Tensor | None = None,
) -> torch.Tensor:
    """The frozen disagreement3 channels, ``[B,1,H,W] x [B,1,H,W] -> [B,3,H,W]``.

    ``mono`` may be passed as the already-computed mono5 batch to avoid
    recomputation; it is recomputed from ``mono_relative_depth`` otherwise, which
    is the path ``N-shuffle`` takes after permuting the raw mono map.
    """
    _check_single_channel(disparity, "disparity")
    _check_single_channel(mono_relative_depth, "mono_relative_depth")
    if disparity.shape != mono_relative_depth.shape:
        raise ValueError(
            f"disparity and mono must share a shape, got "
            f"{tuple(disparity.shape)} and {tuple(mono_relative_depth.shape)}"
        )
    if mono is None:
        mono = mono_features(mono_relative_depth)
    if mono.dim() != 4 or mono.shape[1] != len(MONO_CHANNELS):
        raise ValueError(f"mono must be [B,{len(MONO_CHANNELS)},H,W], got {tuple(mono.shape)}")
    if mono.shape[0] != disparity.shape[0] or mono.shape[-2:] != disparity.shape[-2:]:
        raise ValueError("mono must match the disparity batch and spatial shape")

    mono_grad_x_norm = mono[:, 0:1]
    mono_grad_y_norm = mono[:, 1:2]
    mono_boundary_strength = mono[:, 2:3]

    # D_order — V3 §9.2, averaged over the frozen 16-neighbour set.
    mismatches = torch.zeros_like(disparity)
    for _name, drow, dcol in COMPASS:
        for radius in NEIGHBOUR_RADII:
            stereo_order = torch.sign(disparity - neighbour(disparity, drow, dcol, radius))
            mono_order = torch.sign(
                mono_relative_depth - neighbour(mono_relative_depth, drow, dcol, radius)
            )
            mismatches = mismatches + (stereo_order != mono_order).to(disparity.dtype)
    d_order = mismatches / float(len(COMPASS) * len(NEIGHBOUR_RADII))

    # D_grad — V3 §9.3, after the same separate local normalisation as mono 1-2.
    dx, dy = sobel(disparity)
    disparity_scale = torch.sqrt(box5(dx * dx) + box5(dy * dy))
    gx_stereo_norm = dx / (dx.abs() + disparity_scale + EPS)
    gy_stereo_norm = dy / (dy.abs() + disparity_scale + EPS)
    d_grad = 0.25 * (
        (gx_stereo_norm - mono_grad_x_norm).abs() + (gy_stereo_norm - mono_grad_y_norm).abs()
    )

    # D_boundary — V3 §9.4, the same rule as mono channel 3.
    b_stereo = disparity_scale / (disparity_scale + local_range5(disparity) + EPS)
    d_boundary = (b_stereo - mono_boundary_strength).abs()

    return torch.cat([d_order, d_grad, d_boundary], dim=1)


def r2_evidence(
    disparity: torch.Tensor, mono_relative_depth: torch.Tensor
) -> torch.Tensor:
    """The full 8-channel mono/disagreement block used by ``R2-dis``/``R2-gate``."""
    mono = mono_features(mono_relative_depth)
    return torch.cat([mono, disagreement_features(disparity, mono_relative_depth, mono)], dim=1)


def shuffle_mono_in_batch(mono_relative_depth: torch.Tensor, permutation: torch.Tensor) -> torch.Tensor:
    """``N-shuffle``: replace each sample's mono map with another's, deterministically.

    The permutation is supplied by the caller (a fixed, recorded rule) and the
    mono5/disagreement3 channels are **recomputed** from the shuffled raw map,
    as the frozen protocol requires — never by permuting precomputed features.
    """
    _check_single_channel(mono_relative_depth, "mono_relative_depth")
    batch = mono_relative_depth.shape[0]
    if permutation.dim() != 1 or permutation.numel() != batch:
        raise ValueError(f"permutation must be [{batch}], got {tuple(permutation.shape)}")
    if batch > 1 and bool((permutation == torch.arange(batch, device=permutation.device)).all()):
        raise ValueError("permutation must not be the identity")
    return mono_relative_depth[permutation.to(mono_relative_depth.device)]


def channel_ranges(batch: torch.Tensor) -> dict[str, tuple[float, float]]:
    """Min/max per channel, for the bounded-range assertions in the tests."""
    names = MONO_CHANNELS + DISAGREEMENT_CHANNELS
    if batch.shape[1] != len(names):
        raise ValueError(f"expected {len(names)} channels, got {batch.shape[1]}")
    return {
        name: (float(batch[:, index].min()), float(batch[:, index].max()))
        for index, name in enumerate(names)
    }
