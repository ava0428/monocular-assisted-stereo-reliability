from __future__ import annotations

import cv2
import numpy as np


R0_CHANNELS = ("rgb_0", "rgb_1", "rgb_2", "disparity", "grad_x", "grad_y")
R1_EXTRA_CHANNELS = (
    "photo_error",
    "profile_min_cost",
    "profile_margin",
    "profile_sharpness",
    "profile_ambiguity",
)
R1_CHANNELS = R0_CHANNELS + R1_EXTRA_CHANNELS

PROFILE_OFFSETS = (-2, -1, 0, 1, 2)
PROFILE_WINDOW = 3

# Channels that must never appear in predictor inputs.
FORBIDDEN_CHANNEL_TOKENS = (
    "mono",
    "depth_anything",
    "da_v2",
    "dav2",
    "relative_depth",
    "disagreement",
    "gt_error",
    "oracle",
    "abs_error",
    "middlebury",
)


def _pixel_grid(shape: tuple[int, int]) -> tuple[np.ndarray, np.ndarray]:
    height, width = shape
    xs = np.arange(width, dtype=np.float32)[None, :].repeat(height, axis=0)
    ys = np.arange(height, dtype=np.float32)[:, None].repeat(width, axis=1)
    return xs, ys


def _gradients(values: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    grad_x = cv2.Sobel(values.astype(np.float32), cv2.CV_32F, 1, 0, ksize=3)
    grad_y = cv2.Sobel(values.astype(np.float32), cv2.CV_32F, 0, 1, ksize=3)
    return grad_x, grad_y


def r0_features(left_rgb: np.ndarray, disparity: np.ndarray) -> np.ndarray:
    """R0 = final stereo output + appearance cues (V3 section 14.2).

    RGB, the frozen disparity, and its two spatial gradients. No stereo
    matching evidence and no monocular information.
    """
    if left_rgb.dtype != np.uint8 or left_rgb.ndim != 3 or left_rgb.shape[2] != 3:
        raise ValueError("left_rgb must be RGB uint8 HxWx3")
    if disparity.shape != left_rgb.shape[:2]:
        raise ValueError("disparity must match the image spatial shape")
    rgb = left_rgb.astype(np.float32) / 255.0
    grad_x, grad_y = _gradients(disparity)
    return np.stack(
        [rgb[:, :, 0], rgb[:, :, 1], rgb[:, :, 2], disparity.astype(np.float32), grad_x, grad_y],
        axis=0,
    )


def photometric_error(left_rgb: np.ndarray, right_rgb: np.ndarray, disparity: np.ndarray) -> np.ndarray:
    """Photometric reprojection error E_photo (V3 section 8.2)."""
    height, width = disparity.shape
    xs, ys = _pixel_grid((height, width))
    # Resample the float image, not the uint8 one: cv2 returns a uint8 result
    # for a uint8 source, and that 8-bit rounding cannot be reproduced exactly
    # by an independent implementation. Both paths therefore evaluate the
    # bilinear-sampling specification itself.
    warped = cv2.remap(
        right_rgb.astype(np.float32),
        xs - disparity.astype(np.float32),
        ys,
        cv2.INTER_LINEAR,
        borderMode=cv2.BORDER_REPLICATE,
    )
    return np.abs(left_rgb.astype(np.float32) - warped).mean(axis=2)


def rgb_to_gray(rgb_u8: np.ndarray) -> np.ndarray:
    """Exact float luma: Y = 0.299 R + 0.587 G + 0.114 B.

    This is the frozen feature specification. ``cv2.cvtColor`` implements an
    8-bit fixed-point approximation of it whose rounding cannot be reproduced
    exactly by any simple formula (measured: >=103 mismatching pixels per
    65536, always by 1 grey level), so both the CPU and the GPU path compute
    the specification directly and stay bit-comparable.
    """
    values = rgb_u8.astype(np.float32)
    return (
        0.299 * values[:, :, 0] + 0.587 * values[:, :, 1] + 0.114 * values[:, :, 2]
    ).astype(np.float32)


def local_matching_profile(
    left_rgb: np.ndarray,
    right_rgb: np.ndarray,
    disparity: np.ndarray,
    offsets: tuple[int, ...] = PROFILE_OFFSETS,
    window: int = PROFILE_WINDOW,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """Local matching profile evidence (V3 section 8.3).

    Returns (minimum cost, margin, sharpness, ambiguity) sampled at a few
    disparities around the prediction. Deliberately avoids rebuilding a large
    cost volume.
    """
    gray_left = rgb_to_gray(left_rgb)
    gray_right = rgb_to_gray(right_rgb)
    height, width = disparity.shape
    xs, ys = _pixel_grid((height, width))
    costs = []
    for delta in offsets:
        shifted = cv2.remap(
            gray_right,
            xs - disparity.astype(np.float32) + float(delta),
            ys,
            cv2.INTER_LINEAR,
            borderMode=cv2.BORDER_REPLICATE,
        )
        costs.append(cv2.boxFilter(np.abs(gray_left - shifted), -1, (window, window)))
    stacked = np.stack(costs, axis=0)
    ordered = np.sort(stacked, axis=0)
    min_cost = ordered[0]
    second_cost = ordered[1]
    margin = second_cost - min_cost
    sharpness = margin / (min_cost + 1e-6)
    ambiguity = 1.0 / (sharpness + 1e-6)
    return min_cost, margin, sharpness, ambiguity


def r1_features(left_rgb: np.ndarray, right_rgb: np.ndarray, disparity: np.ndarray) -> np.ndarray:
    """R1 = R0 + frozen stereo-specific evidence (no monocular input)."""
    r0 = r0_features(left_rgb, disparity)
    photo = photometric_error(left_rgb, right_rgb, disparity)
    min_cost, margin, sharpness, ambiguity = local_matching_profile(left_rgb, right_rgb, disparity)
    extra = np.stack([photo, min_cost, margin, sharpness, ambiguity], axis=0)
    return np.concatenate([r0, extra], axis=0)


def assert_no_forbidden_channels(channels: tuple[str, ...]) -> None:
    for name in channels:
        lowered = name.lower()
        for token in FORBIDDEN_CHANNEL_TOKENS:
            if token in lowered:
                raise ValueError(f"Forbidden predictor channel {name!r} matches {token!r}")
