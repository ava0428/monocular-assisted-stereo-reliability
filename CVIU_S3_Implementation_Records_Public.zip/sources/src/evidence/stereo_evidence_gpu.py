"""GPU (PyTorch/CUDA) implementation of the frozen R0/R1 stereo evidence.

Mathematically equivalent to ``stereo_evidence.py``. The formulas, the number
of disparity offsets, the sampling convention, the border conventions and the
window size are all unchanged; only the execution backend differs.

Border conventions matched exactly:
  cv2.Sobel   -> BORDER_REFLECT_101  -> torch F.pad(mode="reflect")
  cv2.remap   -> BORDER_REPLICATE    -> grid_sample(padding_mode="border")
  cv2.boxFilter -> BORDER_REFLECT_101 -> F.pad(mode="reflect") then avg_pool2d

Parity is established by ``scripts/check_feature_parity.py``; see
``docs/WEEK3_TRAINING_READINESS.md`` for the recorded tolerances.
"""
from __future__ import annotations

import torch
import torch.nn.functional as F

from src.evidence.stereo_evidence import PROFILE_OFFSETS, PROFILE_WINDOW

_SOBEL_X = torch.tensor(
    [[-1.0, 0.0, 1.0], [-2.0, 0.0, 2.0], [-1.0, 0.0, 1.0]], dtype=torch.float32
)
_SOBEL_Y = torch.tensor(
    [[-1.0, -2.0, -1.0], [0.0, 0.0, 0.0], [1.0, 2.0, 1.0]], dtype=torch.float32
)


def _kernel(template: torch.Tensor, channels: int, device: torch.device) -> torch.Tensor:
    return template.to(device).view(1, 1, 3, 3).repeat(channels, 1, 1, 1)


def as_bchw_rgb(image: torch.Tensor) -> torch.Tensor:
    """Accept numpy-style HWC uint8 or an already-batched BCHW tensor."""
    if image.dim() == 3:
        return image.permute(2, 0, 1).unsqueeze(0)
    if image.dim() == 4:
        return image
    raise ValueError(f"RGB must be HWC or BCHW, got shape {tuple(image.shape)}")


def as_bchw_scalar(values: torch.Tensor) -> torch.Tensor:
    """Accept numpy-style HW or batched BCHW."""
    if values.dim() == 2:
        return values.unsqueeze(0).unsqueeze(0)
    if values.dim() == 3:
        return values.unsqueeze(0)
    if values.dim() == 4:
        return values
    raise ValueError(f"Scalar map must be HW, CHW or BCHW, got shape {tuple(values.shape)}")


def gradients_gpu(disparity: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
    """Sobel gradients with REFLECT_101 borders, matching cv2.Sobel."""
    disparity = as_bchw_scalar(disparity)
    channels = disparity.shape[1]
    padded = F.pad(disparity, (1, 1, 1, 1), mode="reflect")
    grad_x = F.conv2d(padded, _kernel(_SOBEL_X, channels, disparity.device), groups=channels)
    grad_y = F.conv2d(padded, _kernel(_SOBEL_Y, channels, disparity.device), groups=channels)
    return grad_x, grad_y


def _pixel_grid(height: int, width: int, device: torch.device) -> tuple[torch.Tensor, torch.Tensor]:
    xs = torch.arange(width, dtype=torch.float32, device=device).view(1, 1, 1, width).expand(1, 1, height, width)
    ys = torch.arange(height, dtype=torch.float32, device=device).view(1, 1, height, 1).expand(1, 1, height, width)
    return xs, ys


def sample_bilinear(img: torch.Tensor, map_x: torch.Tensor, map_y: torch.Tensor) -> torch.Tensor:
    """Bilinear sampling with REPLICATE borders, matching cv2.remap + INTER_LINEAR."""
    height = img.shape[-2]
    width = img.shape[-1]
    batch = img.shape[0]
    gx = (2.0 * map_x / max(width - 1, 1) - 1.0).expand(batch, 1, height, width)
    gy = (2.0 * map_y / max(height - 1, 1) - 1.0).expand(batch, 1, height, width)
    grid = torch.cat([gx, gy], dim=1).permute(0, 2, 3, 1)  # [B,H,W,2]
    return F.grid_sample(
        img, grid, mode="bilinear", padding_mode="border", align_corners=True
    )


def sample_bilinear_u8(img_u8: torch.Tensor, map_x: torch.Tensor, map_y: torch.Tensor) -> torch.Tensor:
    """Bilinear sampling that reproduces cv2.remap on a uint8 source.

    OpenCV returns a uint8 image for a uint8 source, so the interpolated value
    is rounded back to an integer (half-to-even). Skipping this quantization
    would diverge from the frozen CPU reference by up to half a grey level.
    """
    warped = sample_bilinear(img_u8.float(), map_x, map_y)
    return warped.round().clamp_(0.0, 255.0)


def rgb_to_gray_gpu(rgb_u8: torch.Tensor) -> torch.Tensor:
    """Exact float luma: Y = 0.299 R + 0.587 G + 0.114 B.

    Shares the frozen specification with ``stereo_evidence.rgb_to_gray``. The
    cv2 fixed-point approximation is deliberately not used here, because it
    cannot be reproduced exactly and would break CPU/GPU comparability.
    """
    rgb_u8 = as_bchw_rgb(rgb_u8)
    values = rgb_u8.float()
    return 0.299 * values[:, 0:1] + 0.587 * values[:, 1:2] + 0.114 * values[:, 2:3]


def box_filter_gpu(values: torch.Tensor, window: int) -> torch.Tensor:
    """Normalized box filter with REFLECT_101 borders, matching cv2.boxFilter."""
    pad = window // 2
    padded = F.pad(values, (pad, pad, pad, pad), mode="reflect")
    return F.avg_pool2d(padded, kernel_size=window, stride=1)


def r0_features_gpu(left_rgb: torch.Tensor, disparity: torch.Tensor) -> torch.Tensor:
    """R0 on GPU: RGB + frozen disparity + its two Sobel gradients."""
    left_rgb = as_bchw_rgb(left_rgb)
    disparity = as_bchw_scalar(disparity)
    rgb = left_rgb.float() / 255.0
    grad_x, grad_y = gradients_gpu(disparity.float())
    return torch.cat(
        [rgb[:, 0:1], rgb[:, 1:2], rgb[:, 2:3], disparity.float(), grad_x, grad_y], dim=1
    )


def photometric_error_gpu(
    left_rgb: torch.Tensor, right_rgb: torch.Tensor, disparity: torch.Tensor
) -> torch.Tensor:
    left_rgb = as_bchw_rgb(left_rgb)
    right_rgb = as_bchw_rgb(right_rgb)
    disparity = as_bchw_scalar(disparity)
    height, width = disparity.shape[-2:]
    xs, ys = _pixel_grid(height, width, disparity.device)
    warped = sample_bilinear(right_rgb.float(), xs - disparity.float(), ys)
    return (left_rgb.float() - warped).abs().mean(dim=1, keepdim=True)


def local_matching_profile_gpu(
    left_rgb: torch.Tensor,
    right_rgb: torch.Tensor,
    disparity: torch.Tensor,
    offsets: tuple[int, ...] = PROFILE_OFFSETS,
    window: int = PROFILE_WINDOW,
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
    left_rgb = as_bchw_rgb(left_rgb)
    right_rgb = as_bchw_rgb(right_rgb)
    disparity = as_bchw_scalar(disparity)
    gray_left = rgb_to_gray_gpu(left_rgb)
    gray_right = rgb_to_gray_gpu(right_rgb)
    height, width = disparity.shape[-2:]
    xs, ys = _pixel_grid(height, width, disparity.device)
    costs = []
    for delta in offsets:
        shifted = sample_bilinear(gray_right, xs - disparity.float() + float(delta), ys)
        costs.append(box_filter_gpu((gray_left - shifted).abs(), window))
    stacked = torch.cat(costs, dim=1)  # [B, len(offsets), H, W]
    ordered, _ = torch.sort(stacked, dim=1)
    min_cost = ordered[:, 0:1]
    second_cost = ordered[:, 1:2]
    margin = second_cost - min_cost
    sharpness = margin / (min_cost + 1e-6)
    ambiguity = 1.0 / (sharpness + 1e-6)
    return min_cost, margin, sharpness, ambiguity


def r1_features_gpu(
    left_rgb: torch.Tensor, right_rgb: torch.Tensor, disparity: torch.Tensor
) -> torch.Tensor:
    """R1 on GPU: R0 plus the frozen stereo-specific evidence."""
    r0 = r0_features_gpu(left_rgb, disparity)
    photo = photometric_error_gpu(left_rgb, right_rgb, disparity)
    min_cost, margin, sharpness, ambiguity = local_matching_profile_gpu(left_rgb, right_rgb, disparity)
    return torch.cat([r0, photo, min_cost, margin, sharpness, ambiguity], dim=1)
