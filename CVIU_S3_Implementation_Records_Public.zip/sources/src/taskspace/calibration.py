"""``C1_d`` and ``C1_z`` — the two calibrators, and ``Omega_z``.

Frozen by specification body §2.1, §2.2, §2.3 and §8.2.

``C1_d`` is the Week 5 split-conformal radius, reused verbatim and in disparity
pixels. ``C1_z`` is a different object in a different unit: a **one-sided
calibrated upper bound on ``AbsRel``**, dimensionless. Substituting one for the
other is a units error, not a modelling choice.

``C1_z`` claims no finite-sample coverage guarantee. ``guarantee_claimed`` is
``False`` and the probability statement is prohibited: the calibration pixels are
pooled within a scene, and pixels within a scene are strongly spatially
correlated, so individual-pixel exchangeability is not established here.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Mapping

import numpy as np

# The frozen Week 5 rank. Imported rather than reimplemented so the parity is
# structural: there is exactly one definition of k in the repository.
from src.calibration.calibrators import conformal_rank

from src.taskspace.spec import (
    C1Z_EMPTY_DOMAIN_EFFECT,
    C1Z_FIT_DOMAIN,
    C1Z_GATE_ROLE,
    C1Z_GUARANTEE_CLAIMED,
    C1Z_OPERATIONAL_TARGET,
    C1Z_PROBABILITY_CLAIM,
    C1Z_RESULT_NAME,
    conformal_rank as spec_conformal_rank,
)


class CalibrationDomainEmpty(RuntimeError):
    """``Omega_z`` is empty: the diagnostic is UNAVAILABLE. Checkpoint 4 is not."""


class RankExceedsSamples(RuntimeError):
    """``k > n`` is a HARD FAILURE and is never capped to ``n``."""


@dataclass(frozen=True)
class C1d:
    """``C1_d`` — disadvantage-space additive split-conformal radius, in pixels."""

    delta: float
    tau: float
    n: int
    k: int

    def radius(self, h0: np.ndarray) -> np.ndarray:
        return np.maximum(0.0, np.asarray(h0, np.float64) + self.delta)


def fit_c1d(errors: np.ndarray, h0: np.ndarray, tau: float) -> C1d:
    """Fit ``C1_d`` on the calibration pixels' pooled residuals."""
    e = np.asarray(errors, dtype=np.float64).ravel()
    base = np.asarray(h0, dtype=np.float64).ravel()
    if e.size != base.size:
        raise ValueError("errors and h0 must have the same length")
    finite = np.isfinite(e) & np.isfinite(base)
    residuals = (e - base)[finite]
    n = residuals.size
    if n == 0:
        raise CalibrationDomainEmpty("C1_d has no finite calibration residual")
    k = spec_conformal_rank(n, tau)
    if k > n:
        raise RankExceedsSamples(f"C1_d: k = {k} > n = {n}; the level is uncertifiable")
    return C1d(delta=float(np.sort(residuals)[k - 1]), tau=tau, n=n, k=k)


# ---------------------------------------------------------------------------
# Omega_z
# ---------------------------------------------------------------------------

def omega_z_mask(
    universe: np.ndarray,
    *,
    depth_denominator_ok: np.ndarray,
    target: np.ndarray,
    raw_output: np.ndarray,
) -> np.ndarray:
    """``Omega_z = {p in Omega : d_pred + d_offs > 0, t finite, u finite}``.

    ``AbsRel`` is not a finite calibration target where the depth denominator is
    non-positive, so ``C1_z`` cannot be fitted on all of ``Omega``.

    ``Omega_z`` MUST NOT replace the task operand ``Omega``: substituting it would
    silently delete the hardest pixels, which is exactly what the GT-defined
    universe exists to prevent.
    """
    uni = np.asarray(universe, dtype=bool)
    ok = np.asarray(depth_denominator_ok, dtype=bool)
    t = np.asarray(target, dtype=np.float64)
    u = np.asarray(raw_output, dtype=np.float64)
    return uni & ok & np.isfinite(t) & np.isfinite(u)


@dataclass(frozen=True)
class OmegaZReport:
    n_omega: int
    n_omega_z: int
    excluded_nonpositive_denominator: int
    excluded_nonfinite_target: int
    excluded_nonfinite_output: int

    @property
    def excluded_total(self) -> int:
        return self.n_omega - self.n_omega_z


def omega_z_report(
    universe: np.ndarray,
    *,
    depth_denominator_ok: np.ndarray,
    target: np.ndarray,
    raw_output: np.ndarray,
) -> OmegaZReport:
    """|Omega|, |Omega_z| and the exclusion breakdown, as the freeze requires."""
    uni = np.asarray(universe, dtype=bool)
    ok = np.asarray(depth_denominator_ok, dtype=bool)
    t = np.asarray(target, dtype=np.float64)
    u = np.asarray(raw_output, dtype=np.float64)
    keep = omega_z_mask(uni, depth_denominator_ok=ok, target=t, raw_output=u)
    inside = uni & ~keep
    return OmegaZReport(
        n_omega=int(np.count_nonzero(uni)),
        n_omega_z=int(np.count_nonzero(keep)),
        excluded_nonpositive_denominator=int(np.count_nonzero(inside & ~ok)),
        excluded_nonfinite_target=int(np.count_nonzero(inside & ok & ~np.isfinite(t))),
        excluded_nonfinite_output=int(np.count_nonzero(inside & ok & np.isfinite(t) & ~np.isfinite(u))),
    )


# ---------------------------------------------------------------------------
# C1_z
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class C1z:
    """``C1_z`` — a ONE-SIDED calibrated upper bound on ``AbsRel``.

    ``r1 = expm1(max(0, max(u, 0) + delta))``. This is an upper bound on a
    dimensionless ratio. It is **not** a symmetric depth interval, not a depth
    interval, and not an interval in metres.
    """

    delta: float
    tau: float
    n: int
    k: int
    report: OmegaZReport | None = None

    @property
    def guarantee_claimed(self) -> bool:
        return C1Z_GUARANTEE_CLAIMED

    @property
    def probability_claim(self) -> str:
        return C1Z_PROBABILITY_CLAIM

    @property
    def operational_target(self) -> str:
        return C1Z_OPERATIONAL_TARGET

    @property
    def result_name(self) -> str:
        return C1Z_RESULT_NAME

    @property
    def domain(self) -> str:
        return C1Z_FIT_DOMAIN

    def upper_bound(self, raw_output: np.ndarray) -> np.ndarray:
        u = np.asarray(raw_output, dtype=np.float64)
        b0 = np.maximum(u, 0.0)
        return np.expm1(np.maximum(0.0, b0 + self.delta))

    def empirical_coverage(self, upper_bound: np.ndarray, target: np.ndarray) -> float:
        """Fraction of ``Omega_z`` pixels whose target is at most the bound."""
        r1 = np.asarray(upper_bound, dtype=np.float64)
        t = np.asarray(target, dtype=np.float64)
        return float(np.mean(t <= r1))


def fit_c1z(target: np.ndarray, raw_output: np.ndarray, tau: float) -> C1z:
    """Fit ``C1_z`` on ``Omega_z`` only.

    The caller passes values already restricted to ``Omega_z``. An empty domain
    raises :class:`CalibrationDomainEmpty`; the caller reports the diagnostic
    UNAVAILABLE, and Checkpoint 4 is **not** affected.
    """
    t = np.asarray(target, dtype=np.float64).ravel()
    u = np.asarray(raw_output, dtype=np.float64).ravel()
    if t.size != u.size:
        raise ValueError("target and raw output must have the same length")
    finite = np.isfinite(t) & np.isfinite(u)
    t, u = t[finite], u[finite]
    n = t.size
    if n == 0:
        raise CalibrationDomainEmpty(
            f"{C1Z_EMPTY_DOMAIN_EFFECT}: Omega_z is empty"
        )
    b0 = np.maximum(u, 0.0)
    a = t - b0
    k = spec_conformal_rank(n, tau)
    if k > n:
        raise RankExceedsSamples(f"C1_z: k = {k} > n = {n}; the level is uncertifiable")
    return C1z(delta=float(np.sort(a)[k - 1]), tau=tau, n=n, k=k)


def c1z_enters_gate() -> bool:
    """``C1_z`` is never read by any Checkpoint 4 predicate. Structural isolation."""
    return C1Z_GATE_ROLE


def assert_c1d_parity(count: int, tau: float) -> None:
    """``C1_d``'s rank must equal the frozen Week 5 rank, exactly."""
    ours = spec_conformal_rank(count, tau)
    week5 = conformal_rank(count, tau)
    if ours != week5:
        raise AssertionError(f"C1_d rank {ours} != frozen Week 5 rank {week5}")


def checkpoints_by_seed(fits: Mapping[int, C1z]) -> Mapping[int, C1z]:
    """Seeds are kept strictly separate; pooling is refused."""
    seeds = sorted(fits)
    if len(seeds) != len(set(seeds)):
        raise ValueError("duplicate seed in calibration fits")
    return dict(fits)
