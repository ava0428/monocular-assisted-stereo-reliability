"""Week 6 / Checkpoint 4 frozen constants.

Every value here is copied from the **effective** frozen specification:

    docs/WEEK6_PROTOCOL_FREEZE_021.md
        sha256 bd4f9d973403dba1620842abe18cb388c56870c0b063d7d5ca969d42aab62ab4
    docs/PROTOCOL_AMENDMENT_WEEK6_021_DRAFT.md  @ Revision 5
        sha256 d35bf6613b3d2fc6c91ed9788856326420e10d51e278456d3ee9471ce39cb1bd

The freeze file governs where the two differ. Nothing in this module is a new
choice: if a value here disagrees with the frozen text, the code is wrong.

``UNRESOLVED`` is kept as a sentinel. A key that is reopened without a value
raises, exactly as the Week 5 specification does, so a missing freeze cannot be
papered over by a default.
"""
from __future__ import annotations

#: Sentinel meaning "no frozen value". Any result-bearing use must refuse.
UNRESOLVED = "UNRESOLVED_WEEK6_SPECIFICATION_BLOCKER"

#: The amendment that produced the frozen specification.
WEEK6_AMENDMENT = "PROTOCOL_AMENDMENT_WEEK6_021"

FROZEN_SPEC_PATH = "docs/WEEK6_PROTOCOL_FREEZE_021.md"
FROZEN_SPEC_SHA256 = "bd4f9d973403dba1620842abe18cb388c56870c0b063d7d5ca969d42aab62ab4"
SPECIFICATION_BODY_PATH = "docs/PROTOCOL_AMENDMENT_WEEK6_021_DRAFT.md"
SPECIFICATION_BODY_SHA256 = "d35bf6613b3d2fc6c91ed9788856326420e10d51e278456d3ee9471ce39cb1bd"

# ---------------------------------------------------------------------------
# tau and rho — two different quantities, never both called "coverage"
# ---------------------------------------------------------------------------

#: tau = nominal interval-coverage probability. Freeze §2.
TAU_VALUES = (0.90, 0.95)
TAU_GATE = 0.90

#: rho = selective retained-pixel fraction. Freeze §2.
RHO_GATE_LEVELS = (0.80, 0.90)

#: V3 §21's six-point retained-fraction grid. Always the same set. Freeze §8.1.
RHO_DRCA_GRID = (1.00, 0.95, 0.90, 0.80, 0.70, 0.50)

#: The bare word "coverage" is banned from keys, headers and formulas.
BARE_COVERAGE_WORD = "PROHIBITED"


def alpha(tau: float) -> float:
    """alpha = 1 - tau, the miscoverage probability. Freeze §1.1."""
    return 1.0 - tau


def conformal_rank(count: int, tau: float) -> int:
    """k = ceil((n + 1) * tau) = ceil((n + 1) * (1 - alpha)).

    Freeze §1.1. ``k > n`` is a HARD FAILURE and is never capped; the caller
    checks it.
    """
    import math

    if count < 1:
        raise ValueError("conformal rank needs at least one calibration sample")
    if not 0.0 < tau < 1.0:
        raise ValueError(f"tau must lie in (0, 1), got {tau}")
    return math.ceil((count + 1) * tau)


# ---------------------------------------------------------------------------
# metric-depth conversion
# ---------------------------------------------------------------------------

#: Z = f * B / (d + d_offs); f = cam0[0, 0]. Freeze §3.
FOCAL_INDEX = (0, 0)
DEPTH_FORMULA = "Z = f * B / (d + d_offs)"

#: Cross-dataset comparison of Depth MAE is PROHIBITED. Freeze §3, §8.
CROSS_DATASET_DEPTH_MAE_COMPARISON = "PROHIBITED"

#: Z_gt is derived from the cached GT disparity, never from a sensor depth map.
GT_DEPTH_SOURCE = "derived_from_gt_disparity"

# ---------------------------------------------------------------------------
# evaluation universe and invalid sets
# ---------------------------------------------------------------------------

#: Omega is defined by the frozen GT and mask ONLY. Freeze §4.
UNIVERSE_DEFINITION = "isfinite(d_gt) AND d_gt > 0 AND source_mask != 0"

#: Selection unit per dataset. Freeze §4.
SELECTION_UNIT = {"middlebury": "scene", "eth3d": "frame"}

#: Fusion of the invalid sets is a SET UNION, never a sum of cardinalities.
INVALID_FUSION = "set_union"

#: Understating N_risk_inf is the permissive error; the additive form is the
#: conservative one. Freeze §2 / correction 1.
ADDITIVE_FORM_DIRECTION = "TOO_STRICT_FALSE_HARD_FAILURE"

# ---------------------------------------------------------------------------
# failure taxonomy
# ---------------------------------------------------------------------------

CLASS_INPUT_UNDEFINED = "CLASS_1_NOT_EVALUABLE"
CLASS_METHOD_FAILURE = "CLASS_2_METHOD_PREDICATE_FALSE"
CLASS_THRESHOLD_MISS = "CLASS_3_SCIENTIFIC_FALSE"
CLASS_UNDEFINED_DENOMINATOR = "CLASS_4_SCIENTIFIC_FALSE"

#: The ONLY entry to NOT EVALUABLE. Freeze §5.
NOT_EVALUABLE_CLASSES = (CLASS_INPUT_UNDEFINED,)

UNDEFINED_DENOMINATOR_REASON = "UNDEFINED_RELATIVE_DENOMINATOR"

# ---------------------------------------------------------------------------
# improvement condition
# ---------------------------------------------------------------------------

REFERENCE_METHOD = "Gd"
GEOMETRIC_BASELINE = "Gz-push"
PRIMARY_CANDIDATE = "Grel-direct"

MINIMUM_RELATIVE_REDUCTION = 0.03
RELATIVE_REDUCTION_COMPARATOR = ">="
RELATIVE_REDUCTION_IS_CLOSED_BAND = False

#: Far depth tercile, the single frozen bin admitted to MODIFY. Freeze §10.2.
FAR_BIN = (2.0 / 3.0, 1.0)
DEPTH_TERCILE_NAMES = ("near", "mid", "far")

# ---------------------------------------------------------------------------
# seeds, aggregation, bootstrap
# ---------------------------------------------------------------------------

R2_GATE_SEEDS = (20260910, 20260911, 20260912)
SEED_RULE = "ALL_THREE_MUST_PASS_INDEPENDENTLY"
SEED_RULE_PROVENANCE = "NEW_CONSERVATIVE_RULE_OF_THIS_AMENDMENT_NOT_V3"

GATE_METRICS = ("depth_mae", "absrel")
GATE_METRICS_PROVENANCE = "V3_41_SLASH_JOINED_AND_IS_THIS_AMENDMENTS_PROSPECTIVE_READING"

AGGREGATION_MIDDLEBURY = "scene_macro"
AGGREGATION_ETH3D = "frame_then_physical_group_then_dataset"
AGGREGATION_SOURCE = "sample_macro"
CROSS_DATASET_POOLING = "PROHIBITED"

BOOTSTRAP_UNIT = {"middlebury": "scene", "eth3d": "physical_group"}
BOOTSTRAP_REPLICATES = 10_000
BOOTSTRAP_SEED = 20260913
BOOTSTRAP_GATING = False

# ---------------------------------------------------------------------------
# DRCA
# ---------------------------------------------------------------------------

DRCA_NAME = "DEPTH RISK-RETAINED-FRACTION AREA"
DRCA_DIVISOR = RHO_DRCA_GRID[0] - RHO_DRCA_GRID[-1]  # 1.00 - 0.50 = 0.50
DRCA_MINIMUM_GRID = 6
DRCA_GATE_ROLE = False

# ---------------------------------------------------------------------------
# source checkpoint selection
# ---------------------------------------------------------------------------

PROXYREL_DEFINITION = "|d_pred - d_gt| / d_pred"
PROXYREL_TARGET = "log1p(ProxyRel)"
SOURCE_METRIC_NAMES = ("ProxyRel-AURC", "ProxyRel-AUSE")
SOURCE_METRIC_PROHIBITED_NAMES = ("AbsRel-AURC", "AbsRel-AUSE")

SOURCE_SELECTION_RULE = (
    "min ProxyRel-AURC -> min ProxyRel-AUSE -> earlier step"
)
SOURCE_SELECTION_CADENCE = 2_000
SOURCE_MIN_VALID_PIXELS = 16
SOURCE_SAMPLE_FINITENESS = "ANY_NON_FINITE_PARTICIPATING_SAMPLE_FAILS_THE_RUN"
SOURCE_SILENT_FILTER = "PROHIBITED"

#: The forbidden tie-break. Freeze §7.
SOURCE_PROHIBITED_TIEBREAK = "Bad2-AUPRC with AbsRel > 0.10"

# ---------------------------------------------------------------------------
# C1_z
# ---------------------------------------------------------------------------

C1Z_OPERATIONAL_TARGET = (
    "empirical coverage of the one-sided AbsRel upper bound at nominal tau"
)
C1Z_GUARANTEE_CLAIMED = False
C1Z_PROBABILITY_CLAIM = "PROHIBITED"
C1Z_FIT_DOMAIN = "Omega_z"
C1Z_RESULT_NAME = "conditional calibration diagnostic"
C1Z_GATE_ROLE = False
C1Z_EMPTY_DOMAIN_EFFECT = "DIAGNOSTIC_UNAVAILABLE"

# ---------------------------------------------------------------------------
# three flows and Checkpoint 4 provenance
# ---------------------------------------------------------------------------

FLOW_MIDDLEBURY_CROSSFIT = "MIDDLEBURY-CROSSFIT"
FLOW_ETH3D_ZERO_LABEL = "ETH3D-ZERO-LABEL"
FLOW_ETH3D_TARGET_CALIBRATED = "ETH3D-TARGET-CALIBRATED"
FLOWS = (FLOW_MIDDLEBURY_CROSSFIT, FLOW_ETH3D_ZERO_LABEL, FLOW_ETH3D_TARGET_CALIBRATED)

CHECKPOINT4_ETH3D_EVALUATION_SET = "ETH3D-EVAL"
CHECKPOINT4_DISPARITY_CALIBRATION_SOURCE = "ETH3D-CAL"
CHECKPOINT4_GREL_GATE_SCORE = "RAW_U_NO_ETH3D_LABEL_FIT"
CHECKPOINT4_COMPARISON_PROVENANCE = "METHOD_SPECIFIC_CALIBRATION_PROVENANCE"

COMPARISON_LABEL = (
    "SCENE-DISJOINT PROJECT-UNSEEN EXTERNAL EVALUATION "
    "WITH METHOD-SPECIFIC CALIBRATION PROVENANCE"
)
LABEL_MIDDLEBURY_CROSSFIT = "CROSS_FITTED DEVELOPMENT EVIDENCE"
LABEL_ETH3D_ZERO_LABEL = (
    "MIDDLEBURY-DEVELOPMENT-CALIBRATED, ZERO-SHOT w.r.t. ETH3D LABELS, PROJECT-UNSEEN"
)
LABEL_ETH3D_TARGET_CALIBRATED = (
    "SCENE-DISJOINT TARGET-CALIBRATED PROJECT-UNSEEN EXTERNAL EVALUATION"
)

MODEL_PRETRAINING_UNSEEN = "NOT_ESTABLISHED"
BANNED_LABEL_TERMS = ("zero-shot", "unseen", "model-pretraining-unseen")

# ---------------------------------------------------------------------------
# Checkpoint 4 verdicts and reason codes
# ---------------------------------------------------------------------------

GO = "GO"
MODIFY = "MODIFY"
STOP = "STOP"
NOT_EVALUABLE = "NOT EVALUABLE"
ALLOWED_FINAL_STATES = (GO, MODIFY, STOP, NOT_EVALUABLE)

REASON_GO = "GO"
REASON_MODIFY_GEOMETRIC_BASELINE = "MODIFY_GEOMETRIC_BASELINE"
REASON_MODIFY_FAR_BIN = "MODIFY_FAR_BIN"
REASON_MODIFY_DATASET_DEPENDENT = "MODIFY_DATASET_DEPENDENT"
REASON_STOP = "STOP_GATE_NOT_MET"
REASON_STOP_SUPERSEDED = "STOP_NO_IMPROVEMENT"

#: MODIFY codes are emitted in this fixed lexicographic order; all that hold are
#: reported. Freeze §10.3.
MODIFY_REASON_CODES = tuple(
    sorted(
        (
            REASON_MODIFY_GEOMETRIC_BASELINE,
            REASON_MODIFY_FAR_BIN,
            REASON_MODIFY_DATASET_DEPENDENT,
        )
    )
)

PARTIAL_CREDIT = "NONE"

# ---------------------------------------------------------------------------
# authorisation
# ---------------------------------------------------------------------------

TRAINING_AUTHORISED = False
MIDDLEBURY_TASK_EXECUTION_AUTHORISED = False
ETH3D_ACCESS_AUTHORISED = False

ETH3D_STATUS = "LOCKED_EXTERNAL_TEST"
ETH3D_ENV_KEYS = ("V3_ETH3D_ROOT", "ETH3D_ROOT", "V3_ALLOW_ETH3D")
