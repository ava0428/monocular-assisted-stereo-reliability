"""Task-space geometry — the frozen metric-depth conversion and the push-forward.

Frozen by ``docs/WEEK6_PROTOCOL_FREEZE_021.md`` §3 and specification body §3, §6.
Every function here is a pure array transform; none of them reads data, and none
of them decides anything about a verdict.

The rule that matters most: a quantity that becomes non-finite is **reported as
non-finite**, never clamped, never replaced by a sentinel, never silently
converted into an ordinary finite risk.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from src.taskspace.spec import CROSS_DATASET_DEPTH_MAE_COMPARISON


class GeometryError(ValueError):
    """A geometry input is unusable in a way the frozen text does not allow."""


@dataclass(frozen=True)
class DepthScale:
    """The per-scene conversion constants, taken from the frozen cache."""

    fx: float
    baseline: float
    doffs: float
    unit: str = "dataset-native"

    def __post_init__(self) -> None:
        for name in ("fx", "baseline", "doffs"):
            value = getattr(self, name)
            if not np.isfinite(value):
                raise GeometryError(f"{name} is not finite: {value!r}")
        if self.fx <= 0 or self.baseline <= 0:
            raise GeometryError(
                f"focal and baseline must be positive, got fx={self.fx!r} baseline={self.baseline!r}"
            )

    @property
    def fB(self) -> float:
        return self.fx * self.baseline


def depth_from_disparity(disparity: np.ndarray, scale: DepthScale) -> np.ndarray:
    """``Z = f * B / (d + d_offs)``.

    A non-positive or non-finite denominator yields ``+inf`` — it is never
    clamped and never replaced by a large finite value.
    """
    array = np.asarray(disparity, dtype=np.float64)
    denominator = array + scale.doffs
    # np.divide with where= keeps the invalid entries non-finite instead of
    # raising, so the caller can classify them rather than lose them.
    with np.errstate(divide="ignore", invalid="ignore", over="ignore"):
        depth = np.divide(
            scale.fB,
            denominator,
            out=np.full(array.shape, np.inf, dtype=np.float64),
            where=np.isfinite(denominator) & (denominator > 0),
        )
    return depth


def depth_denominator_ok(disparity: np.ndarray, scale: DepthScale) -> np.ndarray:
    """Boolean mask: the point-depth denominator is positive and finite."""
    array = np.asarray(disparity, dtype=np.float64)
    denominator = array + scale.doffs
    return np.isfinite(denominator) & (denominator > 0)


@dataclass(frozen=True)
class PushedRisk:
    """The pushed-forward asymmetry plus its two membership signals."""

    q_z: np.ndarray
    q_z_minus: np.ndarray
    q_z_plus: np.ndarray
    lower_denominator_nonpositive: np.ndarray


def push_forward(
    disparity: np.ndarray,
    half_width: np.ndarray,
    scale: DepthScale,
) -> PushedRisk:
    """Exact asymmetric push-forward of ``[d - q_d, d + q_d]``.

    ``q_Z = maximum(q_Z_minus, q_Z_plus)`` — V3 §19.2's own conservative scalar,
    frozen. Where the far denominator ``d - q_d + d_offs`` is non-positive,
    ``q_Z_plus`` is ``+inf`` and the pixel keeps its (finite) point depth but is
    ranked worst. That membership is reported, not erased.
    """
    d = np.asarray(disparity, dtype=np.float64)
    q = np.asarray(half_width, dtype=np.float64)
    if d.shape != q.shape:
        raise GeometryError(f"disparity {d.shape} and half-width {q.shape} must match")

    z = depth_from_disparity(d, scale)
    z_near = depth_from_disparity(d + q, scale)

    lower_denominator = d - q + scale.doffs
    lower_ok = np.isfinite(lower_denominator) & (lower_denominator > 0)
    with np.errstate(divide="ignore", invalid="ignore", over="ignore"):
        z_far = np.divide(
            scale.fB,
            lower_denominator,
            out=np.full(d.shape, np.inf, dtype=np.float64),
            where=lower_ok,
        )

    with np.errstate(invalid="ignore", over="ignore"):
        q_minus = z - z_near
        q_plus = z_far - z
        q_z = np.maximum(q_minus, q_plus)

    return PushedRisk(
        q_z=q_z,
        q_z_minus=q_minus,
        q_z_plus=q_plus,
        lower_denominator_nonpositive=~lower_ok,
    )


def abs_rel_depth(z_pred: np.ndarray, z_gt: np.ndarray) -> np.ndarray:
    """``|Z_pred - Z_gt| / Z_gt``. Dimensionless."""
    pred = np.asarray(z_pred, dtype=np.float64)
    gt = np.asarray(z_gt, dtype=np.float64)
    with np.errstate(divide="ignore", invalid="ignore"):
        return np.abs(pred - gt) / gt


def abs_rel_from_disparity(
    disparity: np.ndarray, gt_disparity: np.ndarray, doffs: float
) -> np.ndarray:
    """``AbsRel`` computed without ``f`` or ``B``.

    ``|Z_pred - Z_gt| / Z_gt`` collapses to ``|d_pred - d_gt| / (d_pred + d_offs)``
    because ``f`` and ``B`` cancel exactly. Dimensionless.
    """
    d = np.asarray(disparity, dtype=np.float64)
    gt = np.asarray(gt_disparity, dtype=np.float64)
    with np.errstate(divide="ignore", invalid="ignore"):
        return np.abs(d - gt) / (d + doffs)


def abs_rel_radius_bound(
    disparity: np.ndarray, half_width: np.ndarray, doffs: float
) -> np.ndarray:
    """Analytic relative-depth bound induced by a disparity radius.

    For ``a = d_hat + d_offs > 0`` and a non-negative disparity half-width
    ``q_d``, the event ``|d_hat - d_gt| <= q_d`` implies

    ``AbsRel <= q_d / (d_hat + d_offs)``.

    This is the geometry-only score that is exactly aligned with AbsRel.  It
    is a bound on the relative depth error, rather than the absolute-depth
    push-forward radius.  A non-positive or non-finite denominator is outside
    the positive-depth branch and is represented as ``+inf``.  Non-finite
    half-widths remain non-finite so that callers can classify them explicitly;
    they are never silently clipped.
    """
    d = np.asarray(disparity, dtype=np.float64)
    q = np.asarray(half_width, dtype=np.float64)
    if d.shape != q.shape:
        raise GeometryError(f"disparity {d.shape} and half-width {q.shape} must match")
    if not np.isfinite(doffs):
        raise GeometryError(f"doffs is not finite: {doffs!r}")
    if np.any(q[np.isfinite(q)] < 0):
        raise GeometryError("half-width must be non-negative where finite")
    denominator = d + float(doffs)
    bound = np.full(d.shape, np.inf, dtype=np.float64)
    valid = np.isfinite(denominator) & (denominator > 0)
    with np.errstate(divide="ignore", invalid="ignore"):
        bound[valid] = q[valid] / denominator[valid]
    return bound


def proxy_rel(disparity: np.ndarray, gt_disparity: np.ndarray) -> np.ndarray:
    """``ProxyRel = |d_pred - d_gt| / d_pred`` — the SceneFlow source target.

    Named ``ProxyRel`` and never ``AbsRel``: SceneFlow's ``d_offs = 0`` has no
    first-hand code or data contract, so this is a disparity-derived proxy.
    """
    d = np.asarray(disparity, dtype=np.float64)
    gt = np.asarray(gt_disparity, dtype=np.float64)
    with np.errstate(divide="ignore", invalid="ignore"):
        return np.abs(d - gt) / d


def refuse_cross_dataset_depth_mae(left_unit: str, right_unit: str) -> None:
    """Absolute Depth MAE may never be compared across datasets."""
    if left_unit != right_unit:
        raise GeometryError(
            f"{CROSS_DATASET_DEPTH_MAE_COMPARISON}: refusing to compare Depth MAE in "
            f"{left_unit!r} against {right_unit!r}"
        )
