"""Prospective V4 CAL-only sampling and native-grid disparity-radius operands."""

import cv2
import numpy as np

from src.taskspace.calibration import fit_c1d


def frame_quotas(frame_names, total=8192):
    names = sorted(frame_names)
    if not names or len(set(names)) != len(names) or total < len(names):
        raise ValueError("distinct frames and at least one sample per frame required")
    base, remainder = divmod(total, len(names))
    return {name: base + (i < remainder) for i, name in enumerate(names)}


def sampled_operands(gt, disparity, raw_score, quota):
    """Transform quarter-grid log radius first, then resize/scale to GT pixels.

    Sampling depends only on GT validity. Reject nonfinite predictions rather
    than altering the selected indices. Returns errors, base radii and indices.
    """
    gt = np.asarray(gt, dtype=np.float64)
    disparity = np.asarray(disparity, dtype=np.float64)
    raw_score = np.asarray(raw_score, dtype=np.float64)
    if gt.ndim != 2 or disparity.ndim != 2 or raw_score.shape != disparity.shape:
        raise ValueError("expected GT and matching 2D prediction maps")
    if gt.size == 0 or disparity.size == 0:
        raise ValueError("empty prediction maps")
    valid = np.flatnonzero((np.isfinite(gt) & (gt > 0)).ravel())
    if not isinstance(quota, int) or not 0 < quota <= len(valid):
        raise ValueError("quota exceeds available GT pixels")
    positions = ((2 * np.arange(quota, dtype=np.int64) + 1) * len(valid)) // (2 * quota)
    indices = valid[positions]
    scale = gt.shape[1] / disparity.shape[1]
    target = (gt.shape[1], gt.shape[0])
    with np.errstate(over="ignore", invalid="ignore"):
        radius = np.maximum(np.expm1(raw_score), 0.0)
    radius[~np.isfinite(raw_score)] = np.nan
    predicted = cv2.resize(disparity, target, interpolation=cv2.INTER_LINEAR) * scale
    base = cv2.resize(radius, target, interpolation=cv2.INTER_LINEAR) * scale
    errors = np.abs(predicted.ravel()[indices] - gt.ravel()[indices])
    bases = base.ravel()[indices]
    if not np.isfinite(errors).all() or not np.isfinite(bases).all():
        raise ValueError("nonfinite sampled calibration operands")
    return errors, bases, indices


def fit_sampled_c1d(samples):
    """Caller binds CAL scenes/seed and quotas; no silent finite filtering."""
    samples = list(samples)
    if not samples:
        raise ValueError("empty calibration sample list")
    errors = np.concatenate([s[0] for s in samples])
    bases = np.concatenate([s[1] for s in samples])
    if not np.isfinite(errors).all() or not np.isfinite(bases).all():
        raise ValueError("nonfinite calibration sample")
    return fit_c1d(errors, bases, 0.90)
