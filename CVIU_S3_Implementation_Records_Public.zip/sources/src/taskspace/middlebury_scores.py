"""Checkpoint-bound raw score adapter for the frozen Middlebury scene cache.

The caller supplies exact manifest entries and paths. The checkpoint hash is
checked immediately before deserialization; this module does not find files by
glob or choose a seed from results.
"""
from __future__ import annotations

import hashlib
from pathlib import Path
from typing import Mapping

import numpy as np
import torch

from src.evidence.negative_controls import transport_mono_to_target
from src.evidence.normalization import NormalizationConstants, normalize_features_torch
from src.evidence.stereo_evidence_gpu import r0_features_gpu, r1_features_gpu
from src.models.grel_predictor import build_grel_direct
from src.models.r2_inputs import build_inputs
from src.models.risk_predictor import build_r0, build_r1, build_r2_dis, build_r2_gate
from src.training.grel_checkpoint import load_checkpoint

NORMALIZATION_SHA256 = "42ef8559dce15302ef1c386aba4e2b80d3711eeca98d5b9281ec1d2f5883080e"
BUILDERS = {
    "r0": build_r0,
    "r1": build_r1,
    "r2_gate": build_r2_gate,
    "n_random": build_r2_dis,
    "n_shuffle": build_r2_dis,
    "grel_direct": build_grel_direct,
}
PARAMETERS = {
    "r0": 18753,
    "r1": 18913,
    "r2_gate": 18910,
    "n_random": 19169,
    "n_shuffle": 19169,
    "grel_direct": 18910,
}


def load_verified_model(
    family: str, path: Path, entry: Mapping[str, object], device: torch.device,
) -> torch.nn.Module:
    """Rehash before every load; strict model and selected-step identity."""
    if family not in BUILDERS:
        raise ValueError(f"unknown frozen family {family!r}")
    hasher = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            hasher.update(block)
    if hasher.hexdigest() != entry["sha256"] or path.stat().st_size != entry["bytes"]:
        raise ValueError(f"checkpoint byte identity mismatch: {family} {path}")
    model = BUILDERS[family]()
    if model.parameter_count() != PARAMETERS[family]:
        raise ValueError(f"unexpected parameter count for {family}")
    if family == "grel_direct":
        payload = load_checkpoint(path, expected_sha256=str(entry["sha256"]), model=model)
    else:
        payload = torch.load(path, map_location="cpu", weights_only=False)
        model.load_state_dict(payload["model"], strict=True)
    step = entry.get("selected_step", entry.get("step"))
    if payload["step"] != step:
        raise ValueError(f"selected step mismatch for {family}: {payload['step']} != {step}")
    return model.to(device).eval()


def raw_score(
    family: str, model: torch.nn.Module, arrays: Mapping[str, np.ndarray],
    constants: NormalizationConstants, device: torch.device,
    *, donor_mono: np.ndarray | None = None,
) -> np.ndarray:
    """One cached scene forward; N-shuffle accepts only donor raw mono pixels."""
    if constants.digest() != NORMALIZATION_SHA256:
        raise ValueError("frozen SceneFlow normalization digest mismatch")
    if family not in BUILDERS:
        raise ValueError(f"unknown frozen family {family!r}")
    d = arrays["stereo_disparity"]
    shape = d.shape
    left = torch.from_numpy(arrays["left_rgb"]).permute(2, 0, 1).unsqueeze(0).to(device)
    right = torch.from_numpy(arrays["right_rgb"]).permute(2, 0, 1).unsqueeze(0).to(device)
    disparity = torch.from_numpy(d).unsqueeze(0).unsqueeze(0).to(device)
    if family == "n_shuffle":
        if donor_mono is None:
            raise ValueError("N-shuffle requires the frozen donor's raw mono map")
        mono_map = transport_mono_to_target(torch.from_numpy(donor_mono), shape)
        mono = mono_map.unsqueeze(0).to(device)
    else:
        if donor_mono is not None:
            raise ValueError("donor mono is permitted only for N-shuffle")
        mono = torch.from_numpy(arrays["mono_relative_depth"]).unsqueeze(0).unsqueeze(0).to(device)
    with torch.inference_mode():
        if family == "r0":
            inputs = (normalize_features_torch(r0_features_gpu(left, disparity), constants),)
        elif family == "r1":
            inputs = (normalize_features_torch(r1_features_gpu(left, right, disparity), constants),)
        else:
            variant = "r2_gate" if family == "grel_direct" else family
            inputs = build_inputs(variant, left, right, disparity, mono, constants)
        output = model(*inputs)
    if tuple(output.shape) != (1, 1, *shape):
        raise ValueError(f"{family}: score shape {tuple(output.shape)} != {(1, 1, *shape)}")
    return output[0, 0].float().cpu().numpy()
