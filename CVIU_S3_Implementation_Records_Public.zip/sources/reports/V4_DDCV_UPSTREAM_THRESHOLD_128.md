# DDCV upstream LR threshold convention (128)

Resolved against public upstream commit `ddf2f57f5ec518a0a167c5da3fc5dfab90211dac` in `CwLiuzzZ/Un-ViTAStereo`.

`toolkit/function/depth_function/loss_fuction.py:236–252`, `component_generate`, computes the absolute warped-right/left disparity residual and applies `torch.quantile(diff_r2l,noc_ratio)` to the whole residual tensor. It does **not** select GT-valid pixels. The default `noc_ratio` is 0.85 in `toolkit/args/args_default.py:54`. Pixels strictly above this quantile receive vote/risk 1.

For the future single-frame V4 comparator, use the full image residual quantile, independent of GT. Do not copy the historical runner's `lr[valid]` percentile. Preserve that historical runner and its results; record this prospective correction in V4's execution freeze. Warping/interpolation parity remains to check before calling the entire adapter equivalent.

Fixed-commit source files and SHA-256 receipt are stored in `outputs/ddcv_source_128/receipt.json`; source was downloaded for inspection only and not executed. The loss source SHA-256 is `bdc5470913400fddb59d26b6c5104dfe573352ea24a39af019941745d2861117`. No dataset or model access occurred.
