"""Prospective one-shot EVAL pipeline. Default never reads EVAL files."""

import argparse
import hashlib
import json
import subprocess
import os
import secrets
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT/'scripts'))
DATA = ROOT/'outputs/v4_booster_eval_recovery_142'
OUTPUT = ROOT/'outputs/v4_booster_eval_run_145'
FIT = ROOT/'outputs/v4_booster_cal_fits_130_run1.json'
FIT_SHA = '0d4913ce2760d370b68e005b63a2352844cffb0b22c3477f5f69390a087f274b'


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda:f.read(1048576), b''):
            h.update(block)
    return h.hexdigest()


def execution_identity():
    from scripts.v4_booster_eval_recovered_143 import recovery_identity
    if recovery_identity() != 'f93386da571f41f8b46697533904483b80281bc8a8e1f367ebbc95e6351f9b76':
        raise ValueError('original recovery identity changed')
    path = ROOT/'manifests/v4_eval_count_amendment_145.json'
    for row in json.loads(path.read_text())['files']:
        if sha(ROOT/row['path']) != row['sha256']:
            raise ValueError('count amendment identity changed')
    return sha(path)


def bind_inputs():
    """Only call after separately authorized EVAL acquisition; records exact bytes."""
    import numpy as np
    import struct
    from v4_booster_cal_parallel_123 import file_identity
    from src.taskspace.booster_geometry_check import parse_balanced_calibration, assert_gt_geometry
    frozen = json.loads((ROOT/'manifests/v4_booster_scene_split_077.json').read_text())
    names = sorted(r['scene'] for r in frozen['roles'] if r['role']=='EVAL')
    transfer = json.loads((DATA/'terminal.json').read_text())
    if transfer['status'] != 'COMPLETE' or transfer.get('execution_sha256') != 'f93386da571f41f8b46697533904483b80281bc8a8e1f367ebbc95e6351f9b76':
        raise ValueError('complete EVAL transfer required')
    scenes = []
    for name in names:
        receipt = json.loads((DATA/f'{name}_receipt.json').read_text())
        if receipt['scene'] != name:
            raise ValueError('scene receipt identity mismatch')
        entries = {}
        for row in receipt['members']:
            path = (DATA/row['path']).resolve()
            if not path.is_relative_to(DATA/name) or str(path) in entries:
                raise ValueError('duplicate or out-of-scene member')
            if file_identity(path) != (row['bytes'],row['crc32'],row['sha256']):
                raise ValueError('member identity mismatch')
            entries[str(path)] = row['sha256']
        def bound(path):
            return {'path':str(path), 'sha256':entries[str(path)]}
        folder = DATA/name
        xml = folder/'calib_00-02.xml'; gt_path = folder/'disp_00.npy'
        bound(xml); bound(gt_path)
        scale, grid = parse_balanced_calibration(xml.read_bytes())
        if grid != (4112,3008):
            raise ValueError('EVAL grid differs from frozen CAL grid')
        gt = np.load(gt_path,mmap_mode='r',allow_pickle=False)
        assert_gt_geometry(gt,scale,grid)
        left = sorted((folder/'camera_00').glob('im*.png'))
        right = sorted((folder/'camera_02').glob('im*.png'))
        if not left or [p.name for p in left] != [p.name for p in right]:
            raise ValueError('EVAL stereo pairs incomplete')
        frames=[]
        for l,r in zip(left,right):
            for p in (l,r,folder/'mask_00.png',folder/'mask_cat.png'):
                bound(p)
                with p.open('rb') as f: header=f.read(24)
                if header[:8] != b'\x89PNG\r\n\x1a\n' or struct.unpack('>II',header[16:24]) != grid:
                    raise ValueError('EVAL PNG grid mismatch')
            frames.append({'frame':l.stem,'left':bound(l),'right':bound(r)})
        scenes.append({'scene':name,'frames':frames,'gt':bound(gt_path),
                       'geometry':{'fx':scale.fx,'baseline':scale.baseline,'doffs':scale.doffs,'unit':scale.unit}})
    if len(scenes)!=19 or sum(len(s['frames']) for s in scenes)!=108:
        raise ValueError('EVAL cohort differs from directory-derived 19 scenes/108 pairs')
    expected=json.loads((ROOT/'manifests/v4_eval_exact_frames_145.json').read_text())
    if {s['scene']:[f['frame'] for f in s['frames']] for s in scenes} != {s['scene']:[f['frame'] for f in s['frames']] for s in expected['scenes']}:
        raise ValueError('exact EVAL frame names mismatch')
    return scenes


def worker(stage):
    import cv2
    import numpy as np
    import torch
    from src.adapters.raft_stereo import StereoAdapter
    from src.adapters.depth_anything import MonoAdapter
    from src.evidence.normalization import NormalizationConstants
    from src.taskspace.middlebury_scores import load_verified_model
    from src.utils.config import load_paths,load_yaml
    from scripts.v4_booster_cal_scores_129 import score_frame,save_frame,checked_inputs
    from src.taskspace.booster_frame_eval import evaluate_frame
    from src.taskspace.booster_cohort_summary import summarize_primary
    from src.taskspace.geometry import DepthScale
    identity=execution_identity()
    if stage == 'metrics':
        receipt=json.loads((OUTPUT/'raw_complete.json').read_text())
        if (receipt['execution_sha256'] != identity or receipt['inputs_sha256'] != sha(OUTPUT/'inputs.json')
                or receipt['scores_log_sha256'] != sha(OUTPUT/'scores.jsonl')):
            raise ValueError('raw stage identity mismatch')
        scenes=json.loads((OUTPUT/'inputs.json').read_text())
        records={(r['scene'],r['frame']):r for r in (json.loads(line) for line in (OUTPUT/'scores.jsonl').read_text().splitlines())}
        return measure_stage(scenes,records,identity)
    scenes=bind_inputs()
    with (OUTPUT/'inputs.json').open('x') as f: json.dump(scenes,f,indent=2)
    _,binding=checked_inputs(); paths=load_paths(); config=load_yaml(ROOT/'configs/models/mvt.yaml')
    gpu_deadline=time.monotonic()+7200
    stereo=StereoAdapter(paths['raft_source'],paths['raft_checkpoint'],config['raft_stereo'],'cuda')
    mono=MonoAdapter(paths['depth_anything_source'],paths['depth_anything_checkpoint'],config['depth_anything_v2'],'cuda')
    models={(e['family'],e['seed']):load_verified_model(e['family'],ROOT/e['path'],e,torch.device('cuda')) for e in binding['checkpoints']}
    constants=NormalizationConstants.load(ROOT/'configs/normalization_sceneflow_train.json')
    spent=0; records={}
    with (OUTPUT/'scores.jsonl').open('x') as log:
        for scene in scenes:
            for frame in scene['frames']:
                images=[]
                for side in ('left','right'):
                    entry=frame[side]; path=Path(entry['path'])
                    if sha(path)!=entry['sha256']: raise ValueError('RGB identity changed')
                    image=cv2.imread(str(path),cv2.IMREAD_COLOR)
                    if image is None or image.shape!=(3008,4112,3): raise ValueError('RGB decode mismatch')
                    images.append(cv2.resize(cv2.cvtColor(image,cv2.COLOR_BGR2RGB),(1028,752),interpolation=cv2.INTER_AREA))
                shared,heads,seconds=score_frame(*images,stereo,mono,models,constants,'cuda',gpu_deadline)
                record=save_frame(OUTPUT/'scores'/f"{scene['scene']}_{frame['frame']}.npz",shared,heads,5_000_000_000-spent-20_000_000)
                spent+=record['bytes']; records[(scene['scene'],frame['frame'])]=record
                log.write(json.dumps({**record,'scene':scene['scene'],'frame':frame['frame'],'seconds':seconds})+'\n');log.flush()
                print(f"SCORED {scene['scene']}/{frame['frame']}",flush=True)
    del stereo,mono,models
    torch.cuda.empty_cache()
    with (OUTPUT/'raw_complete.json').open('x') as f:
        json.dump({'execution_sha256':identity,'inputs_sha256':sha(OUTPUT/'inputs.json'),'scores_log_sha256':sha(OUTPUT/'scores.jsonl')},f)
    return identity


def measure_stage(scenes,records,identity):
    import numpy as np
    from src.taskspace.booster_frame_eval import evaluate_frame
    from src.taskspace.booster_cohort_summary import summarize_primary
    from src.taskspace.geometry import DepthScale
    fits=json.loads(FIT.read_text())['fits']; results={}
    with (OUTPUT/'frame_metrics.jsonl').open('x') as log:
        for scene in scenes:
            gt_path=Path(scene['gt']['path'])
            if sha(gt_path)!=scene['gt']['sha256']: raise ValueError('GT identity changed')
            gt=np.load(gt_path,mmap_mode='r',allow_pickle=False)
            scale=DepthScale(**scene['geometry'])
            for frame in scene['frames']:
                key=(scene['scene'],frame['frame']); record=records[key]; path=Path(record['path'])
                if sha(path)!=record['sha256']: raise ValueError('score identity changed')
                with np.load(path,allow_pickle=False) as maps: result=evaluate_frame(maps,gt,scale,fits)
                results[key]=result
                log.write(json.dumps({'scene':key[0],'frame':key[1],'methods':result})+'\n');log.flush()
                print(f"MEASURED {key[0]}/{key[1]}",flush=True)
    expected={s['scene']:[f['frame'] for f in s['frames']] for s in scenes}
    primary=summarize_primary(results,expected)
    with (OUTPUT/'primary.json').open('x') as f: json.dump(primary,f,indent=2)
    with (OUTPUT/'metrics_complete.json').open('x') as f: json.dump(metric_bindings(identity),f,indent=2)
    return identity


def metric_bindings(identity):
    inputs=json.loads((OUTPUT/'inputs.json').read_text())
    rows=[json.loads(line) for line in (OUTPUT/'frame_metrics.jsonl').read_text().splitlines()]
    expected={(s['scene'],f['frame']) for s in inputs for f in s['frames']}
    actual={(r['scene'],r['frame']) for r in rows}
    primary=json.loads((OUTPUT/'primary.json').read_text())
    if len(inputs)!=19 or len(expected)!=108 or len(rows)!=108 or actual!=expected or len(primary['table'])!=14:
        raise ValueError('incomplete final EVAL result cohort')
    return {'execution_sha256':identity,'fit_sha256':FIT_SHA,'scenes':19,'frames':108,'rows':14,
            'artifacts':{name:sha(OUTPUT/name) for name in
                         ('inputs.json','raw_complete.json','scores.jsonl','frame_metrics.jsonl','primary.json')}}


def validate_metrics_receipt(identity):
    path=OUTPUT/'metrics_complete.json'
    if json.loads(path.read_text())!=metric_bindings(identity):
        raise ValueError('final metric completion binding mismatch')
    return sha(path)


def validate_worker_token(token):
    receipt=json.loads((OUTPUT/'run_authorization.json').read_text())
    if (not token or not secrets.compare_digest(token,receipt['token'])
            or receipt['parent_pid']!=os.getppid()):
        raise ValueError('worker requires live authorized parent')
    if receipt['execution_sha256']!=execution_identity():
        raise ValueError('worker execution differs from parent authorization')


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--run-authorized-eval',action='store_true');parser.add_argument('--worker',choices=('raw','metrics'));parser.add_argument('--worker-token');args=parser.parse_args()
    if args.worker:
        validate_worker_token(args.worker_token)
        try: worker(args.worker)
        except BaseException as e:
            with (OUTPUT/'failure.json').open('x') as f: json.dump({'type':type(e).__name__,'message':str(e)[:2000]},f)
            raise
        return
    if not args.run_authorized_eval:
        print('Preparation only: no EVAL reads or model loading.');return
    identity=execution_identity();OUTPUT.mkdir(parents=True,exist_ok=False);status='FAILED';started=time.monotonic()
    token=secrets.token_hex(24)
    with (OUTPUT/'run_authorization.json').open('x') as f:
        json.dump({'token':token,'parent_pid':os.getpid(),'execution_sha256':identity},f)
    stage=None; returncode=None; metrics_sha=None; parent_error=None
    try:
        for stage,limit in (('raw',7200),('metrics',14400)):
            returncode=None
            result=subprocess.run([sys.executable,'-u',str(Path(__file__).resolve()),'--worker',stage,'--worker-token',token],timeout=limit)
            returncode=result.returncode
            if result.returncode != 0: break
        else:
            metrics_sha=validate_metrics_receipt(identity)
            status='COMPLETE'
    except subprocess.TimeoutExpired:status='TIMEOUT'
    except BaseException as error:
        parent_error={'type':type(error).__name__,'message':str(error)[:2000]}
        raise
    finally:
        terminal={'status':status,'elapsed_seconds':time.monotonic()-started,'execution_sha256':identity,
                  'fit_sha256':FIT_SHA,'failed_stage':stage if status!='COMPLETE' else None,
                  'returncode':returncode,'metrics_complete_sha256':metrics_sha,'parent_error':parent_error}
        if (OUTPUT/'failure.json').exists():
            terminal['worker_failure']=json.loads((OUTPUT/'failure.json').read_text())
            terminal['worker_failure_sha256']=sha(OUTPUT/'failure.json')
        with (OUTPUT/'terminal.json').open('x') as f:json.dump(terminal,f,indent=2)
    if status!='COMPLETE':
        raise SystemExit(1)


if __name__=='__main__':main()
