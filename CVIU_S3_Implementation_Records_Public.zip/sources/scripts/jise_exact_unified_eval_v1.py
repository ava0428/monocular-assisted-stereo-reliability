#!/usr/bin/env python3
"""Native float64, exact discrete JISE evaluation; immutable, resumable frames.

45 rules/frame. All counts enter AURC/segments; plot samples never enter metrics.
--curve-methods selects lossless streamed .npy.gz AbsRel curves, e.g.
Raw:r2_gate:20260910,Rel-Analytic:r2_gate:20260910,Depth-Exact:r2_gate:20260910
NaN/-inf scores are diagnosed and their full AURC is unavailable; +inf is legal.
"""
from __future__ import annotations
import argparse, gzip, hashlib, json, math, os, sys, uuid
from concurrent.futures import ProcessPoolExecutor, wait, FIRST_COMPLETED
from datetime import datetime, timezone
from pathlib import Path
import cv2
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from src.taskspace.geometry import DepthScale, depth_from_disparity, push_forward, abs_rel_radius_bound

FAMILIES = ('r1', 'r2_concat', 'r2_dis', 'r2_gate', 'n_random', 'n_shuffle')
SEEDS = (20260910, 20260911, 20260912)
BOUNDS = (0., .2, .4, .6, .8, .9, 1.)
SCHEMA = 'jise-exact-unified-eval-v1'
CFG = None

def loadj(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))

def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1 << 20), b''):
            h.update(block)
    return h.hexdigest()

def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True).encode()).hexdigest()

def writej(path, value):
    # Exclusive creation: complete frame JSON is published only after artifacts.
    tmp = Path(path).with_name(Path(path).name + '.' + uuid.uuid4().hex + '.tmp')
    with tmp.open('x', encoding='utf-8') as stream:
        json.dump(value, stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write('\n'); stream.flush(); os.fsync(stream.fileno())
    os.link(tmp, path)  # Atomic publication with no replacement on either OS.
    tmp.unlink()

def project(array, shape, scale=1.):
    result = cv2.resize(np.asarray(array, dtype=np.float64), (shape[1], shape[0]), interpolation=cv2.INTER_LINEAR)
    result *= float(scale)
    return result

def native_radius(raw, shape, ratio, universe):
    raw = np.asarray(raw, dtype=np.float64)
    with np.errstate(over='ignore', invalid='ignore'):
        base = np.maximum(np.expm1(raw), 0.)
    base[~np.isfinite(raw)] = np.nan
    return project(base, shape, ratio)[universe]

def methods():
    ids = [f'Raw:{f}:{s}' for f in FAMILIES for s in SEEDS]
    ids += [f'Rel-Analytic:{f}:{s}' for f in FAMILIES[:4] for s in SEEDS]
    ids += [f'{r}:r2_gate:{s}' for r in ('DispCal', 'Depth-Exact', 'Depth-Linear') for s in SEEDS]
    return ids + ['Depth-Only', 'DDCV', 'PlaneSweep'] + [f'Grel:{s}' for s in SEEDS]

def exact_metrics(risk, losses, block_size, full_curve=None, groups=None):
    """One stable sort, shared by all losses; cumsum is bitwise block invariant.

    Prefix each block with the preceding cumulative SUM, rather than adding a
    carry to an independently accumulated block (which changes float rounding).
    """
    risk = np.asarray(risk, dtype=np.float64).ravel()
    n = len(risk)
    if not n or any(np.asarray(v).shape != (n,) for v in losses.values()):
        raise ValueError('empty or mismatched metric operands')
    if groups is not None and (np.asarray(groups).shape != (n,) or np.any((groups < 0) | (groups > 2))):
        raise ValueError('depth groups must have one bin0..2 for each metric unit')
    bad = np.isnan(risk) | np.isneginf(risk)
    order = np.argsort(np.where(bad, np.inf, risk), kind='stable')
    cuts = np.array([math.ceil(r * n) for r in BOUNDS], dtype=np.int64)
    plot_counts = np.maximum(1, np.ceil(np.linspace(0., 1., 1001) * n).astype(np.int64))
    row = {'n_unit': n, 'score_nan': int(np.isnan(risk).sum()), 'score_posinf': int(np.isposinf(risk).sum()),
           'score_neginf': int(np.isneginf(risk).sum()), 'aurc_status': 'NONORDERABLE_SCORE' if bad.any() else 'OK'}
    fixed = [(math.ceil(r * n), f'{int(r * 100)}') for r in (.8, .9)]
    fixed_ok = {key: not bool(bad[order[:k]].any()) for k, key in fixed}
    for k, key in fixed:
        row[f'status_{key}'] = 'OK' if fixed_ok[key] else 'NONORDERABLE_SCORE'
    plots = {'coverage': plot_counts.astype(np.float64) / n, 'counts': plot_counts}
    bin_counts = np.zeros(3, dtype=np.int64); bin_sums = np.zeros(3, dtype=np.float64)
    keep80 = math.ceil(.8 * n)
    for name, loss in losses.items():
        loss = np.asarray(loss, dtype=np.float64)
        if not np.isfinite(loss).all():
            raise ValueError(f'nonfinite common loss: {name}')
        sums = np.zeros(len(BOUNDS) - 1, dtype=np.float64)
        samples = np.empty(1001, dtype=np.float64)
        carry = 0.
        for start in range(0, n, block_size):
            end = min(n, start + block_size)
            buffer = np.empty(end - start + 1, dtype=np.float64)
            buffer[0] = carry; buffer[1:] = loss[order[start:end]]
            np.cumsum(buffer, dtype=np.float64, out=buffer)
            carry = float(buffer[-1])
            buffer[1:] /= np.arange(start + 1, end + 1, dtype=np.float64)
            curve = buffer[1:]
            for k, key in fixed:
                if start < k <= end:
                    row[f'{name}_{key}'] = float(curve[k - start - 1]) if fixed_ok[key] else None
            for i, (lo, hi) in enumerate(zip(cuts[:-1], cuts[1:])):
                left, right = max(start, int(lo)), min(end, int(hi))
                if left < right:
                    sums[i] += np.sum(curve[left - start:right - start], dtype=np.float64)
            selected = (plot_counts > start) & (plot_counts <= end)
            samples[selected] = curve[plot_counts[selected] - start - 1]
            if groups is not None and name == 'absrel' and start < keep80:
                selected_order = order[start:min(end, keep80)]
                selected_groups = groups[selected_order]
                bin_counts += np.bincount(selected_groups, minlength=3)
                bin_sums += np.bincount(selected_groups, weights=loss[selected_order], minlength=3)
            if name == 'absrel' and full_curve is not None:
                full_curve.write(curve.tobytes())
        for i, (lo, hi) in enumerate(zip(cuts[:-1], cuts[1:])):
            row[f'{name}_segment_{i}_counts'] = int(hi - lo)
            row[f'{name}_segment_{i}_mean'] = float(sums[i] / (hi - lo)) if hi > lo and not bad.any() else None
            row[f'{name}_segment_{i}_contribution'] = float(sums[i] / n) if not bad.any() else None
        row[f'{name}_aurc'] = float(math.fsum(float(x / n) for x in sums)) if not bad.any() else None
        plots[name] = samples
    if groups is not None:
        for i in range(3):
            total = int(np.count_nonzero(groups == i)); count = int(bin_counts[i])
            row[f'depth_bin_{i}_universe_count'] = total
            row[f'depth_bin_{i}_retained_count_80'] = count
            row[f'depth_bin_{i}_retained_fraction_80'] = float(count / total) if total else None
            row[f'depth_bin_{i}_absrel_sum_80'] = float(bin_sums[i]) if fixed_ok['80'] else None
            row[f'depth_bin_{i}_absrel_80'] = float(bin_sums[i] / count) if count and fixed_ok['80'] else None
    return row, plots

def quantiles(values):
    values = np.asarray(values, dtype=np.float64)
    finite = values[np.isfinite(values)]
    return {'finite_count': int(len(finite)), 'nonfinite_count': int(values.size - len(finite)),
            'q00_q25_q50_q75_q90_q99_q100': np.quantile(finite, [0., .25, .5, .75, .9, .99, 1.]).tolist() if finite.size else None}

def delta_description(base, calibrated, delta, groups=None):
    with np.errstate(divide='ignore', invalid='ignore'):
        share = np.divide(delta, calibrated, out=np.full_like(base, np.nan), where=calibrated > 0)
        ratio = np.abs(delta) / base
    result = {'delta_native_disparity_px': delta, 'native_base_radius': quantiles(base), 'native_calibrated_radius': quantiles(calibrated),
            'signed_delta_share_of_calibrated_radius': quantiles(share), 'absolute_delta_to_base_radius': quantiles(ratio),
            'fraction_absolute_delta_ge_base': float(np.mean(np.abs(delta) >= base)), 'calibrated_zero_count': int((calibrated == 0).sum())}
    if groups is not None:
        result['prediction_depth_tertiles'] = {str(i): delta_description(base[groups == i], calibrated[groups == i], delta) for i in range(3) if np.any(groups == i)}
    return result

def init_worker(cfg):
    global CFG
    CFG = cfg
    cv2.setNumThreads(1)

def expired(cfg):
    return bool(cfg['deadline'] and datetime.now(timezone.utc).timestamp() >= cfg['deadline'])

def evaluate_frame(frame):
    c = CFG
    if expired(c):
        return {'status': 'DEADLINE', 'scene': frame['scene'], 'frame': frame['frame']}
    scene, name = frame['scene'], frame['frame']
    op = c['operands'][scene]
    stem = f'{scene}_{name}'
    if Path(stem).name != stem or any(x in stem for x in ('/', '\\')):
        raise ValueError('unsafe frame identifier')
    ip = Path(c['input_root']) / frame['input_npz']
    gp = Path(c['operand_root']) / op['operand_npz']
    lp = Path(c['legacy_score_root']) / f'{stem}.npz'
    source = {'run_sha256': c['run_sha256'], 'input_npz_sha256': sha(ip), 'operand_npz_sha256': sha(gp), 'scores': {}}
    if source['input_npz_sha256'] != frame['input_sha256']:
        raise ValueError(f'input identity mismatch: {ip}')
    if source['operand_npz_sha256'] != op['operand_sha256']:
        raise ValueError(f'frozen GT operand identity mismatch: {gp}')
    if not c['no_legacy']:
        source['legacy_npz_sha256'] = sha(lp)
        legacy = c['legacy_manifest'].get(stem)
        source['legacy_source_npz_sha256'] = legacy['source_sha256'] if legacy else source['legacy_npz_sha256']
        if (legacy and (legacy['sha256'] != source['legacy_npz_sha256'] or legacy['bytes'] != lp.stat().st_size)) or (frame.get('source_score_npz_sha256') and source['legacy_source_npz_sha256'] != frame['source_score_npz_sha256']):
            raise ValueError(f'legacy NPZ identity mismatch: {lp}')
    for fam in FAMILIES:
        for seed in SEEDS:
            p = Path(c['score_root']) / 'raw_scores' / f'{fam}_seed{seed}' / f'{stem}.npy'
            r = loadj(p.with_suffix('.json')); cp = c['checkpoints'][f'{fam}:{seed}']
            wanted = {'family': fam, 'seed': seed, 'scene': scene, 'frame': name, 'input_npz_sha256': source['input_npz_sha256'],
                      'checkpoint_sha256': cp['sha256'], 'checkpoint_selected_step': cp['selected_step'], 'gt_opened_for_score_generation': False}
            if any(r.get(k) != v for k, v in wanted.items()) or r.get('score_sha256') != sha(p):
                raise ValueError(f'raw receipt mismatch: {p}')
            source['scores'][f'{fam}:{seed}'] = {'score_sha256': r['score_sha256'], 'receipt_sha256': sha(p.with_suffix('.json'))}
    binding = digest(source)
    final = Path(c['out']) / 'frames' / f'{stem}.json'
    if final.exists():
        old = loadj(final)
        if old['input_binding_sha256'] != binding or any(sha(Path(c['out']) / a['path']) != a['sha256'] for a in old['artifacts']):
            raise ValueError(f'resume identity mismatch: {final}')
        print(f'RESUMED {scene}/{name}', flush=True)
        return {'status': 'RESUMED', 'scene': scene, 'frame': name}
    attempt = Path(c['out']) / 'artifacts' / f'{stem}_{uuid.uuid4().hex}'
    attempt.mkdir(parents=True, exist_ok=False)
    with np.load(ip, allow_pickle=False) as z:
        d0 = np.asarray(z['stereo_disparity'], dtype=np.float64)
    with np.load(gp, allow_pickle=False) as z:
        gt = np.asarray(z['gt_disparity'], dtype=np.float64)
    shape = gt.shape; ratio = shape[1] / d0.shape[1]
    if not np.isclose(ratio, shape[0] / d0.shape[0], rtol=1e-9, atol=1e-9) or not np.isclose(ratio, 4., rtol=0., atol=1e-9):
        raise ValueError('non-frozen native projection ratio')
    universe = np.isfinite(gt) & (gt > 0)
    d = project(d0, shape, ratio)[universe]; g = gt[universe]
    scale = DepthScale(**op['geometry'])
    pred = depth_from_disparity(d, scale); truth = depth_from_disparity(g, scale)
    losses = {'epe': np.abs(d - g), 'mae': np.abs(pred - truth), 'absrel': np.abs(pred - truth) / truth}
    if not np.isfinite(pred).all():
        raise ValueError('nonfinite point depth on common GT universe')
    depth_cuts = np.quantile(pred, [1 / 3, 2 / 3])
    groups = np.searchsorted(depth_cuts, pred, side='right').astype(np.uint8)
    del gt, g, pred, truth
    rows, plot, artifacts, diagnostics = [], {}, [], {}
    def record(method, risk, family=None, seed=None):
        curve_path = attempt / (method.replace(':', '_') + '.absrel.npy.gz')
        stream = None
        if method in c['curve_methods']:
            stream = gzip.GzipFile(fileobj=curve_path.open('xb'), mode='wb', compresslevel=1, mtime=0)
            np.lib.format.write_array_header_1_0(stream, {'descr': np.dtype(np.float64).str, 'fortran_order': False, 'shape': (len(d),)})
        try:
            values, samples = exact_metrics(risk, losses, c['block_size'], stream, groups)
        finally:
            if stream is not None:
                raw_stream = stream.fileobj; stream.close(); raw_stream.close()
        rows.append({'method': method, 'family': family, 'seed': seed, **values})
        for key, value in samples.items():
            plot[f'{method}/{key}'] = value
        if stream is not None:
            artifacts.append({'path': str(curve_path.relative_to(c['out'])), 'sha256': sha(curve_path), 'kind': 'full_absrel_curve_float64_lossless', 'method': method})
    for fam in FAMILIES:
        for seed in SEEDS:
            p = Path(c['score_root']) / 'raw_scores' / f'{fam}_seed{seed}' / f'{stem}.npy'
            raw = np.load(p, mmap_mode='r', allow_pickle=False)
            if raw.shape != d0.shape:
                raise ValueError(f'raw score shape mismatch: {p}')
            record(f'Raw:{fam}:{seed}', project(raw, shape)[universe], fam, seed)
            if fam not in FAMILIES[:4]:
                continue
            base = native_radius(raw, shape, ratio, universe)
            delta = c['fits'][f'{fam}:{seed}']; q = np.maximum(0., base + delta)
            diagnostics[f'{fam}:{seed}'] = delta_description(base, q, delta, groups)
            del base
            for rule in (('Rel-Analytic', 'DispCal', 'Depth-Exact', 'Depth-Linear') if fam == 'r2_gate' else ('Rel-Analytic',)):
                if rule == 'DispCal':
                    risk = q
                else:
                    risk = np.empty_like(d)
                    for lo in range(0, len(d), c['block_size']):
                        hi = min(len(d), lo + c['block_size']); db, qb = d[lo:hi], q[lo:hi]
                        if rule == 'Rel-Analytic':
                            risk[lo:hi] = abs_rel_radius_bound(db, qb, scale.doffs)
                        elif rule == 'Depth-Exact':
                            risk[lo:hi] = push_forward(db, qb, scale).q_z
                        else:
                            with np.errstate(divide='ignore', invalid='ignore', over='ignore'):
                                risk[lo:hi] = scale.fB * qb / (db + scale.doffs) ** 2
                record(f'{rule}:{fam}:{seed}', risk, fam, seed)
                del risk
            del q, raw
    a = d + scale.doffs
    record('Depth-Only', np.divide(1., a, out=np.full_like(a, np.inf), where=np.isfinite(a) & (a > 0)))
    del a
    if not c['no_legacy']:
        with np.load(lp, allow_pickle=False) as z:
            for method, key in [('DDCV', 'ddcv_full_reference'), ('PlaneSweep', 'plane_sweep')] + [(f'Grel:{s}', f'grel_direct_seed{s}') for s in SEEDS]:
                record(method, project(z[key], shape)[universe], seed=int(method.split(':')[1]) if ':' in method else None)
    plot_path = attempt / 'plot_1001.npz'
    with plot_path.open('xb') as stream:
        np.savez_compressed(stream, **plot)
    artifacts.append({'path': str(plot_path.relative_to(c['out'])), 'sha256': sha(plot_path), 'kind': 'plot_samples_only'})
    writej(final, {'schema': SCHEMA, 'scene': scene, 'frame': name, 'input_binding_sha256': binding, 'source': source,
                   'segment_bounds': BOUNDS, 'segment_count_rule': '(ceil(lo*N), ceil(hi*N)]', 'rows': rows, 'calibration_diagnostics': diagnostics,
                   'depth_strata': {'definition': 'predicted point depth tertiles on common GT-valid universe, independent of GT values; bins0 near,1 middle,2 far', 'quantiles': [1 / 3, 2 / 3], 'native_depth_cuts': depth_cuts.tolist(), 'boundary_rule': 'np.searchsorted(cuts, predicted_depth, side=right)'},
                   'artifacts': artifacts, 'full_curve_methods_saved': c['curve_methods'], 'full_curve_all_methods_complete': len(c['curve_methods']) == len(methods()), 'scope': 'SMOKE_NO_LEGACY' if c['no_legacy'] else 'FULL_45_METHODS'})
    print(f'COMPLETE {scene}/{name} methods={len(rows)} units={len(d)}', flush=True)
    return {'status': 'COMPLETE', 'scene': scene, 'frame': name}

def main():
    ap = argparse.ArgumentParser(description=__doc__)
    for name in ('input-root', 'operand-root', 'score-root', 'legacy-score-root', 'cal-fits', 'checkpoint-manifest', 'out'):
        ap.add_argument('--' + name, type=Path, required=True)
    ap.add_argument('--workers', type=int, default=1, help='1..4 independent frame workers')
    ap.add_argument('--block-size', type=int, default=262144)
    ap.add_argument('--deadline', help='UTC ISO timestamp, e.g. 2026-10-05T15:38:00Z; no new frame starts afterwards')
    ap.add_argument('--max-frames', type=int, help='limit first N manifest frames for smoke evaluation')
    ap.add_argument('--curve-methods', default='', help='comma-separated method IDs for full lossless AbsRel curves')
    ap.add_argument('--save-full-curves', action='store_true', help='save all45 curves; substantial disk use')
    ap.add_argument('--no-legacy', action='store_true', help='smoke only; requires --max-frames; cannot constitute full evaluation')
    args = ap.parse_args()
    if not 1 <= args.workers <= 4 or args.block_size < 1 or (args.max_frames is not None and args.max_frames < 1):
        ap.error('workers must be 1..4; block-size and max-frames must be positive')
    if args.no_legacy and not args.max_frames:
        ap.error('--no-legacy requires --max-frames')
    deadline = datetime.fromisoformat(args.deadline.replace('Z', '+00:00')) if args.deadline else None
    if deadline and (deadline.tzinfo is None or deadline.utcoffset().total_seconds() != 0):
        ap.error('deadline must explicitly use UTC')
    selected = methods() if args.save_full_curves else [x for x in args.curve_methods.split(',') if x]
    if len(set(selected)) != len(selected) or set(selected) - set(methods()):
        ap.error('unknown or duplicate curve method IDs')
    if args.no_legacy and (args.save_full_curves or any(x in ['DDCV', 'PlaneSweep'] or x.startswith('Grel:') for x in selected)):
        ap.error('legacy curves require the comparator bundle')
    cfg = {k: str(v.resolve()) if isinstance(v, Path) else v for k, v in vars(args).items()}
    cfg['deadline'] = deadline.timestamp() if deadline else None
    cfg['curve_methods'] = selected
    inputs = loadj(args.input_root / 'manifest.json'); ops = loadj(args.operand_root / 'manifest.json')
    frames = inputs.get('frames', inputs.get('records', []))
    if not frames or len({(f['scene'], f['frame']) for f in frames}) != len(frames):
        raise ValueError('empty or duplicate frame manifest')
    cp = loadj(args.checkpoint_manifest)
    cfg['checkpoints'] = {f"{e['family']}:{e['seed']}": e for e in cp.get('entries', cp.get('checkpoints', []))}
    cfg['fits'] = {f"{e['family']}:{e['seed']}": float(e['delta']) for e in loadj(args.cal_fits)['fits']}
    expected = {f'{f}:{s}' for f in FAMILIES for s in SEEDS}
    if set(cfg['checkpoints']) != expected or not expected <= set(cfg['fits']) or not all(np.isfinite(x) for x in cfg['fits'].values()):
        raise ValueError('incomplete checkpoint/CAL fit matrix')
    cfg['operands'] = {e['scene']: e for e in ops['records']}
    legacy_manifest_path = args.legacy_score_root / 'manifest.json'
    cfg['legacy_manifest'] = {e['frame']: e for e in loadj(legacy_manifest_path)['frames']} if legacy_manifest_path.exists() else {}
    source_files = [args.input_root / 'manifest.json', args.operand_root / 'manifest.json', args.cal_fits, args.checkpoint_manifest,
                    Path(__file__), ROOT / 'src/taskspace/geometry.py']
    if legacy_manifest_path.exists():
        source_files.append(legacy_manifest_path)
    identity = {'schema': SCHEMA, 'hashes': {str(p.resolve()): sha(p) for p in source_files}, 'families': FAMILIES, 'seeds': SEEDS,
                'segment_bounds': BOUNDS, 'curve_methods': selected, 'no_legacy': args.no_legacy, 'block_size': args.block_size, 'numpy': np.__version__, 'opencv': cv2.__version__}
    cfg['run_sha256'] = digest(identity)
    args.out.mkdir(parents=True, exist_ok=True); (args.out / 'frames').mkdir(exist_ok=True)
    run_path = args.out / 'run.json'
    if run_path.exists():
        if loadj(run_path)['run_sha256'] != cfg['run_sha256']:
            raise ValueError('output belongs to another evaluation contract')
    else:
        writej(run_path, {**identity, 'run_sha256': cfg['run_sha256'], 'method_ids': methods(), 'gt_used_only_for_metrics': True})
    frames = frames[:args.max_frames] if args.max_frames else frames
    results = []
    if args.workers == 1:
        init_worker(cfg)
        for frame in frames:
            if expired(cfg):
                break
            results.append(evaluate_frame(frame))
    else:
        todo = iter(frames); exhausted = False
        with ProcessPoolExecutor(max_workers=args.workers, initializer=init_worker, initargs=(cfg,)) as pool:
            pending = set()
            while pending or not exhausted:
                while not exhausted and len(pending) < args.workers and not expired(cfg):
                    frame = next(todo, None)
                    if frame is None:
                        exhausted = True
                    else:
                        pending.add(pool.submit(evaluate_frame, frame))
                if expired(cfg):
                    exhausted = True
                if pending:
                    done, pending = wait(pending, return_when=FIRST_COMPLETED)
                    results.extend(f.result() for f in done)
    writej(args.out / f'invocation_{uuid.uuid4().hex}.json', {'run_sha256': cfg['run_sha256'], 'deadline': args.deadline, 'results': results,
            'status': 'DEADLINE' if expired(cfg) else 'COMPLETE_REQUESTED_SCOPE', 'requested_frames': len(frames), 'full_manifest_frames': len(inputs.get('frames', inputs.get('records', [])))})
    print(json.dumps({'status': 'DEADLINE' if expired(cfg) else 'COMPLETE_REQUESTED_SCOPE', 'frames_processed_or_resumed': len(results), 'out': str(args.out)}), flush=True)

if __name__ == '__main__':
    main()
