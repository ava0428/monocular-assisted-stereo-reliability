#!/usr/bin/env python3
"""Validate108 EVAL frames/19 scenes/45 methods and five lossless curves.
Fixed seeds stay within scene units; partial evidence emits status only."""
from __future__ import annotations
import argparse, csv, gzip, hashlib, json, math
from collections import defaultdict
from pathlib import Path
import numpy as np
SEEDS = (20260910, 20260911, 20260912)
FAMILIES = ('r1', 'r2_concat', 'r2_dis', 'r2_gate', 'n_random', 'n_shuffle')
BOUNDS = (0., .2, .4, .6, .8, .9, 1.)
FULL_CURVES = ('Rel-Analytic:r2_gate:20260910', 'Depth-Exact:r2_gate:20260910', 'Depth-Linear:r2_gate:20260910', 'Depth-Only', 'DDCV')
BASE_KEYS = tuple(f'{loss}_{suffix}' for loss in ('epe', 'mae', 'absrel') for suffix in ('80', '90', 'aurc'))
KEYS = BASE_KEYS + tuple(f'{loss}_segment_{i}_{suffix}' for loss in ('epe', 'mae', 'absrel') for i in range(6) for suffix in ('mean', 'contribution'))
SCHEMA = 'jise-exact-unified-analysis-v1'
def loadj(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))
def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1 << 20), b''):
            h.update(block)
    return h.hexdigest()

def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True).encode()).hexdigest()

def writej(path, value):
    with Path(path).open('x', encoding='utf-8') as stream:
        json.dump(value, stream, indent=2, sort_keys=True, allow_nan=False); stream.write('\n')

def writecsv(path, rows):
    with Path(path).open('x', newline='', encoding='utf-8') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader(); writer.writerows(rows)

def method_ids():
    ids = [f'Raw:{f}:{s}' for f in FAMILIES for s in SEEDS]
    ids += [f'Rel-Analytic:{f}:{s}' for f in FAMILIES[:4] for s in SEEDS]
    ids += [f'{r}:r2_gate:{s}' for r in ('DispCal', 'Depth-Exact', 'Depth-Linear') for s in SEEDS]
    return ids + ['Depth-Only', 'DDCV', 'PlaneSweep'] + [f'Grel:{s}' for s in SEEDS]

def scene_equal(frames, keys=KEYS):
    """Return per-scene and equal-scene means; no finite filtering."""
    grouped = defaultdict(list)
    for frame in frames:
        for row in frame['rows']:
            grouped[(frame['scene'], row['method'])].append(row)
    scene_rows = [{'scene': scene, 'method': method, 'frames': len(items),
                   **{key: float(np.mean([r[key] for r in items], dtype=np.float64)) for key in keys}}
                  for (scene, method), items in sorted(grouped.items())]
    cohort = {}
    for method in sorted({r['method'] for r in scene_rows}):
        items = [r for r in scene_rows if r['method'] == method]
        cohort[method] = {'scenes': len(items), **{key: float(np.mean([r[key] for r in items], dtype=np.float64)) for key in keys}}
    return scene_rows, cohort

def paired_bootstrap(seed_by_scene, indices):
    """Average fixed seeds within scene, then resample the same scene indices."""
    values = np.asarray(seed_by_scene, dtype=np.float64)
    if values.ndim != 2 or values.shape[1] != indices.shape[1]:
        raise ValueError('bootstrap requires seed-by-scene matrix')
    scene_delta = np.mean(values, axis=0, dtype=np.float64)
    replicas = np.mean(scene_delta[indices], axis=1, dtype=np.float64)
    ci = np.quantile(replicas, [.025, .975])
    return {'delta': float(scene_delta.mean(dtype=np.float64)), 'ci_low': float(ci[0]), 'ci_high': float(ci[1]), 'scenes': len(scene_delta)}

def segment_differences(left, right):
    values = [left[f'absrel_segment_{i}_contribution'] - right[f'absrel_segment_{i}_contribution'] for i in range(6)]
    delta = left['absrel_aurc'] - right['absrel_aurc']
    if not np.isclose(math.fsum(values), delta, rtol=5e-13, atol=1e-12):
        raise ValueError('segment contribution differences do not sum to exact AURC difference')
    return values, delta

def validate_full_curve(path, row):
    n = row['n_unit']; cuts = [math.ceil(r * n) for r in BOUNDS]
    sums = np.zeros(6, dtype=np.float64); fixed = {}; start = 0
    with gzip.open(path, 'rb') as stream:
        version = np.lib.format.read_magic(stream)
        readers = {(1, 0): np.lib.format.read_array_header_1_0, (2, 0): np.lib.format.read_array_header_2_0}
        if version not in readers: raise ValueError(f'unsupported full curve NPY version: {version}')
        shape, fortran, dtype = readers[version](stream)
        if shape != (n,) or dtype != np.dtype(np.float64) or fortran:
            raise ValueError(f'invalid full native curve header: {path}')
        while start < n:
            payload = stream.read(min(1 << 20, (n - start) * 8))
            if not payload or len(payload) % 8:
                raise ValueError(f'truncated full native curve: {path}')
            values = np.frombuffer(payload, dtype=dtype); end = start + len(values)
            if not np.isfinite(values).all():
                raise ValueError(f'nonfinite full native curve: {path}')
            for i, (lo, hi) in enumerate(zip(cuts[:-1], cuts[1:])):
                left, right = max(start, lo), min(end, hi)
                if left < right:
                    sums[i] += values[left - start:right - start].sum(dtype=np.float64)
            for level in (80, 90):
                k = math.ceil(level / 100 * n)
                if start < k <= end:
                    fixed[f'absrel_{level}'] = float(values[k - start - 1])
            start = end
        if stream.read(1):
            raise ValueError(f'excess full native curve payload: {path}')
    check = {**fixed, 'absrel_aurc': math.fsum(float(x / n) for x in sums), **{f'absrel_segment_{i}_contribution': float(x / n) for i, x in enumerate(sums)}}
    if any(row.get(k) is not None and not np.isclose(v, row[k], rtol=5e-13, atol=1e-12) for k, v in check.items()):
        raise ValueError(f'full curve disagrees with recorded exact metrics: {path}')

def validate(args):
    run = loadj(args.eval_root / 'run.json')
    identity_keys = ('schema', 'hashes', 'families', 'seeds', 'segment_bounds', 'curve_methods', 'no_legacy', 'block_size', 'numpy', 'opencv')
    if digest({k: run[k] for k in identity_keys}) != run['run_sha256'] or run['schema'] != 'jise-exact-unified-eval-v1':
        raise ValueError('invalid run contract digest')
    if tuple(run['segment_bounds']) != BOUNDS or set(run['method_ids']) != set(method_ids()):
        raise ValueError('different method/segment contract')
    inp = loadj(args.input_manifest)
    expected = {(e['scene'], e['frame']): e for e in inp.get('frames', inp.get('records', []))}
    roles_payload = loadj(args.scene_roles)
    role_entries = roles_payload.get('roles', roles_payload.get('scenes', []))
    roles = {e['scene']: e['role'] for e in role_entries}
    eval_scenes = {s for s, role in roles.items() if role == 'EVAL'}
    if len(expected) != 108 or len(eval_scenes) != 19 or {s for s, _ in expected} != eval_scenes:
        raise ValueError('frozen scope must be 108 distinct frames and 19 EVAL-role scenes')
    if sha(args.input_manifest) not in run['hashes'].values():
        raise ValueError('input manifest not hash-bound by evaluation')
    frames, incomplete, evidence = [], [], []
    for path in sorted((args.eval_root / 'frames').glob('*.json')):
        frame = loadj(path); key = (frame['scene'], frame['frame'])
        if key not in expected or roles.get(key[0]) != 'EVAL':
            raise ValueError(f'unexpected frame/role: {key}')
        source = frame['source']
        if digest(source) != frame['input_binding_sha256'] or source['run_sha256'] != run['run_sha256']:
            raise ValueError(f'frame provenance binding mismatch: {key}')
        if source['input_npz_sha256'] != expected[key]['input_sha256']:
            raise ValueError(f'frame input identity mismatch: {key}')
        if source.get('legacy_source_npz_sha256') != expected[key].get('source_score_npz_sha256'):
            if not run['no_legacy']:
                raise ValueError(f'legacy source identity mismatch: {key}')
        if set(source['scores']) != {f'{f}:{s}' for f in FAMILIES for s in SEEDS}:
            raise ValueError(f'raw score provenance matrix mismatch: {key}')
        if tuple(frame['segment_bounds']) != BOUNDS:
            raise ValueError(f'frame segment contract mismatch: {key}')
        ids = [r['method'] for r in frame['rows']]
        if len(ids) != len(set(ids)):
            raise ValueError(f'duplicate method: {key}')
        if set(ids) != set(method_ids()):
            incomplete.append({'frame': '/'.join(key), 'reason': 'INCOMPLETE_METHOD_MATRIX'})
        if 'depth_strata' not in frame:
            incomplete.append({'frame': '/'.join(key), 'reason': 'MISSING_PREDICTION_DEPTH_STRATA'})
        saved = set()
        if sum(a['kind'] == 'plot_samples_only' for a in frame['artifacts']) != 1:
            incomplete.append({'frame': '/'.join(key), 'reason': 'MISSING_OR_DUPLICATE_PLOT_ARTIFACT'})
        for artifact in frame['artifacts']:
            p = (args.eval_root / artifact['path']).resolve()
            if not p.is_relative_to(args.eval_root.resolve()):
                raise ValueError(f'artifact path outside evaluation root: {p}')
            if not p.exists():
                incomplete.append({'frame': '/'.join(key), 'reason': 'MISSING_ARTIFACT', 'path': artifact['path']})
                continue
            if sha(p) != artifact['sha256']:
                raise ValueError(f'artifact hash mismatch: {p}')
            if artifact['kind'] == 'full_absrel_curve_float64_lossless':
                saved.add(artifact['method'])
                row = next(r for r in frame['rows'] if r['method'] == artifact['method'])
                validate_full_curve(p, row)
        if not set(FULL_CURVES) <= saved:
            incomplete.append({'frame': '/'.join(key), 'reason': 'MISSING_REQUIRED_FULL_CURVES', 'missing': sorted(set(FULL_CURVES) - saved)})
        for row in frame['rows']:
            if any(row.get(k) is None or not np.isfinite(row[k]) for k in KEYS):
                incomplete.append({'frame': '/'.join(key), 'method': row['method'], 'reason': 'UNAVAILABLE_METRIC'})
                continue
            for loss in ('epe', 'mae', 'absrel'):
                total = math.fsum(row[f'{loss}_segment_{i}_contribution'] for i in range(6))
                if not np.isclose(total, row[f'{loss}_aurc'], rtol=5e-13, atol=1e-12) or sum(row[f'{loss}_segment_{i}_counts'] for i in range(6)) != row['n_unit']:
                    raise ValueError(f'full-count segment integral mismatch: {key}/{row["method"]}')
            if 'depth_strata' in frame:
                if sum(row[f'depth_bin_{i}_universe_count'] for i in range(3)) != row['n_unit'] or sum(row[f'depth_bin_{i}_retained_count_80'] for i in range(3)) != math.ceil(.8 * row['n_unit']):
                    raise ValueError(f'depth stratum count mismatch: {key}')
                numerator = math.fsum(row[f'depth_bin_{i}_absrel_sum_80'] for i in range(3))
                if not np.isclose(numerator / math.ceil(.8 * row['n_unit']), row['absrel_80'], rtol=5e-13, atol=1e-12):
                    raise ValueError(f'depth stratum loss sum mismatch: {key}')
        evidence.append({'frame': '/'.join(key), 'json_sha256': sha(path), 'binding_sha256': frame['input_binding_sha256']})
        frames.append(frame)
    observed = [(f['scene'], f['frame']) for f in frames]
    if len(observed) != len(set(observed)):
        raise ValueError('duplicate frame IDs')
    missing = sorted(set(expected) - set(observed))
    if missing:
        incomplete.append({'reason': 'MISSING_FRAMES', 'frames': ['/'.join(x) for x in missing]})
    return run, frames, incomplete, evidence

def pair_tables(scene_rows, scenes):
    lookup = {(r['scene'], r['method']): r for r in scene_rows}
    rng = np.random.default_rng(20260913)
    indices = rng.integers(0, len(scenes), size=(10000, len(scenes)))
    ra = [f'Rel-Analytic:{f}:{{seed}}' for f in FAMILIES[:4]]
    pairs = [(x, 'Depth-Only') for x in ra] + [(ra[i], ra[j]) for i in range(4) for j in range(i)]
    pairs += [(f'{r}:r2_gate:{{seed}}', 'Depth-Only') for r in ('DispCal', 'Depth-Exact', 'Depth-Linear')]
    pairs += [(f'Raw:{f}:{{seed}}', 'Raw:r1:{seed}') for f in FAMILIES[1:]]
    pairs += [('Raw:r2_dis:{seed}', 'Raw:r2_concat:{seed}'), ('Raw:r2_gate:{seed}', 'Raw:r2_dis:{seed}')]
    pairs += [('Raw:r2_concat:{seed}', f'Raw:{f}:{{seed}}') for f in ('n_random', 'n_shuffle')]
    pairs += [(f'{r}:r2_gate:{{seed}}', 'DDCV') for r in ('Rel-Analytic', 'Depth-Exact', 'Depth-Linear')]
    pairs += [('Rel-Analytic:r2_gate:{seed}', 'Depth-Exact:r2_gate:{seed}'), ('Depth-Exact:r2_gate:{seed}', 'Depth-Linear:r2_gate:{seed}'), ('Depth-Only', 'DDCV')]
    boot, differences = [], []
    for left, right in pairs:
        for metric in BASE_KEYS:
            if '{seed}' not in left and '{seed}' not in right:
                matrix = np.asarray([[lookup[(s, left)][metric] - lookup[(s, right)][metric] for s in scenes]], dtype=np.float64)
                boot.append({'left': left, 'right': right, 'seed_scope': 'SHARED_RULE_SINGLE', 'metric': metric, **paired_bootstrap(matrix, indices), 'replicates': 10000, 'bootstrap_seed': 20260913})
                differences.extend({'scene': s, 'left': left, 'right': right, 'seed_scope': 'SHARED_RULE_SINGLE', 'metric': metric, 'delta': float(matrix[0, j])} for j, s in enumerate(scenes))
                continue
            matrix = np.asarray([[lookup[(s, left.format(seed=seed))][metric] - lookup[(s, right.format(seed=seed))][metric] for s in scenes] for seed in SEEDS], dtype=np.float64)
            for i, seed in enumerate(SEEDS):
                boot.append({'left': left.format(seed=seed), 'right': right.format(seed=seed), 'seed_scope': seed, 'metric': metric, **paired_bootstrap(matrix[i:i + 1], indices), 'replicates': 10000, 'bootstrap_seed': 20260913})
                for j, scene in enumerate(scenes):
                    differences.append({'scene': scene, 'left': left.format(seed=seed), 'right': right.format(seed=seed), 'seed_scope': seed, 'metric': metric, 'delta': float(matrix[i, j])})
            boot.append({'left': left, 'right': right, 'seed_scope': 'FIXED_3_SEED_MEAN_WITHIN_SCENE', 'metric': metric, **paired_bootstrap(matrix, indices), 'replicates': 10000, 'bootstrap_seed': 20260913})
            for j, scene in enumerate(scenes):
                differences.append({'scene': scene, 'left': left, 'right': right, 'seed_scope': 'FIXED_3_SEED_MEAN_WITHIN_SCENE', 'metric': metric, 'delta': float(matrix[:, j].mean(dtype=np.float64))})
    return boot, differences

def plot_tables(root, frames, scenes):
    grouped = defaultdict(list)
    for frame in frames:
        artifact = next(a for a in frame['artifacts'] if a['kind'] == 'plot_samples_only')
        with np.load(root / artifact['path'], allow_pickle=False) as z:
            for method in method_ids():
                values = np.asarray(z[f'{method}/absrel'], dtype=np.float64)
                if values.shape != (1001,) or not np.isfinite(values).all():
                    raise ValueError('invalid 1001-point visual samples')
                grouped[(frame['scene'], method)].append(values)
    plots = {'requested_coverage': np.linspace(0., 1., 1001)}
    for method in method_ids():
        plots[method] = np.mean([np.mean(grouped[(s, method)], axis=0, dtype=np.float64) for s in scenes], axis=0, dtype=np.float64)
    for method in FULL_CURVES:
        if method != 'DDCV':
            plots[f'DIFF:{method}:minus:DDCV'] = plots[method] - plots['DDCV']
    for rule in ('Rel-Analytic', 'Depth-Exact', 'Depth-Linear'):
        for seed in SEEDS:
            method = f'{rule}:r2_gate:{seed}'
            plots[f'DIFF:{method}:minus:Depth-Only'] = plots[method] - plots['Depth-Only']
    return plots

def depth_strata_tables(frames):
    """Pool stratum numerators/counts within each scene, then equal-weight scenes."""
    grouped = defaultdict(list)
    for frame in frames:
        for row in frame['rows']:
            grouped[(frame['scene'], row['method'])].append(row)
    scene_rows = []
    for (scene, method), items in sorted(grouped.items()):
        for i in range(3):
            count = sum(r[f'depth_bin_{i}_retained_count_80'] for r in items)
            total = sum(r[f'depth_bin_{i}_universe_count'] for r in items)
            numerator = math.fsum(r[f'depth_bin_{i}_absrel_sum_80'] for r in items)
            scene_rows.append({'scene': scene, 'method': method, 'depth_bin': i, 'frames': len(items), 'retained_count_80': count,
                               'universe_count': total, 'absrel_sum_80': numerator, 'absrel_80': numerator / count if count else None,
                               'retained_fraction_80': count / total if total else None})
    cohort = []
    for method in sorted({r['method'] for r in scene_rows}):
        for i in range(3):
            items = [r for r in scene_rows if r['method'] == method and r['depth_bin'] == i]
            available = [r for r in items if r['absrel_80'] is not None]
            cohort.append({'method': method, 'depth_bin': i, 'scenes': len(items), 'nonempty_retained_scenes': len(available),
                           'scene_equal_absrel_80': float(np.mean([r['absrel_80'] for r in available], dtype=np.float64)) if len(available) == len(items) else None,
                           'scene_equal_retained_fraction_80': float(np.mean([r['retained_fraction_80'] for r in items], dtype=np.float64)) if all(r['retained_fraction_80'] is not None for r in items) else None,
                           'retained_count_total_80': sum(r['retained_count_80'] for r in items), 'universe_count_total': sum(r['universe_count'] for r in items)})
    return scene_rows, cohort

def calibration_tables(frames, scenes):
    original = [{'scene': f['scene'], 'frame': f['frame'], 'family_seed': k, 'description': v} for f in frames for k, v in f['calibration_diagnostics'].items()]
    scene_rows = []
    for family_seed in sorted({r['family_seed'] for r in original}):
        for scene in scenes:
            items = [r['description'] for r in original if r['scene'] == scene and r['family_seed'] == family_seed]
            scene_rows.append({'scene': scene, 'family_seed': family_seed, 'frames': len(items), 'delta_native_disparity_px': items[0]['delta_native_disparity_px'],
                               'frame_equal_fraction_absolute_delta_ge_base': float(np.mean([r['fraction_absolute_delta_ge_base'] for r in items], dtype=np.float64)),
                               'calibrated_zero_count_total': sum(r['calibrated_zero_count'] for r in items)})
    cohort = []
    for family_seed in sorted({r['family_seed'] for r in original}):
        items = [r for r in scene_rows if r['family_seed'] == family_seed]
        cohort.append({'family_seed': family_seed, 'scenes': len(items), 'delta_native_disparity_px': items[0]['delta_native_disparity_px'],
                       'scene_equal_fraction_absolute_delta_ge_base': float(np.mean([r['frame_equal_fraction_absolute_delta_ge_base'] for r in items], dtype=np.float64)),
                       'calibrated_zero_count_total': sum(r['calibrated_zero_count_total'] for r in items)})
    return {'interpretation': 'Original per-frame quantiles retained verbatim; no averaged quantile is called a global quantile. Fractions use frame then equal-scene means; zero counts are descriptive totals.',
            'original_frame_descriptions': original, 'scene_descriptions': scene_rows, 'cohort_descriptions': cohort}

def main():
    ap = argparse.ArgumentParser(description=__doc__)
    for name in ('eval-root', 'input-manifest', 'scene-roles', 'original-summary', 'out'):
        ap.add_argument('--' + name, type=Path, required=True)
    ap.add_argument('--allow-partial', action='store_true')
    args = ap.parse_args()
    run, frames, incomplete, evidence = validate(args)
    if incomplete and not args.allow_partial:
        raise SystemExit(f'REJECTED_PARTIAL: {len(frames)}/108 frames; {len(incomplete)} incomplete evidence records')
    args.out.mkdir(parents=True, exist_ok=False)
    provenance = {'schema': SCHEMA, 'evaluation_run_sha256': run['run_sha256'], 'analysis_source_sha256': sha(Path(__file__)),
                  'input_manifest_sha256': sha(args.input_manifest), 'scene_roles_sha256': sha(args.scene_roles), 'original_summary_sha256': sha(args.original_summary), 'frames': evidence}
    stages = [{'stage': x, 'status': 'PENDING'} for x in ('INPUT_INTEGRITY', 'SCENE_AGGREGATION', 'MATCHED_DIFFERENCES', 'AUDIT_ARTIFACTS')]
    if incomplete:
        writej(args.out / 'status.json', {**provenance, 'status': 'PARTIAL_DESCRIPTIVE_ONLY', 'observed_frames': len(frames), 'incomplete': incomplete, 'stages': stages})
        print('PARTIAL_DESCRIPTIVE_ONLY'); return
    stages[0]['status'] = 'COMPLETE'
    writej(args.out / 'stage1_integrity.json', {**provenance, 'status': 'VALIDATED_108_FRAMES_19_EVAL_SCENES_45_METHODS', 'required_full_curves': FULL_CURVES})
    scene_rows, cohort = scene_equal(frames); scenes = sorted({f['scene'] for f in frames})
    writecsv(args.out / 'scene_metrics_19x45.csv', scene_rows)
    writej(args.out / 'cohort_metrics.json', {'aggregation': 'float64 frame->scene->equal_scene; seeds are fixed replicates', 'rows': cohort})
    strata_scenes, strata_cohort = depth_strata_tables(frames)
    writecsv(args.out / 'depth_strata_scene_metrics.csv', strata_scenes)
    writej(args.out / 'depth_strata_cohort.json', {'aggregation': 'Per-frame prediction-depth tertiles; pool retained AbsRel numerators/counts within scene, then equal-scene means; empty strata remain unavailable.', 'rows': strata_cohort,
            'original_prediction_depth_boundaries': [{'scene': f['scene'], 'frame': f['frame'], **f['depth_strata']} for f in frames]})
    seed_groups = defaultdict(list)
    for method, row in cohort.items():
        group = method.rsplit(':', 1)[0] if method.split(':')[-1] in {str(s) for s in SEEDS} else method
        seed_groups[group].append(row)
    fixed = [{'method_group': k, 'fixed_seed_replicates': len(items), **{key: float(np.mean([r[key] for r in items], dtype=np.float64)) for key in KEYS}} for k, items in sorted(seed_groups.items())]
    writecsv(args.out / 'fixed_seed_means.csv', fixed); stages[1]['status'] = 'COMPLETE'
    boot, differences = pair_tables(scene_rows, scenes)
    writecsv(args.out / 'pair_bootstrap_10000.csv', boot); writecsv(args.out / 'pair_scene_differences.csv', differences)
    segment_pairs = [(m, 'DDCV') for m in FULL_CURVES if m != 'DDCV']
    segment_pairs += [(f'{r}:r2_gate:{s}', 'Depth-Only') for r in ('Rel-Analytic', 'Depth-Exact', 'Depth-Linear') for s in SEEDS]
    segments = []
    for left, right in segment_pairs:
        values, delta = segment_differences(cohort[left], cohort[right])
        for i, contribution in enumerate(values):
            segments.append({'left': left, 'right': right, 'lo': BOUNDS[i], 'hi': BOUNDS[i + 1], 'exact_absrel_aurc_contribution_difference': contribution, 'exact_total_absrel_aurc_difference': delta})
    writecsv(args.out / 'exact_segment_differences.csv', segments)
    with (args.out / 'plot_cohort_visualization_only_1001.npz').open('xb') as stream:
        np.savez_compressed(stream, **plot_tables(args.eval_root, frames, scenes))
    stages[2]['status'] = 'COMPLETE'
    original = loadj(args.original_summary); comparisons = []
    key_map = {'absrel_80': 'absrel_80', 'absrel_90': 'absrel_90', 'depth_mae_80': 'mae_80', 'epe_aurc': 'epe_aurc', 'absrel_aurc': 'absrel_aurc'}
    for old in original['rows']:
        method = f"Raw:{old['family']}:{old['seed']}"
        for old_key, new_key in key_map.items():
            before, after = old[old_key], cohort[method][new_key]
            comparisons.append({'method': method, 'metric': new_key, 'original_20261005_float64': before, 'new_exact_float64': after, 'difference_new_minus_original': after - before,
                                'within_rtol5e13_atol1e12': bool(np.isclose(after, before, rtol=5e-13, atol=1e-12))})
    writecsv(args.out / 'raw_precision_comparison_v1.csv', comparisons)
    writej(args.out / 'calibration_descriptives.json', calibration_tables(frames, scenes))
    stages[3]['status'] = 'COMPLETE'
    artifact_hashes = {p.name: sha(p) for p in sorted(args.out.iterdir()) if p.is_file()}
    writej(args.out / 'status.json', {**provenance, 'status': 'COMPLETE', 'stages': stages, 'artifacts_sha256': artifact_hashes,
            'statistics': 'Exact discrete all-count frame integrals; fixed-seed means within scene; paired 10000 scene bootstrap uses identical indices, seed20260913.',
            'precision': 'Block cumsum preserves the complete float64 accumulation order; segment/cohort reductions allow rtol5e-13,atol1e-12 summation tolerance.',
            'plots': '1001-point arrays are visualization only and never substitute for any AURC or segment integral.', 'full_curves_retained': FULL_CURVES})
    print(json.dumps({'status': 'COMPLETE', 'frames': len(frames), 'scenes': len(scenes), 'methods': len(cohort), 'out': str(args.out)}))

if __name__ == '__main__':
    main()
