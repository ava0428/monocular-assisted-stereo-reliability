"""CAL raw-score preparation. Default is metadata-only planning, no model load."""

import argparse
import hashlib
import io
import json
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
MANIFEST = ROOT / "manifests/v4_booster_cal_frames_125.json"
FRAME_SHA = "ac504eff5bc4da1919fd52bd31f4ad79f2d4f08689bb74f2fb79931052d2c1c8"
BINDING_SHA = "2b18650a04ea9254374ec15b82cd90b468671834ec2adb214fccd4146dc5f548"
MODEL_CONFIG_SHA = "72660df7d6e39c248c3f2174cfc5fad59a6ffd101ad67e8a6d29c741f9143eee"


def execution_identity():
    payload = (ROOT / "manifests/v4_cal_execution_code_130.json").read_bytes()
    for entry in json.loads(payload)["files"]:
        path = (ROOT / entry["path"]).resolve()
        if not path.is_relative_to(ROOT) or hashlib.sha256(path.read_bytes()).hexdigest() != entry["sha256"]:
            raise ValueError("execution package changed")
    return hashlib.sha256(payload).hexdigest()


def checked_inputs():
    def read(path, digest):
        data = path.read_bytes()
        if hashlib.sha256(data).hexdigest() != digest:
            raise ValueError(f"frozen input changed: {path.name}")
        return data
    manifest = json.loads(read(MANIFEST, FRAME_SHA))
    binding = json.loads(read(ROOT / "manifests/v4_scorer_weight_binding_127.json", BINDING_SHA))
    read(ROOT / "configs/models/mvt.yaml", MODEL_CONFIG_SHA)
    expected = {(f, s) for f in ("r1", "r2_gate", "grel_direct")
                for s in (20260910, 20260911, 20260912)}
    if len(binding["checkpoints"]) != 9 or {(e["family"], e["seed"]) for e in binding["checkpoints"]} != expected:
        raise ValueError("frozen nine-head set mismatch")
    for entry in binding["checkpoints"]:
        if not (ROOT / entry["path"]).resolve().is_relative_to(ROOT / "weights"):
            raise ValueError("checkpoint outside workspace weights")
    if len(manifest["scenes"]) != 19 or any(s["role"] != "CAL" for s in manifest["scenes"]):
        raise ValueError("CAL cohort mismatch")
    for scene in manifest["scenes"]:
        for frame in scene["frames"]:
            for side in ("left", "right"):
                path = (ROOT / frame[side]["path"]).resolve()
                if not path.is_relative_to(ROOT / "outputs/v4_booster_cal_range_116" / scene["scene"]):
                    raise ValueError("CAL frame path outside bound scene")
    return manifest, binding


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--run", action="store_true", help="requires separate GPU authorization")
    args = parser.parse_args()
    manifest, _ = checked_inputs()
    frames = [(s["scene"], f) for s in manifest["scenes"] for f in s["frames"]]
    print(json.dumps({"pairs": len(frames), "stereo_forwards": len(frames)*6,
                      "mono_forwards": len(frames), "head_forwards": len(frames)*9,
                      "status": "DRAFT_NOT_AUTHORIZED", "run": args.run}), flush=True)
    if not args.run:
        return
    # Keep execution closed until runtime/storage limits and the complete
    # calibration plan have passed integration review and user authorization.
    raise RuntimeError("129 is preparation-only; execution gate is not yet released")


def score_frame(left, right, stereo, mono, models, constants, device, deadline):
    """In-memory frame operation; caller owns verified input and output files."""
    import torch
    from src.baselines.shared_reference_inputs import shared_reference_inputs
    from src.taskspace.frozen_head_batch import score_frozen_heads

    def check():
        if time.monotonic() >= deadline:
            raise TimeoutError("CAL budget reached before next model call")

    def predict_stereo(a, b):
        check()
        return stereo.predict(a, b).disparity

    def predict_mono(a):
        check()
        return mono.predict(a).relative_depth

    check()
    if torch.device(device).type == "cuda":
        torch.cuda.synchronize(device)
    start = time.monotonic()
    shared = shared_reference_inputs(left, right, predict_stereo, predict_mono)
    heads = score_frozen_heads(models, shared, constants, device, before_head=check)
    if torch.device(device).type == "cuda":
        torch.cuda.synchronize(device)
    return shared, heads, time.monotonic() - start


def read_bound_rgb(entry):
    import cv2
    import numpy as np
    path = (ROOT / entry["path"]).resolve()
    if not path.is_relative_to(ROOT / "outputs/v4_booster_cal_range_116"):
        raise ValueError("image outside CAL download root")
    payload = path.read_bytes()
    if hashlib.sha256(payload).hexdigest() != entry["sha256"]:
        raise ValueError("CAL image hash mismatch")
    image = cv2.imdecode(np.frombuffer(payload, dtype=np.uint8), cv2.IMREAD_COLOR)
    if image is None or image.shape != (3008, 4112, 3):
        raise ValueError("CAL RGB grid mismatch")
    return cv2.resize(cv2.cvtColor(image, cv2.COLOR_BGR2RGB), (1028, 752),
                      interpolation=cv2.INTER_AREA)


def run_cal_worker(manifest, output, deadline, byte_limit):
    """Draft worker; caller must enforce a hard process timeout and frozen manifest."""
    checked_manifest, binding = checked_inputs()
    if manifest != checked_manifest:
        raise ValueError("worker manifest differs from frozen input")
    output = Path(output).resolve()
    if not output.is_relative_to(ROOT / "outputs") or output == ROOT / "outputs":
        raise ValueError("run output must be a new directory under workspace outputs")
    if not 0 < byte_limit <= 5_000_000_000:
        raise ValueError("output cap must be at most 5 GB")
    if not 0 < deadline - time.monotonic() <= 7200:
        raise ValueError("worker deadline must be within two hours")
    import torch
    from src.adapters.raft_stereo import StereoAdapter
    from src.adapters.depth_anything import MonoAdapter
    from src.evidence.normalization import NormalizationConstants
    from src.taskspace.middlebury_scores import load_verified_model
    from src.utils.config import load_paths, load_yaml

    if output.exists():
        raise FileExistsError("CAL run directory already exists")
    if not torch.cuda.is_available():
        raise RuntimeError("authorized local CUDA device required")
    paths = load_paths()
    config = load_yaml(ROOT / "configs/models/mvt.yaml")
    stereo = StereoAdapter(paths["raft_source"], paths["raft_checkpoint"], config["raft_stereo"], "cuda")
    mono = MonoAdapter(paths["depth_anything_source"], paths["depth_anything_checkpoint"], config["depth_anything_v2"], "cuda")
    models = {(e["family"], e["seed"]): load_verified_model(
        e["family"], ROOT / e["path"], e, torch.device("cuda")) for e in binding["checkpoints"]}
    constants = NormalizationConstants.load(ROOT / "configs/normalization_sceneflow_train.json")
    output.mkdir(parents=True, exist_ok=False)
    spent = 0
    with (output / "frames.jsonl").open("x", encoding="utf-8") as log:
        for scene in manifest["scenes"]:
            if scene["role"] != "CAL":
                raise ValueError("non-CAL scene rejected")
            for frame in scene["frames"]:
                if time.monotonic() >= deadline:
                    raise TimeoutError("CAL deadline before image read")
                left, right = (read_bound_rgb(frame[k]) for k in ("left", "right"))
                shared, heads, seconds = score_frame(left, right, stereo, mono, models, constants, "cuda", deadline)
                # Reserve 1 MiB for receipts within the total output cap.
                record = save_frame(output / f"{scene['scene']}_{frame['frame']}.npz",
                                    shared, heads, byte_limit - spent - 1_048_576)
                spent += record["bytes"]
                record.update(scene=scene["scene"], frame=frame["frame"], seconds=seconds,
                              weight_binding_sha256=BINDING_SHA)
                log.write(json.dumps(record) + "\n")
                log.flush()
                print(f"{scene['scene']}/{frame['frame']} saved", flush=True)


def save_frame(path, shared, heads, remaining_bytes):
    """Exclusive NPZ write, byte budget checked before disk mutation.

    Returned identity belongs in the run receipt. Failed writes are left for
    inspection; no automatic overwrite/resume of partial evidence.
    """
    import numpy as np
    from src.taskspace.frozen_head_batch import FAMILIES, SEEDS

    expected = {f"{family}_seed{seed}" for family in FAMILIES for seed in SEEDS}
    if set(heads) != expected:
        raise ValueError("complete nine-head output required")
    maps = {k: shared[k] for k in ("stereo_disparity", "mono_relative_depth",
                                  "plane_sweep", "ddcv_full_reference")}
    maps.update(heads)
    shape = np.shape(shared["stereo_disparity"])
    if len(shape) != 2 or any(np.shape(v) != shape for v in maps.values()):
        raise ValueError("all saved maps must share a 2D grid")
    buffer = io.BytesIO()
    np.savez(buffer, **{k: np.asarray(v, dtype=np.float32) for k, v in maps.items()})
    payload = buffer.getvalue()
    if len(payload) > remaining_bytes:
        raise ValueError("frame exceeds remaining output budget")
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("xb") as stream:
        stream.write(payload)
    return {"path": str(path), "bytes": len(payload),
            "sha256": hashlib.sha256(payload).hexdigest(), "grid_hw": list(shape)}


def supervise_cal(output, seconds=7200, byte_limit=5_000_000_000):
    """Draft opt-in supervisor; CLI remains closed pending review/authorization."""
    import multiprocessing

    manifest, _ = checked_inputs()
    code_sha = execution_identity()
    output = Path(output).resolve()
    if not output.is_relative_to(ROOT / "outputs") or output == ROOT / "outputs":
        raise ValueError("supervisor output must be under workspace outputs")
    if not 0 < seconds <= 7200 or not 0 < byte_limit <= 5_000_000_000:
        raise ValueError("supervisor limits exceed draft ceiling")
    output.mkdir(parents=True, exist_ok=False)
    started = time.monotonic()
    process = multiprocessing.get_context("spawn").Process(
        target=worker_with_failure_receipt,
        args=(manifest, output / "frames", started + seconds, byte_limit, code_sha),
    )
    status = "FAILED"
    try:
        process.start()
        process.join(max(0, seconds - (time.monotonic() - started)))
        if process.is_alive():
            status = "TIMEOUT"
        elif process.exitcode == 0:
            status = "COMPLETE"
    finally:
        if process.pid is not None and process.is_alive():
            process.terminate()
            process.join(5)
            if process.is_alive():
                process.kill()
                process.join(5)
        receipt = {
            "status": status, "exitcode": process.exitcode,
            "elapsed_seconds": time.monotonic() - started,
            "timeout_seconds": seconds, "byte_limit": byte_limit,
            "frame_manifest_sha256": FRAME_SHA, "weight_binding_sha256": BINDING_SHA,
            "execution_sha256": code_sha, "model_config_sha256": MODEL_CONFIG_SHA,
            "partial_policy": "Preserve partial outputs; no automatic restart or overwrite",
        }
        failure_path = output / "worker_failure.json"
        if failure_path.exists():
            failure_bytes = failure_path.read_bytes()
            receipt["worker_failure"] = json.loads(failure_bytes)
            receipt["worker_failure_sha256"] = hashlib.sha256(failure_bytes).hexdigest()
            if receipt["worker_failure"]["exception_type"] == "TimeoutError":
                receipt["status"] = "TIMEOUT"
        with (output / "terminal.json").open("x", encoding="utf-8") as stream:
            json.dump(receipt, stream, indent=2)
    return receipt


def worker_with_failure_receipt(manifest, output, deadline, byte_limit, expected_code):
    try:
        if execution_identity() != expected_code:
            raise ValueError("parent/worker execution identity mismatch")
        run_cal_worker(manifest, output, deadline, byte_limit)
    except BaseException as error:
        with (output.parent / "worker_failure.json").open("x", encoding="utf-8") as stream:
            json.dump({"exception_type": type(error).__name__, "message": str(error)[:2000]}, stream)
        raise


if __name__ == "__main__":
    main()
