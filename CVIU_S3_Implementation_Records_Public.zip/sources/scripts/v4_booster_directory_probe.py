"""Read only Booster ZIP directory metadata; never open archive members."""

from __future__ import annotations

import argparse
import hashlib
import io
import json
import re
import unicodedata
import urllib.request
import zipfile
from datetime import datetime, timezone
from pathlib import Path


URL = "https://amsacta.unibo.it/id/eprint/6876/1/booster_gt.zip"
MAX_BYTES = 1_048_576
SPLIT_SALT = "V4-BOOSTER-2022-SCENE-v1\n"


def train_scenes(tail: bytes) -> tuple[list[str], int]:
    """Inspect the central directory only; retain train/balanced names only."""
    scenes: set[str] = set()
    train_members = 0
    with zipfile.ZipFile(io.BytesIO(tail)) as archive:
        for info in archive.infolist():
            parts = info.filename.replace("\\", "/").strip("/").split("/")
            lower = [part.lower() for part in parts]
            for index in (0, 1):  # at most one archive top-level directory
                if lower[index : index + 2] != ["train", "balanced"]:
                    continue
                if len(parts) <= index + 2:  # parent directory, not a scene member
                    break
                if any(part in ("", ".", "..") for part in parts):
                    raise ValueError("invalid TRAIN path in archive directory")
                train_members += 1
                scenes.add(parts[index + 2])
                break
    return sorted(scenes), train_members


def split(scenes: list[str]) -> list[dict[str, str]]:
    if len(scenes) != 38:
        raise ValueError(f"expected 38 TRAIN balanced scenes, found {len(scenes)}")
    keys = [unicodedata.normalize("NFC", name).lower() for name in scenes]
    if len(set(keys)) != 38:
        raise ValueError("TRAIN scene keys collide after NFC/lower normalization")
    rows = [
        {"scene": name, "scene_key": key,
         "group_sha256": hashlib.sha256((SPLIT_SALT + key).encode("utf-8")).hexdigest()}
        for name, key in zip(scenes, keys)
    ]
    rows.sort(key=lambda row: (row["group_sha256"], row["scene_key"]))
    for index, row in enumerate(rows):
        row["role"] = "CAL" if index < 19 else "EVAL"
    return rows


def fetch_tail() -> tuple[bytes, dict[str, str | int]]:
    request = urllib.request.Request(
        URL, headers={"Range": f"bytes=-{MAX_BYTES}", "User-Agent": "project4-v4-metadata/1.0"}
    )
    with urllib.request.urlopen(request, timeout=45) as response:
        if response.status != 206:
            raise ValueError(f"Range unsupported: HTTP {response.status}; body not read")
        content_range = response.headers.get("Content-Range", "")
        match = re.fullmatch(r"bytes (\d+)-(\d+)/(\d+)", content_range)
        if not match:
            raise ValueError("missing or malformed Content-Range; body not read")
        start, end, total = map(int, match.groups())
        if end + 1 != total or end - start + 1 > MAX_BYTES:
            raise ValueError("response is not a bounded archive suffix; body not read")
        tail = response.read(MAX_BYTES + 1)
        if len(tail) != end - start + 1:
            raise ValueError("Range response size mismatch")
        return tail, {"archive_total_bytes": total, "range_start": start,
                      "range_end": end, "etag": response.headers.get("ETag", "")}


def self_test() -> None:
    buffer = io.BytesIO()
    buffer.write(b"X" * (MAX_BYTES + 8))
    with zipfile.ZipFile(buffer, "w", allowZip64=True) as archive:
        archive.writestr("pack/train/balanced/", b"")
        for index in range(38):
            archive.writestr(f"pack/train/balanced/Scene{index:02d}/image.png", b"x")
        archive.writestr("pack/test/Secret/image.png", b"x")
    names, members = train_scenes(buffer.getvalue()[-MAX_BYTES:])
    rows = split(names)
    assert members == 38 and len(rows) == 38
    assert sum(row["role"] == "CAL" for row in rows) == 19
    assert sum(row["role"] == "EVAL" for row in rows) == 19
    assert all("Secret" not in row["scene"] for row in rows)
    print("PASS: bounded ZIP suffix parses 38 TRAIN scenes; test name excluded; 19/19 split")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--self-test", action="store_true")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    if args.self_test:
        self_test()
        return
    if args.output is None:
        parser.error("--output is required unless --self-test is used")
    tail, headers = fetch_tail()
    names, members = train_scenes(tail)
    rows = split(names)
    receipt = {
        "schema": "v4-booster-directory-probe-1",
        "status": "TRAIN_DIRECTORY_ONLY_UNVERIFIED_ARCHIVE_MEMBERS",
        "source_url": URL,
        "retrieved_utc": datetime.now(timezone.utc).isoformat(),
        "range_bytes": len(tail),
        "range_sha256": hashlib.sha256(tail).hexdigest(),
        "archive_sha256": "NOT_COMPUTED",
        "train_balanced_members": members,
        "train_balanced_scenes": rows,
        "official_test_contents_read": False,
        **headers,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_bytes((json.dumps(receipt, ensure_ascii=False, indent=2) + "\n").encode("utf-8"))
    print(f"WROTE {args.output}; TRAIN balanced scenes=38; CAL=19; EVAL=19")


if __name__ == "__main__":
    main()
