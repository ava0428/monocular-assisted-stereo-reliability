"""Week 4 Phase G: train one R2 run under the frozen protocol.

Implements ``configs/experiments/week4_r2_mono_increment.yaml``
(``week4_r2_mono_increment_v1``). The only variable across runs is which
evidence the predictor sees; training protocol, loss, output parameterization,
validation cadence and checkpoint rule are inherited verbatim from the frozen
Week 3 protocol.

R0/R1 are **not** touched by this script: ``scripts/train_reliability.py`` and
its code path are left exactly as they were, so the archived Week 3 execution
semantics stay reproducible.

The mono path is an **offline/cached prior scenario** (V3 §28): the mono map is
read from the frozen mono cache, never inferred here.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import platform
import subprocess
import sys
import time
import traceback
from concurrent.futures import ProcessPoolExecutor
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import torch

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT))

from src.data.mono_cache import MONO_CACHE_SCHEMA
from src.evidence.mono_evidence import MONO_CHANNELS, r2_evidence, shuffle_mono_in_batch
from src.evidence.negative_controls import (
    N_RANDOM_SEED,
    N_SHUFFLE_SEED,
    random_control_channels,
    shuffle_permutation,
)
from src.evidence.normalization import NormalizationConstants, normalize_features_torch
from src.evidence.stereo_evidence_gpu import r1_features_gpu
from src.evaluation.risk import aurc, ause, bad2_auprc
from src.models.risk_predictor import (
    build_m_only,
    build_r2_concat,
    build_r2_dis,
    build_r2_gate,
)
from src.training.r2_data import SceneFlowR2Dataset, collate_r2
from src.training.masked_loss import masked_log_error_smooth_l1
from src.utils.config import load_paths, load_yaml

FROZEN_NORMALIZATION_DIGEST = "42ef8559dce15302ef1c386aba4e2b80d3711eeca98d5b9281ec1d2f5883080e"

#: CLI name -> (config variant name, model builder). Negative controls use the
#: R2-dis topology, which is what gives them the same parameter budget.
VARIANT_MODELS = {
    "m_only": ("M-only", build_m_only),
    "r2_concat": ("R2-concat", build_r2_concat),
    "r2_dis": ("R2-dis", build_r2_dis),
    "r2_gate": ("R2-gate", build_r2_gate),
    "n_random": ("R2-dis (N-random)", build_r2_dis),
    "n_shuffle": ("R2-dis (N-shuffle)", build_r2_dis),
}

#: Exact expected parameter counts (Phase H.1). A mismatch aborts the run.
EXPECTED_PARAMETERS = {
    "m_only": 18721,
    "r2_concat": 19073,
    "r2_dis": 19169,
    "r2_gate": 18910,
    "n_random": 19169,
    "n_shuffle": 19169,
}


def log(message: str) -> None:
    print(f"[{datetime.now(timezone.utc).isoformat()}] {message}", flush=True)


def sha256_file(path: Path) -> str:
    """Digest of a possibly large file, streamed."""
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(8 * 1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def lr_at_step(step: int, max_steps: int, warmup: int, base_lr: float, final_lr: float) -> float:
    """Frozen schedule: linear warmup then cosine decay to ``final_lr``."""
    if step < warmup:
        return base_lr * (step + 1) / warmup
    progress = (step - warmup) / max(1, max_steps - warmup)
    progress = min(max(progress, 0.0), 1.0)
    return final_lr + 0.5 * (base_lr - final_lr) * (1.0 + math.cos(math.pi * progress))


def better(candidate: dict, incumbent: dict | None) -> bool:
    """Frozen rule: min AURC, then min AUSE, then max Bad2-AUPRC, then earlier step."""
    if incumbent is None:
        return True
    for key, prefer_lower in (("aurc", True), ("ause", True), ("bad2_auprc", False)):
        a, b = candidate[key], incumbent[key]
        if not np.isfinite(a):
            return False
        if not np.isfinite(b):
            return True
        if prefer_lower and a < b - 1e-12:
            return True
        if not prefer_lower and a > b + 1e-12:
            return True
        if prefer_lower and a > b + 1e-12:
            return False
        if not prefer_lower and a < b - 1e-12:
            return False
    return candidate["step"] < incumbent["step"]


def build_inputs(variant: str, left, right, disparity, mono, constants):
    """Assemble the frozen predictor inputs for one batch.

    The R1 channels take the frozen SceneFlow normalization. The mono and
    disagreement channels are analytically bounded by construction, so they are
    deliberately **not** normalized — no statistic is fitted at any point.
    ``N-shuffle`` arrives here with its mono map already permuted and is handled
    by the ``R2-dis`` branch, so its features are recomputed from the shuffled
    map rather than permuted after the fact.
    """
    r1 = normalize_features_torch(r1_features_gpu(left, right, disparity), constants)
    block = r2_evidence(disparity, mono)
    if variant == "m_only":
        return (block[:, : len(MONO_CHANNELS)],)
    if variant == "r2_concat":
        return (torch.cat([r1, block[:, : len(MONO_CHANNELS)]], dim=1),)
    if variant in ("r2_dis", "n_shuffle"):
        return (torch.cat([r1, block], dim=1),)
    if variant == "n_random":
        # The whole mono5 + disagreement3 block is replaced by fixed random
        # channels of the same shape and dimensionality (V3 14.5).
        random_block = (
            random_control_channels(block.shape[-2:], device=block.device, dtype=block.dtype)
            .unsqueeze(0)
            .expand(block.shape[0], -1, -1, -1)
            .contiguous()
        )
        return (torch.cat([r1, random_block], dim=1),)
    if variant == "r2_gate":
        return (r1, block, block[:, : len(MONO_CHANNELS)])
    raise ValueError(f"unknown variant {variant!r}")


def apply_control(variant: str, mono):
    """``N-shuffle`` permutes the raw mono map *before* any feature is computed."""
    if variant != "n_shuffle":
        return mono
    permutation = shuffle_permutation(mono.shape[0])
    return shuffle_mono_in_batch(mono, permutation)


def _metric_worker(payload):
    risk, error, mask = payload
    entry = {"valid_pixels": int(mask.sum())}
    entry["aurc"] = float(aurc(risk, error, mask))
    entry["ause"] = float(ause(risk, error, mask))
    try:
        entry["bad2_auprc"] = float(bad2_auprc(risk, error, mask))
    except ValueError:
        entry["bad2_auprc"] = float("nan")
    return entry


def evaluate(model, loader, device, variant, constants, workers: int = 32):
    """Full frozen-validation evaluation with the reference metric implementation."""
    model.eval()
    per_sample = []
    with torch.inference_mode(), ProcessPoolExecutor(max_workers=workers) as pool:
        futures = []
        for left, right, disparity, gt, mask, mono in loader:
            left = left.to(device, non_blocking=True)
            right = right.to(device, non_blocking=True)
            disparity = disparity.to(device, non_blocking=True)
            gt = gt.to(device, non_blocking=True)
            mask = mask.to(device, non_blocking=True)
            mono = mono.to(device, non_blocking=True)
            inputs = build_inputs(variant, left, right, disparity, apply_control(variant, mono), constants)
            risk = model(*inputs)
            error = (disparity - gt).abs()
            for b in range(risk.shape[0]):
                m = mask[b, 0].cpu().numpy().astype(bool)
                if m.sum() < 16:
                    continue
                futures.append(
                    pool.submit(
                        _metric_worker,
                        (
                            risk[b, 0].float().cpu().numpy().copy(),
                            error[b, 0].float().cpu().numpy().copy(),
                            m.copy(),
                        ),
                    )
                )
                if len(futures) >= 256:
                    per_sample.extend(f.result() for f in futures)
                    futures = []
        per_sample.extend(f.result() for f in futures)
    model.train()
    summary = {}
    for key in ("aurc", "ause", "bad2_auprc"):
        values = np.array([s[key] for s in per_sample], dtype=np.float64)
        values = values[np.isfinite(values)]
        summary[key] = float(values.mean()) if values.size else float("nan")
        summary[f"{key}_std"] = float(values.std()) if values.size else float("nan")
    summary["samples"] = len(per_sample)
    return summary, per_sample


def provenance(paths, protocol, constants, attempt: int) -> dict:
    cache_root = Path(paths["cache_root"])
    model_config = load_yaml(PROJECT_ROOT / "configs" / "models" / "mvt.yaml")
    return {
        "attempt": attempt,
        "local_commit": subprocess.run(
            ["git", "rev-parse", "HEAD"], cwd=PROJECT_ROOT, capture_output=True, text=True
        ).stdout.strip(),
        "execution_snapshot_sha256": os.environ.get("V3_EXECUTION_SNAPSHOT_SHA256", "unknown"),
        "server_is_git_checkout": False,
        "note": "deployed source snapshot; no server HEAD is claimed",
        "configs": {
            "week4_training_yaml": sha256_file(
                PROJECT_ROOT / "configs/experiments/week4_r2_mono_increment.yaml"
            ),
            "normalization_config": sha256_file(
                PROJECT_ROOT / "configs/normalization_sceneflow_train.json"
            ),
            "normalization_digest": constants.digest(),
            "model_config": sha256_file(PROJECT_ROOT / "configs/models/mvt.yaml"),
        },
        "implementation": {
            "mono_evidence": sha256_file(PROJECT_ROOT / "src/evidence/mono_evidence.py"),
            "negative_controls": sha256_file(PROJECT_ROOT / "src/evidence/negative_controls.py"),
            "risk_predictor": sha256_file(PROJECT_ROOT / "src/models/risk_predictor.py"),
            "r2_data": sha256_file(PROJECT_ROOT / "src/training/r2_data.py"),
            "trainer": sha256_file(PROJECT_ROOT / "scripts/train_r2.py"),
        },
        "caches": {
            "raft_train_index": sha256_file(cache_root / "sceneflow_raft_v1/train/index.jsonl"),
            "raft_val_index": sha256_file(cache_root / "sceneflow_raft_v1/val/index.jsonl"),
            "mono_train_index": sha256_file(cache_root / "sceneflow_mono_v1/train/index.jsonl"),
            "mono_val_index": sha256_file(cache_root / "sceneflow_mono_v1/val/index.jsonl"),
            "mono_cache_schema": MONO_CACHE_SCHEMA,
        },
        "frozen_backbones": {
            "raft_checkpoint": model_config["raft_stereo"]["checkpoint_sha256"],
            "raft_source_tree": model_config["raft_stereo"]["source_sha256"],
            "depth_anything_checkpoint": model_config["depth_anything_v2"]["checkpoint_sha256"],
            "depth_anything_source_tree": model_config["depth_anything_v2"]["source_sha256"],
        },
        "negative_controls": {"n_random_seed": N_RANDOM_SEED, "n_shuffle_seed": N_SHUFFLE_SEED},
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--variant", choices=sorted(VARIANT_MODELS), required=True)
    parser.add_argument("--seed", type=int, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--steps", type=int, default=0)
    parser.add_argument("--attempt", type=int, default=1)
    parser.add_argument("--smoke", action="store_true")
    args = parser.parse_args()

    protocol = load_yaml(PROJECT_ROOT / "configs" / "experiments" / "week4_r2_mono_increment.yaml")
    paths = load_paths()
    constants_path = PROJECT_ROOT / "configs" / "normalization_sceneflow_train.json"
    constants = NormalizationConstants.load(constants_path)
    if constants.digest() != FROZEN_NORMALIZATION_DIGEST:
        raise RuntimeError(
            f"Normalization digest changed: {constants.digest()} != {FROZEN_NORMALIZATION_DIGEST}; STOP"
        )

    variant_name, builder = VARIANT_MODELS[args.variant]
    seed = args.seed
    torch.manual_seed(seed)
    np.random.seed(seed)
    device = torch.device("cuda")

    opt_cfg = protocol["optimizer"]
    sch_cfg = protocol["schedule"]
    max_steps = args.steps or int(sch_cfg["max_steps"])
    warmup = int(sch_cfg["warmup_steps"])
    base_lr = float(opt_cfg["lr"])
    final_lr = float(sch_cfg["final_lr"])
    weight_decay = float(opt_cfg["weight_decay"])
    effective_batch = int(sch_cfg["effective_batch_size"])
    val_every = int(protocol["validation"]["every_steps"])
    single_hidden = int(protocol["variants"]["M-only"]["hidden"])
    hidden_channels = int(protocol["variants"]["R2-gate"]["hidden"])
    gate_channels = int(protocol["variants"]["R2-gate"]["gate_channels"])
    physical_batch = min(effective_batch, 2 if args.smoke else effective_batch)
    accumulate = max(1, effective_batch // physical_batch)

    out = args.out
    out.mkdir(parents=True, exist_ok=True)
    provenance_record = provenance(paths, protocol, constants, args.attempt)
    (out / "provenance.json").write_text(json.dumps(provenance_record, indent=2) + "\n", encoding="utf-8")

    cache_root = Path(paths["cache_root"])
    train_ds = SceneFlowR2Dataset(
        paths["sceneflow"], cache_root / "sceneflow_raft_v1/train", cache_root / "sceneflow_mono_v1/train", "train"
    )
    val_ds = SceneFlowR2Dataset(
        paths["sceneflow"], cache_root / "sceneflow_raft_v1/val", cache_root / "sceneflow_mono_v1/val", "validation"
    )

    from torch.utils.data import DataLoader

    train_loader = DataLoader(
        train_ds, batch_size=physical_batch, shuffle=True, num_workers=12,
        collate_fn=collate_r2, pin_memory=True, drop_last=True, persistent_workers=True,
    )
    val_loader = DataLoader(
        val_ds, batch_size=8, shuffle=False, num_workers=12,
        collate_fn=collate_r2, pin_memory=True, persistent_workers=True,
    )

    if args.variant == "r2_gate":
        model = builder(hidden_channels, gate_channels)
    else:
        model = builder(single_hidden)
    model = model.to(device).train()
    parameters = model.parameter_count()
    if parameters != EXPECTED_PARAMETERS[args.variant]:
        raise RuntimeError(
            f"parameter count {parameters} != frozen {EXPECTED_PARAMETERS[args.variant]} for {args.variant}"
        )

    run_meta = {
        "phase": "week4_r2_source_training",
        "variant": args.variant,
        "variant_name": variant_name,
        "seed": seed,
        "attempt": args.attempt,
        "smoke": bool(args.smoke),
        "max_steps": max_steps,
        "warmup_steps": warmup,
        "base_lr": base_lr,
        "final_lr": final_lr,
        "weight_decay": weight_decay,
        "effective_batch": effective_batch,
        "physical_batch": physical_batch,
        "gradient_accumulation": accumulate,
        "loss": protocol["supervision"]["loss"],
        "training_target": protocol["supervision"]["training_target"],
        "output": protocol["model"]["output"],
        "bad2_auxiliary": protocol["supervision"]["bad2_auxiliary"],
        "ranking_auxiliary": protocol["supervision"]["ranking_auxiliary"],
        "augmentation": protocol["augmentation"]["enabled"],
        "early_stopping": protocol["early_stopping"]["enabled"],
        "val_every": val_every,
        "parameters": parameters,
        "input_channels": list(model.input_channels) if isinstance(model.input_channels, tuple) else model.input_channels,
        "train_samples": len(train_ds),
        "val_samples": len(val_ds),
        "started_utc": datetime.now(timezone.utc).isoformat(),
        "python": platform.python_version(),
        "torch": torch.__version__,
        "cuda": torch.version.cuda,
        "gpu": torch.cuda.get_device_name(0) if torch.cuda.is_available() else "cpu",
        "resume_policy": "failed runs restart from scratch under a new attempt; no partial state is reused",
        "provenance": "provenance.json",
    }
    (out / "run_metadata.json").write_text(json.dumps(run_meta, indent=2) + "\n", encoding="utf-8")
    log(
        f"{args.variant} seed={seed} attempt={args.attempt} steps={max_steps} "
        f"params={parameters} train={len(train_ds)} val={len(val_ds)}"
    )

    optimizer = torch.optim.AdamW(model.parameters(), lr=base_lr, weight_decay=weight_decay)
    train_curve, val_records, selection = [], [], []
    best = None
    peak_vram = 0
    started = time.time()
    step = 0
    optimizer.zero_grad(set_to_none=True)

    try:
        while step < max_steps:
            for left, right, disparity, gt, mask, mono in train_loader:
                lr = lr_at_step(step, max_steps, warmup, base_lr, final_lr)
                for group in optimizer.param_groups:
                    group["lr"] = lr
                left = left.to(device, non_blocking=True)
                right = right.to(device, non_blocking=True)
                disparity = disparity.to(device, non_blocking=True)
                gt = gt.to(device, non_blocking=True)
                mask = mask.to(device, non_blocking=True)
                mono = mono.to(device, non_blocking=True)

                with torch.no_grad():
                    inputs = build_inputs(
                        args.variant, left, right, disparity, apply_control(args.variant, mono), constants
                    )
                risk = model(*inputs)
                loss = masked_log_error_smooth_l1(risk, disparity, gt, mask)

                if not torch.isfinite(loss):
                    raise RuntimeError(f"Non-finite loss at step {step}: {loss.item()}")
                if not torch.isfinite(risk).all():
                    raise RuntimeError(f"Non-finite risk at step {step}")
                (loss / accumulate).backward()
                if (step + 1) % accumulate == 0:
                    grads = [p.grad for p in model.parameters() if p.grad is not None]
                    if not all(torch.isfinite(g).all() for g in grads):
                        raise RuntimeError(f"Non-finite gradient at step {step}")
                    optimizer.step()
                    optimizer.zero_grad(set_to_none=True)

                peak_vram = max(peak_vram, int(torch.cuda.max_memory_allocated()))
                if step % 50 == 0:
                    train_curve.append({"step": step, "loss": float(loss.item()), "lr": lr})
                step += 1

                if step % val_every == 0 or step == max_steps:
                    metrics, per_sample = evaluate(model, val_loader, device, args.variant, constants)
                    val_records.append({"step": step, **metrics})
                    (out / "val_per_sample_latest.json").write_text(
                        json.dumps(per_sample) + "\n", encoding="utf-8"
                    )
                    log(
                        f"step {step}: AURC {metrics['aurc']:.4f} AUSE {metrics['ause']:.4f} "
                        f"Bad2AUPRC {metrics['bad2_auprc']:.4f}"
                    )
                    candidate = {
                        "step": step,
                        "aurc": metrics["aurc"],
                        "ause": metrics["ause"],
                        "bad2_auprc": metrics["bad2_auprc"],
                    }
                    if better(candidate, best):
                        best = candidate
                        torch.save(
                            {"model": model.state_dict(), "step": step, "metrics": candidate,
                             "variant": args.variant, "seed": seed},
                            out / "best.pt",
                        )
                        selection.append({"selected": "best", **candidate})
                        log(f"  new best at step {step}")
                    torch.save(
                        {"model": model.state_dict(), "step": step, "variant": args.variant, "seed": seed},
                        out / "last.pt",
                    )
                    (out / "train_curve.json").write_text(json.dumps(train_curve), encoding="utf-8")
                    (out / "val_records.json").write_text(json.dumps(val_records, indent=2), encoding="utf-8")
                    (out / "selection.json").write_text(json.dumps(selection, indent=2), encoding="utf-8")
                    if device.type == "cuda":
                        torch.cuda.reset_peak_memory_stats()
                if step >= max_steps:
                    break
    except Exception as exc:  # noqa: BLE001 - recorded, run marked failed
        (out / "FAILED.json").write_text(
            json.dumps(
                {"error": f"{type(exc).__name__}: {exc}", "step": step, "attempt": args.attempt,
                 "traceback": traceback.format_exc()},
                indent=2,
            ) + "\n",
            encoding="utf-8",
        )
        log(f"RUN FAILED at step {step}: {type(exc).__name__}: {exc}")
        raise

    summary = {
        "phase": "week4_r2_source_training",
        "variant": args.variant,
        "seed": seed,
        "attempt": args.attempt,
        "smoke": bool(args.smoke),
        "steps": step,
        "wall_seconds": time.time() - started,
        "peak_vram_bytes": peak_vram,
        "best": best,
        "final_val": val_records[-1] if val_records else None,
        "finished_utc": datetime.now(timezone.utc).isoformat(),
        "status": "SMOKE_ONLY" if args.smoke else "COMPLETE",
    }
    (out / "run_summary.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
    log("SUMMARY " + json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
