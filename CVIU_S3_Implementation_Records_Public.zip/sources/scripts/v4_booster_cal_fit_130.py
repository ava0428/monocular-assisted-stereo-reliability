"""Fit CAL-only C1_d from a complete, identity-checked 129 score run."""

import hashlib
import json
from dataclasses import asdict
from pathlib import Path

import numpy as np

from scripts.v4_booster_cal_scores_129 import ROOT, FRAME_SHA, BINDING_SHA, MODEL_CONFIG_SHA, checked_inputs, execution_identity
from src.taskspace.booster_calibration import frame_quotas, sampled_operands, fit_sampled_c1d


def fit_cal_run(run_directory, output):
    manifest, _ = checked_inputs()
    run = Path(run_directory).resolve()
    output = Path(output).resolve()
    if not run.is_relative_to(ROOT / "outputs") or not output.is_relative_to(ROOT / "outputs"):
        raise ValueError("CAL run and fit output must stay under workspace outputs")
    if output.exists():
        raise FileExistsError(output)
    terminal_bytes = (run / "terminal.json").read_bytes()
    terminal = json.loads(terminal_bytes)
    if (terminal["status"] != "COMPLETE" or terminal["exitcode"] != 0
            or terminal["frame_manifest_sha256"] != FRAME_SHA
            or terminal["weight_binding_sha256"] != BINDING_SHA
            or terminal.get("execution_sha256") != execution_identity()
            or terminal.get("model_config_sha256") != MODEL_CONFIG_SHA):
        raise ValueError("complete bound CAL run required")
    log_bytes = (run / "frames/frames.jsonl").read_bytes()
    records = [json.loads(line) for line in log_bytes.splitlines()]
    expected = {(s["scene"], f["frame"]) for s in manifest["scenes"] for f in s["frames"]}
    by_frame = {(r["scene"], r["frame"]): r for r in records}
    if len(records) != len(expected) or set(by_frame) != expected:
        raise ValueError("CAL frame receipts incomplete or duplicated")
    seeds = (20260910, 20260911, 20260912)
    samples = {seed: [] for seed in seeds}
    provenance = []
    for scene in manifest["scenes"]:
        gt_entry = scene["shared"]["disp_00.npy"]
        gt_path = (ROOT / gt_entry["path"]).resolve()
        if not gt_path.is_relative_to(ROOT / "outputs/v4_booster_cal_range_116" / scene["scene"]):
            raise ValueError("GT outside bound CAL scene")
        if hashlib.sha256(gt_path.read_bytes()).hexdigest() != gt_entry["sha256"]:
            raise ValueError("CAL GT hash mismatch")
        gt = np.load(gt_path, mmap_mode="r", allow_pickle=False)
        quotas = frame_quotas([f["frame"] for f in scene["frames"]])
        for frame in scene["frames"]:
            record = by_frame[(scene["scene"], frame["frame"])]
            path = Path(record["path"]).resolve()
            if not path.is_relative_to(run / "frames") or record["weight_binding_sha256"] != BINDING_SHA:
                raise ValueError("score path or binding mismatch")
            payload = path.read_bytes()
            if len(payload) != record["bytes"] or hashlib.sha256(payload).hexdigest() != record["sha256"]:
                raise ValueError("score bytes mismatch")
            with np.load(path, allow_pickle=False) as maps:
                if maps["stereo_disparity"].shape != (752, 1028) or gt.shape != (3008, 4112):
                    raise ValueError("frozen CAL grids mismatch")
                for seed in seeds:
                    values = sampled_operands(gt, maps["stereo_disparity"], maps[f"r2_gate_seed{seed}"], quotas[frame["frame"]])
                    samples[seed].append(values)
            provenance.append({"scene": scene["scene"], "frame": frame["frame"],
                               "indices": values[2].tolist(), "score_sha256": record["sha256"],
                               "gt_sha256": gt_entry["sha256"]})
    fits = {str(seed): asdict(fit_sampled_c1d(samples[seed])) for seed in seeds}
    result = {"status": "CAL_ONLY_FITS", "fits": fits, "samples": provenance,
              "frame_manifest_sha256": FRAME_SHA, "weight_binding_sha256": BINDING_SHA,
              "execution_sha256": terminal["execution_sha256"],
              "terminal_sha256": hashlib.sha256(terminal_bytes).hexdigest(),
              "frame_log_sha256": hashlib.sha256(log_bytes).hexdigest(),
              "policy": "draft130; 8192 per scene; transform radius before resize; tau=.90"}
    with output.open("x", encoding="utf-8") as stream:
        json.dump(result, stream, indent=2)
    return result
