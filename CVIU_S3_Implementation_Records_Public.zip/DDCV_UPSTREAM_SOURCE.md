# Referenced upstream DDCV source (not redistributed)

The public derivative omits `sources/upstream_ddcv/loss_fuction.py` because a redistribution
license covering that upstream file was not found. All original source identity
records remain unchanged; absence here is deliberate, not a claim that the
historical execution omitted this inspection source.

- Repository: https://github.com/CwLiuzzZ/Un-ViTAStereo
- Commit: ddf2f57f5ec518a0a167c5da3fc5dfab90211dac
- File: toolkit/function/depth_function/loss_fuction.py
- Fixed URL: https://github.com/CwLiuzzZ/Un-ViTAStereo/blob/ddf2f57f5ec518a0a167c5da3fc5dfab90211dac/toolkit/function/depth_function/loss_fuction.py
- Historical SHA-256: `bdc5470913400fddb59d26b6c5104dfe573352ea24a39af019941745d2861117`

The public copy of verify_review.py checks every retained source hash and reports
this exact excluded file separately. Its statistical checks are unchanged. The
project comparator implementations and recorded convention report remain supplied.
