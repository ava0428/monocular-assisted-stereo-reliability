"""Reconstructed 2026-10-11 CPU verifier, NOT a historical execution entry.

Checks saved scene reductions, paired bootstrap, split identities, and an explicit
synthetic contract example. Never loads a checkpoint, image dataset or network.
"""
from pathlib import Path
import ast,csv,hashlib,importlib.util,json,math,sys,unicodedata
import numpy as np

ROOT=Path(__file__).resolve().parent
def rows(n):return list(csv.DictReader((ROOT/n).open(encoding='utf-8')))
def load(n):return json.loads((ROOT/n).read_text(encoding='utf-8'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
# PUBLIC RELEASE COPY: one unlicensed upstream inspection source is omitted.
# Historical source_identity.json is unchanged; statistical checks are unchanged.
excluded_public_sources=[]
for rec in load('source_identity.json'):
    if rec['path']=='upstream_ddcv/loss_fuction.py':
        assert rec['sha256']=='bdc5470913400fddb59d26b6c5104dfe573352ea24a39af019941745d2861117'
        assert not (ROOT/'sources'/rec['path']).exists()
        excluded_public_sources.append({'path':rec['path'],'sha256':rec['sha256'],'reason':'upstream redistribution licence not found; see DDCV_UPSTREAM_SOURCE.md'})
        continue
    assert sha(ROOT/'sources'/rec['path'])==rec['sha256']
frames=rows('split_frames.csv');scenes=rows('split_scenes.csv')
for s in scenes:
    key=unicodedata.normalize('NFC',s['scene']).lower()
    assert key==s['physical_scene_id']
    assert hashlib.sha256(('V4-BOOSTER-2022-SCENE-v1\n'+key).encode()).hexdigest()==s['group_sha256']
for i,s in enumerate(sorted(scenes,key=lambda z:(z['group_sha256'],z['physical_scene_id']))):
    assert s['role']==('CAL' if i<19 else 'EVAL')
cal=load('sources/manifests/v4_booster_cal_frames_125.json')['scenes']
eva=load('sources/outputs/v4_booster_eval_run_145/inputs.json')
bound={}
for role,groups in [('CAL',cal),('EVAL',eva)]:
    for s in groups:
        gt=s['shared']['disp_00.npy'] if role=='CAL' else s['gt']
        for f in s['frames']:
            bound[role,s['scene'],f['frame']]=(f,gt)
assert len(bound)==len(frames)
for row in frames:
    f,gt=bound[row['role'],row['scene'],row['frame_id']]
    assert row['left_sha256']==f['left']['sha256'] and row['right_sha256']==f['right']['sha256']
    assert row['gt_sha256']==gt['sha256']
for role,n,ns in [('CAL',120,19),('EVAL',108,19)]:
    fs=[x for x in frames if x['role']==role]
    assert len(fs)==len({x['pair_id'] for x in fs})==n
    assert len({x['physical_scene_id'] for x in fs})==ns
    assert sum(int(s['frames']) for s in scenes if s['role']==role)==n
assert not {x['physical_scene_id'] for x in frames if x['role']=='CAL'} & {x['physical_scene_id'] for x in frames if x['role']=='EVAL'}
for field in ['left_sha256','right_sha256','gt_sha256']:
    assert not {x[field] for x in frames if x['role']=='CAL'} & {x[field] for x in frames if x['role']=='EVAL'}

source=ROOT/'sources/scripts/analyze_jise_exact_unified_v1.py'
sp=importlib.util.spec_from_file_location('preserved_analysis',source)
mod=importlib.util.module_from_spec(sp);sp.loader.exec_module(mod)
x=rows('data/scene_metrics_19x45.csv');ss=sorted({z['scene'] for z in x});lut={(z['scene'],z['method']):z for z in x}
seed=(20260910,20260911,20260912);idx=np.random.default_rng(20260913).integers(0,19,size=(10000,19))
for saved in load('coverage90.json'):
    f=saved['family']
    vals=np.array([[float(lut[s,f'Rel-Analytic:{f}:{i}']['absrel_90']) for s in ss] for i in seed])
    ref=np.array([[float(lut[s,f'Rel-Analytic:r1:{i}']['absrel_90']) for s in ss] for i in seed])
    actual={'mean':float(vals.mean(axis=1).mean()),'sample_sd':float(vals.mean(axis=1).std(ddof=1)),**mod.paired_bootstrap(vals-ref,idx)}
    for k,v in actual.items():assert math.isclose(v,saved[k],rel_tol=5e-13,abs_tol=1e-14),(f,k)
    assert math.isclose(saved['relative_reduction_percent'],100*(ref.mean()-vals.mean())/ref.mean(),abs_tol=1e-12)

# Execute only the preserved arithmetic function, not its inference/file driver.
ev=ROOT/'sources/scripts/jise_exact_unified_eval_v1.py'
tree=ast.parse(ev.read_text(encoding='utf-8'));node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='exact_metrics')
ns={'np':np,'math':math,'BOUNDS':(0.,.2,.4,.6,.8,.9,1.)}
exec(compile(ast.Module(body=[node],type_ignores=[]),str(ev),'exec'),ns)
fixture=load('synthetic_contract_example.json');loss=np.array(fixture['absrel_loss']);risk=np.array([np.inf if v=='+inf' else v for v in fixture['risk']])
out,_=ns['exact_metrics'](risk,{'absrel':loss},2)
assert np.isclose(out['absrel_80'],.25) and np.isclose(out['absrel_90'],.25)
assert np.isclose(out['absrel_aurc'],17/60) and out['aurc_status']=='OK'
bad=risk.copy();bad[-1]=np.nan
out_bad,_=ns['exact_metrics'](bad,{'absrel':loss},2)
assert out_bad['status_80']=='OK' and out_bad['status_90']=='NONORDERABLE_SCORE' and out_bad['absrel_aurc'] is None
try:ns['exact_metrics'](risk,{'absrel':np.array([0,.5,np.nan,0,.25])},2)
except ValueError:pass
else:raise AssertionError('nonfinite common loss must reject')
cal=fixture['calibration'];errors=np.asarray(cal['errors']);h=np.asarray(cal['base_radii']);k=math.ceil((len(h)+1)*cal['tau']);delta=float(np.sort(errors-h)[k-1])
assert k==cal['expected_rank'] and delta==cal['expected_delta']
assert math.ceil((19*8192+1)*.90)==140085
result={'status':'PASS_RECONSTRUCTED_CPU_REVIEW','scene_rows':len(x),'split_frames':len(frames),'coverage90_saved_summary_bootstrap_agreement':True,'synthetic_example':'PASS; artificial arithmetic operands, not an empirical result','historical_pixel_evaluation_repeated':False,'CAL_refitted_on_original_operands':False,'models_loaded':False,'script_sha256':sha(Path(__file__))}
result['public_source_exclusions']=excluded_public_sources
result['all_retained_source_hashes_verified']=True
(ROOT/'verification_result.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result))
