# Public release derivative

This archive is a separately identified public derivative. Historical
research records and original archive remain unchanged locally. Public
licensing notices supersede pre-release wording about pending external
delivery or author licensing decisions in preserved historical READMEs.

Run `python reproduce.py summary` to replay saved-result paired changes
and display tables; this does not refit CAL or run models.
`python reproduce.py cal-bootstrap` explicitly refits CAL on the six
sampled operand files; it does not propagate refits to EVAL rankings.
Both require Python and NumPy. Use a disposable extraction because
derived outputs are overwritten. See BOOSTER_CAL_OPERANDS_NOTICE.md.
