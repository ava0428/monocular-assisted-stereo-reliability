# Materials access and executable scope — CVIU round 5

These are prepared local review materials. No public deposit, journal upload or redistribution licence is claimed.

## Included risk-head weights

`CVIU_risk_head_weights.zip` contains the original 18 source-selected checkpoints for four central families (Stereo-Err, Stereo+Mono, Stereo+Mono+Disag, Base-Risk) and two content-control families (Random Mono, Shuffled Mono), each with three fixed runs, total 1,447,128 weight bytes. `checkpoint_manifest.json` identifies each family, original run and display seed, selected step, SHA-256 and archive member. The prior packaging checked checkpoint metadata on CPU; this round independently rechecked archive member hashes/sizes and their source-selected family/run/step mappings without constructing a model or running forward inference. The corresponding model, normalization and feature sources are preserved in S3 and the editable source. The standalone weights use the original `model` state-dict envelope; do not reinterpret them as backbone weights or select a new checkpoint. Actual external release/licensing remains an author decision.

## Separately supplied Rel-Direct weights

`CVIU_rel_direct_weights.zip` adds the three existing source-selected Rel-Direct checkpoints (`grel_direct`), with seed0/seed1/seed2 mapped to20260910/20260911/20260912 and selected steps8000/2000/8000. Checkpoint bytes total819966. Each file's size and SHA-256 match `manifests/week6_grel_direct_checkpoints.json`; the catalog and its original provenance qualifications are included. This separate archive does not change the original18 archive or S1–S4.

The available restricted weights_only loader cannot decode a legacy NumPy pickle global. No unsafe fallback or model forward was run; identity verification used exact registered file hashes, source-catalog family/seed/step and binding seeds. The new archive includes saved project model/loader source copies under `code/` for inspection. Compatible serialization dependencies and the project imports of `src/training/grel_checkpoint.py` are still needed for actual loading; these code copies are not a standalone runtime. Packaging does not imply full historical dependency reconstruction. No new weight selection, training, evaluation or external upload occurred.

## Pretrained inputs and dataset

The retained RAFT-Stereo checkpoint is `raftstereo-sceneflow.pth`, SHA-256 `ba75bdcb379b4c3942d1e714565d0e66e6b2450a3da8129f54073302d67e0a6d`. The preserved upstream README/download script directs users to https://www.dropbox.com/s/ftveifyqcomiwaq/models.zip . It is the SceneFlow model, not the RVC model; verify the individual file hash. The retained upstream code identity and inference settings are in S3's `configs/models/mvt.yaml` and the manuscript preprocessing table.

Depth Anything V2-Small uses `depth_anything_v2_vits.pth`, SHA-256 `715fade13be8f229f8a70cc02066f656f2423a59effd0579197bbf57860e1378`. The preserved official README specifies https://huggingface.co/depth-anything/Depth-Anything-V2-Small/resolve/main/depth_anything_v2_vits.pth?download=true and https://github.com/DepthAnything/Depth-Anything-V2 . These are source instructions found in retained upstream files; live download availability was not retested in this revision. Backbone weights are not redistributed in the risk-head archive.

Booster source: https://amsacta.unibo.it/id/eprint/6876/1/booster_gt.zip ; official archive README: https://amsacta.unibo.it/id/eprint/6876/2/README_Booster.rtf . Use the recorded TRAIN/balanced camera00/02 members, not official held-out test or a newly chosen cohort. `CVIU_review_support.zip` contains `split_frames.csv`, `split_scenes.csv`, `split_contract.json` and member hashes for 19 CAL groups/120 frames and 19 EVAL groups/108 frames. The archive's complete historical SHA was not computed. Its retained README reports CC BY-NC 4.0; users must check the actual applicable terms before redistribution. No new data were downloaded here.

## What runs from the light package

- S1: extract `JISE_light_offline_review_20261006.zip`, run `python reproduce.py --out <new-directory> --plots`. This recomputes original scene summaries/bootstrap, exact segment sums and display data, not native arrays.
- S3: extract `CVIU_review_support.zip`, run `python verify_review.py`. Saved empirical @0.90 checks and labelled synthetic arithmetic checks are distinct.
- S4: extract `CVIU_round2_validation.zip`, run `python summarize_regenerated.py` and `python write_validation_tables.py`. Uses already evaluated additional frame results, with no CAL refit or model forward.
- Round-3 support: extract `CVIU_round3_support.zip`, run `python analysis_round3/compare_evaluations.py` from its root. Requires Python/NumPy. It matches frame IDs, checkpoint/run, path, tau and metric, recomputes fixed-run/scene statistics and writes the main path table and SI consistency table. Included minimal original/additional inputs keep this entry independent of project absolute paths.
- Editable source: `./compile_cviu.ps1`; the build resolves cross-document labels and compiles both PDFs. `analysis_revision/` retains the figure generators and actual display arrays. Table numbers in old immutable S4 TeX files describe the old document; current display files are in `analysis_round3/`.

## Repeating the prior full additional re-evaluation

This was executed in round 2; it was NOT repeated in round 3. The recorded scripts are `analysis_round2/recover_all_scores.py`, `fit_regenerated_cal.py`, `evaluate_regenerated.py --stage core`, `evaluate_regenerated.py --stage extras --workers 2`, and `summarize_regenerated.py`. They locate an existing project root by `src/models/risk_predictor.py`, use project-relative input paths and derive their output directory relative to their source location. They are preserved execution entries, not a path-independent installed application. Work from a separate reconstruction workspace, never rerun them over an immutable review archive.

Required existing project inputs:
1. `outputs/jise_mono_ablation_booster_inputs_20261005/manifest.json` and each referenced EVAL NPZ; `outputs/jise_mono_ablation_booster_cal_inputs_20261005/manifest.json` and each CAL NPZ. These contain scoring-grid RGB, stereo disparity and mono maps; donor mappings and image SHA identities must match. The scoring grid is1028x752.
2. EVAL native GT/geometry records from `outputs/jise_mono_ablation_booster_eval_operands_20261005/manifest.json`; CAL GT from `outputs/v4_booster_cal_range_116/<scene>/disp_00.npy`, with `manifests/v4_booster_cal_frames_125.json`. The native grid is4112x3008; preserve units and common valid domain.
3. The 18 checkpoints at manifest-mapped locations, `configs/normalization_sceneflow_train.json`, preserved feature/model/calibration code and matching adapters. S4's `execution_sources/`, `execution_source_identity.json`, `checkpoint_identity.json` and runtime records document the executed version. The weights archive supplies the small self-trained files; its manifest maps them back to project paths.
4. The archived original fit file is read only for explicitly labelled old/new diagnostics. Each newly evaluated score uses its own newly fitted offset within the additional execution; do not combine it with an old fit to replace primary results.

The saved execution used PyTorch2.0.1+cu118/NumPy1.24.4/OpenCV4.12.0. Summary checks need NumPy, not CUDA. Large cached inputs, GT, ~12.7GB additional raw scores, and native/full-curve arrays are not bundled here. Their current local location and input-manifest hashes are in `analysis_round3/local_asset_inventory.json`; an external delivery channel for these assets still needs author arrangement. Providing risk heads does not resolve every historical loader/dependency gap or make full native reproduction self-contained.


## Round5 executable additions

See REPRODUCTION_LEVELS.md and the unified reproduce.py entry. CVIU_round5_analysis.zip adds direct paired-change statistics and six sampled CAL operand files for an actually executed directory-group refit/OOB diagnostic. This is separate from S1–S4 and does not rerun models or propagate CAL variability into EVAL risk. Input preparation has a verified single-frame array-identity check; full public-data backbone generation remains an externally dependent, unvalidated clean-host stage.
