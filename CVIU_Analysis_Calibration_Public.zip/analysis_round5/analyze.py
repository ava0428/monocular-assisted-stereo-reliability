"""Paired change-in-contrast and CAL group refit diagnostics. CPU; no network/model."""
from pathlib import Path
import json,csv,hashlib,math,time
import numpy as np
H=Path(__file__).resolve().parent;A=H.parent
def load(p):return json.loads(p.read_text(encoding='utf-8'))
def rows(p):return list(csv.DictReader(p.open(encoding='utf-8')))
def out(n,x):(H/n).write_text(json.dumps(x,indent=2)+'\n')
def csvout(n,rs):
 with (H/n).open('w',newline='',encoding='utf-8') as f:w=csv.DictWriter(f,fieldnames=list(rs[0]));w.writeheader();w.writerows(rs)
p=load(H/'protocol.json');runs=p['CAL_cluster_refit']['seeds'];families=p['CAL_cluster_refit']['families']
old={(r['scene'],r['method']):r for r in rows(A/'results/canonical_summary/scene_metrics_19x45.csv')}
new={(r['scene'],r['family'],int(r['seed']),r['rule'],r['tau']):r for r in rows(A/'analysis_round2/regenerated_scene_metrics.csv')}
scenes=sorted({k[0] for k in old});assert len(scenes)==19
ix=np.random.default_rng(p['EVAL_bootstrap']['rng_seed']).integers(0,19,(p['EVAL_bootstrap']['draws'],19))
contrasts=[];scene_out=[]
for spec in p['contrasts']:
 for metric in p['metrics']:
  arr=[]
  for rule in [spec['before'],spec['after']]:
   pair=[]
   for seed in runs:
    if spec['execution']=='original':d=[float(old[s,f'{rule}:r2_gate:{seed}'][metric])-float(old[s,f'{rule}:r1:{seed}'][metric]) for s in scenes]
    else:
     rr='qd/a' if rule.startswith('qd/a') else rule;tau='0.9' if rr=='qd/a' else ''
     d=[float(new[s,'r2_gate',seed,rr,tau][metric])-float(new[s,'r1',seed,rr,tau][metric]) for s in scenes]
    pair.append(d)
   arr.append(np.asarray(pair))
  before,after=arr;v=(after-before).mean(axis=0);reps=v[ix].mean(axis=1);ci=np.quantile(reps,[.025,.975])
  contrasts.append({**spec,'metric':metric,'before_mean_delta':float(before.mean()),'after_mean_delta':float(after.mean()),'change_in_delta':float(v.mean()),'ci_low':float(ci[0]),'ci_high':float(ci[1]),'positive_scene_changes':int((v>0).sum()),'total_scenes':19,'CAL_fixed':True})
  for i,s in enumerate(scenes):scene_out.append({'execution':spec['execution'],'metric':metric,'scene':s,'before_delta':float(before[:,i].mean()),'after_delta':float(after[:,i].mean()),'paired_change':float(v[i])})
out('paired_change.json',contrasts);csvout('paired_change_scenes.csv',scene_out)
import sys,subprocess
if "--paired-only" in sys.argv:
 subprocess.run([sys.executable,str(H/"render_tables.py")],check=True)
 raise SystemExit(0)
# Whole-directory group bootstrap: repeated groups give integer weights on fixed pixels.
t=time.perf_counter();fits=load(A/'analysis_round2/cal_refit.json')['rows'];bootcfg=p['CAL_cluster_refit'];B=bootcfg['draws']; draws=np.random.default_rng(bootcfg['rng_seed']).integers(0,19,(B,19));mult=np.asarray([np.bincount(x,minlength=19) for x in draws],dtype=np.int16)
raw=[];summary=[];inputs=[];deltas={};identity=[]
for fam in families:
 for seed in runs:
  f=H/'cal_operands'/f'{fam}_{seed}.npz'
  with np.load(f,allow_pickle=False) as z:e=z['error'];h=z['h0'];grp=z['scene']
  gs=sorted(set(grp.tolist()));assert len(gs)==19 and len(e)==155648 and np.isfinite(e).all() and np.isfinite(h).all() and np.all(e>=0) and np.all(h>=0)
  gid=np.searchsorted(gs,grp);assert np.all(np.bincount(gid)==8192);res=e-h;order=np.argsort(res,kind='stable');sorted_res=res[order];sorted_gid=gid[order];k=math.ceil((len(e)+1)*.9)
  saved=next(x for x in fits if x['family']==fam and x['seed']==seed and x['tau']==.9);base=float(sorted_res[k-1]);assert gs==sorted(saved['scene_sample_coverage']);assert abs(base-saved['delta'])<1e-12
  inputs.append({'family':fam,'seed':seed,'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'n':len(e),'groups':gs,'refit_tau90_matches_saved_delta':True,'delta':base})
  ds=np.empty(B)
  for start in range(0,B,32):
   w=mult[start:start+32,sorted_gid];cum=np.cumsum(w,axis=1,dtype=np.int32);pos=np.argmax(cum>=k,axis=1);ds[start:start+len(pos)]=sorted_res[pos]
  # Direct materialization on three fixed draws verifies weighted-order-statistic implementation.
  for j in [0,1,2]:
   material=np.concatenate([res[gid==g] for g in draws[j]]);direct=float(np.partition(material,k-1)[k-1]);assert direct==ds[j]
  # Coverage with radius max(h0+delta,0): zero error is always covered, even if offset<0.
  cover=np.empty((B,19));original_group=[]
  for g in range(19):
   mask=gid==g;positive=mask&(e>0);zeros=int(np.sum(mask&(e==0)));sorted_positive=np.sort(res[positive]);cover[:,g]=(zeros+np.searchsorted(sorted_positive,ds,side='right'))/8192
   original_group.append(float(np.mean(e[mask]<=np.maximum(h[mask]+base,0))))
  oob=mult==0;den=oob.sum(axis=1);oobval=np.divide((cover*oob).sum(axis=1),den,out=np.full(B,np.nan),where=den>0)
  fitted=(cover*mult).sum(axis=1)/19
  for j in range(B):raw.append({'family':fam,'seed':seed,'replicate':j,'delta':float(ds[j]),'fitted_sample_coverage':float(fitted[j]),'out_of_bag_groups':int(den[j]),'out_of_bag_sampled_group_coverage':None if den[j]==0 else float(oobval[j])})
  finite=oobval[np.isfinite(oobval)];dq=np.quantile(ds,[.025,.5,.975]);oq=np.quantile(finite,[.025,.5,.975])
  summary.append({'family':fam,'seed':seed,'baseline_additional_delta':base,'delta_p025':float(dq[0]),'delta_median':float(dq[1]),'delta_p975':float(dq[2]),'oob_coverage_p025':float(oq[0]),'oob_coverage_median':float(oq[1]),'oob_coverage_p975':float(oq[2]),'no_oob_replicates':int((den==0).sum()),'original_fitted_group_coverage':dict(zip(gs,original_group))})
  deltas[fam,seed]=ds
  print(fam,seed,'finished',round(time.perf_counter()-t,1),'s',flush=True)
paired_delta=np.mean([deltas['r2_gate',seed]-deltas['r1',seed] for seed in runs],axis=0)
out('cal_cluster_summary.json',{'classification':'new post-hoc CAL group refit stability and out-of-bag sampled-group coverage; not external validation','protocol_sha256':hashlib.sha256((H/'protocol.json').read_bytes()).hexdigest(),'bootstrap_draws':B,'shared_draws':draws.tolist(),'summaries':summary,'paired_Base_minus_Stereo_delta_quantiles':np.quantile(paired_delta,[.025,.5,.975]).tolist(),'runtime_seconds':time.perf_counter()-t,'numpy':np.__version__,'direct_materialization_checks':18,'EVAL_recomputed':False,'inputs':inputs,'risk_interval_includes_CAL_refit':False})
csvout('cal_cluster_replicates.csv',raw)
import subprocess,sys
subprocess.run([sys.executable,str(H/"render_tables.py")],check=True)
