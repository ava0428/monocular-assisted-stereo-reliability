# Reproduction levels and unified entry — round5

Run commands from the extracted editable source or round5 analysis root. The unified entry is `python reproduce.py <mode>`. No model, CAL refit or pixel evaluation is started implicitly.

|Level|Entry / inputs|Actual check this revision|What it does not establish|
|---|---|---|---|
|Saved-result paired changes|`summary`: existing original scene/config matrix, additional scene matrix and saved CAL diagnostic|Executed; new paired change intervals and display tables reproduced in a clean extracted directory|No model forward, native sorting or CAL refit in this mode|
|CAL-group refit diagnostic|`cal-bootstrap`: six supplied CAL sampled-operand NPZs, fixed protocol|Executed2,000 common directory-group draws x6fits;18 explicitly materialized cross-checks|Not an independent cohort; EVAL risks are not recomputed; no joint CAL+EVAL uncertainty interval|
|Prepare risk-head inputs|`prepare-inputs --balanced-root <train/balanced> --prediction-root <cached_predictions> --role EVAL --out <NEW directory>`|One existing frame executed; all four output arrays exactly matched the saved input bundle|Requires previously generated frozen disparity/mono predictions; not backbone inference or all-frame smoke test|
|Raw-run asset inventory|`preflight-raw --project-root <root>`|Executed read-only inventory of manifest/checkpoint presence|Presence is not array-integrity, runtime or clean-host full reproduction verification|
|Prior full additional re-evaluation|Recorded `analysis_round2` inference/CAL/native entries with original project paths|Actually executed in the earlier round; not rerun now|Not yet a verified one-command clean-host execution from public data|

## Included in CVIU_round5_analysis.zip

The standalone root includes reproduce.py, analysis_round5/, minimal unchanged original/additional scene inputs and the six CAL sampled operands (Stereo-Err/Base-Risk x3runs). Operands contain155648 native disparity errors e, uncalibrated radii h0 and directory-group labels per fit; they are GT-derived sampled data, not images or the complete GT domain. Their CURRENT archive hashes and baseline fit agreement are recorded. This inventory is not represented as a historically captured checksum receipt.

```
python reproduce.py summary
python reproduce.py cal-bootstrap
```

Python3 and NumPy are sufficient for these two modes. The same RNG seeds/draw counts in protocol.json are used; reruns overwrite derived files within the extracted analysis directory, so preserve the supplied archive. The raw source matrices/operands are never modified. The summary mode reads the supplied CAL bootstrap results only to regenerate its display table; it does not refit CAL. The cal-bootstrap mode also recalculates the paired saved-result comparison before refitting, without model or native-array evaluation.

## Data-generation path from official assets

1. Obtain the Booster official labelled archive and pretrained predictors using the links/identities in MATERIALS_ACCESS.md. Use the exact TRAIN/balanced camera00/02 members from S3 split_frames.csv; do not choose a new split. Keep RGB, GT disparity and camera calibration at4112x3008. Archived member SHA identities constrain the intended files; the original complete archive SHA was not recorded.
2. To create prediction caches from public RGB, use the preserved RAFT-Stereo/Depth Anything V2 adapters and the exact model config. Native RGB is reduced by AREA to1028x752. RAFT uses1056x768 padded input,32updates and its recorded settings; DA-V2 uses the actual714x518 official518/aspect-preserving preprocessing and restores output to1028x752. The documented project APIs are StereoAdapter.predict(left,right).disparity and MonoAdapter.predict(left).relative_depth. Save each pair's arrays as `<scene>_<frame>.npz` with keys `stereo_disparity` and `mono_relative_depth`. Source snapshots are in `generation_sources/`; third-party predictor trees, their full imports and compatible environment remain external. This public-data backbone stage was NOT rerun or validated in a clean host here; a new numerical execution need not be bit-identical to the archived caches.
3. `prepare-inputs` combines those predictions with hash-matched public RGB, using the recorded AREA resize. It writes a new directory only and refuses overwrite; `--limit` explicitly marks a smoke-test subset. It does not read GT, infer missing predictions or change geometry. The one tested EVAL frame is identified in internal_review/input_packer_check.json in the full candidate.
4. Ground-truth sampling/CAL requires the original native disparity arrays and deterministic per-group/per-frame quota policy. EVAL additionally requires per-scene fx,baseline,doffs under the recorded camera convention. The source metadata and source paths are in S3 manifests and the project operand manifests listed in MATERIALS_ACCESS.md. Do not infer or repair missing calibration from image dimensions. The historical operand-builder scripts are preserved for inspection, but have fixed paths/overwrite behavior and are NOT invoked by this wrapper.
5. Risk-head score generation uses the supplied six-family18checkpoint archive; Rel-Direct's separate3weights are outside the narrow new diagnostic. The recorded feature, normalization and checkpoint mapping must match. Follow the prior analysis_round2 inference→CAL fit→native evaluation→summary chain using one consistent new-score/new-fit execution. Original primary results cannot be silently replaced by that new execution.

Thus public raw data and supplied/official weights identify the ingredients for a new full calculation, but the distributed lightweight materials do not yet demonstrate a standalone clean-host raw pipeline. Remaining dependencies are the full raw dataset, third-party predictor trees, imports/environment, and regenerated/retained caches. Summary agreement and the one-frame input check are not substitutes for executing those stages. No missing historical provenance is reconstructed by this document.

## Validation choice and limits

The inspected ETH3D manifests record prior exposure, so its existing assets cannot be described as a fresh independent cohort. The inspected Middlebury2021 candidate has unresolved geometry/protocol conditions; no new cohort was opened here. We chose the available CAL-group refit validation, fixed its design before inspecting its outputs, and retained all outcomes. That check addresses calibration composition and OOB sampled-group coverage; it does not test transfer or robustness of EVAL selective-risk gains to refitting. An independent-cohort test and propagation of CAL uncertainty through EVAL remain separate next steps.
