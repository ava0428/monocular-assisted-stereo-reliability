"""Unified review entry. Models/raw EVAL are never run implicitly."""
from pathlib import Path
import argparse,subprocess,sys,json,hashlib,csv
H=Path(__file__).resolve().parent
p=argparse.ArgumentParser(description=__doc__);p.add_argument('mode',choices=['summary','cal-bootstrap','prepare-inputs','preflight-raw']);p.add_argument('--project-root',type=Path);p.add_argument('--balanced-root',type=Path);p.add_argument('--prediction-root',type=Path);p.add_argument('--role',choices=['CAL','EVAL'],default='EVAL');p.add_argument('--out',type=Path);p.add_argument('--limit',type=int);args=p.parse_args()
if args.mode in ['summary','cal-bootstrap']:
 cmd=[sys.executable,str(H/'analysis_round5/analyze.py')]
 if args.mode=='summary':cmd.append('--paired-only')
 subprocess.run(cmd,check=True)
elif args.mode=='prepare-inputs':
 if not all([args.balanced_root,args.prediction_root,args.out]):p.error('prepare-inputs requires --balanced-root, --prediction-root and a NEW --out directory')
 if args.out.exists():raise FileExistsError('Refusing to overwrite any existing input/archive directory')
 import numpy as np,cv2
 from PIL import Image
 def sha(f):return hashlib.sha256(f.read_bytes()).hexdigest()
 records=list(csv.DictReader((H/'review_support/split_frames.csv').open()));records=[r for r in records if r['role']==args.role]
 if args.limit:records=records[:args.limit]
 args.out.mkdir(parents=True);(args.out/'frames').mkdir();result=[]
 for r in records:
  left=args.balanced_root/r['scene']/'camera_00'/(r['frame_id']+'.png');right=args.balanced_root/r['scene']/'camera_02'/(r['frame_id']+'.png');pred=args.prediction_root/(r['scene']+'_'+r['frame_id']+'.npz')
  assert sha(left)==r['left_sha256'] and sha(right)==r['right_sha256']
  with np.load(pred,allow_pickle=False) as z:d=np.asarray(z['stereo_disparity'],np.float32);m=np.asarray(z['mono_relative_depth'],np.float32)
  assert d.shape==m.shape==(752,1028)
  l=np.asarray(Image.open(left).convert('RGB'),np.uint8);rr=np.asarray(Image.open(right).convert('RGB'),np.uint8);assert l.shape==rr.shape==(3008,4112,3)
  target=args.out/'frames'/(r['scene']+'_'+r['frame_id']+'.npz');np.savez_compressed(target,left_rgb=cv2.resize(l,(1028,752),interpolation=cv2.INTER_AREA),right_rgb=cv2.resize(rr,(1028,752),interpolation=cv2.INTER_AREA),stereo_disparity=d,mono_relative_depth=m)
  result.append({'scene':r['scene'],'frame':r['frame_id'],'role':args.role,'input_npz':target.relative_to(args.out).as_posix(),'input_sha256':sha(target),'prediction_source_sha256':sha(pred),'left_sha256':sha(left),'right_sha256':sha(right),'native_gt_sha256_required':r['gt_sha256'],'GT_read':False})
 (args.out/'manifest.json').write_text(json.dumps({'classification':'round5 reconstructed safe input packer, not historical execution file','role':args.role,'count':len(result),'frame_count':len(result),'subset':bool(args.limit),'records':result,**({'frames':result} if args.role=='EVAL' else {}),'GT_included':False,'gt_included':False,'resize_rule':'cv2.INTER_AREA 4112x3008 to1028x752','backbone_forward':False},indent=2)+'\n');print('Prepared',len(result),'frozen-input records')
else:
 if args.project_root is None:p.error('preflight-raw requires --project-root; read-only, no execution')
 paths=['outputs/jise_mono_ablation_booster_inputs_20261005/manifest.json','outputs/jise_mono_ablation_booster_cal_inputs_20261005/manifest.json','outputs/jise_mono_ablation_booster_eval_operands_20261005/manifest.json','manifests/v4_booster_cal_frames_125.json','weights/raftstereo/raftstereo-sceneflow.pth','weights/depth_anything_v2/depth_anything_v2_vits.pth']
 result={'status':'inventory_only','files':[{'path':n,'present':(args.project_root/n).is_file()} for n in paths],'full_raw_execution_validated':False,'note':'Presence does not validate every referenced array or runtime; follow REPRODUCTION_LEVELS.md.'}
 print(json.dumps(result,indent=2))
