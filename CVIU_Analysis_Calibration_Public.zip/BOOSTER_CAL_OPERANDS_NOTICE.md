# Booster-derived sampled CAL operands

Files: `analysis_round5/cal_operands/r1_20260910.npz`,
`r1_20260911.npz`, `r1_20260912.npz`, `r2_gate_20260910.npz`,
`r2_gate_20260911.npz`, and `r2_gate_20260912.npz` in that same directory.

Adapted from **Booster Dataset** (2022), Pierluigi Zama Ramirez, Fabio Tosi,
Matteo Poggi, Samuele Salti, Stefano Mattoccia and Luigi Di Stefano,
University of Bologna. DOI: https://doi.org/10.6092/unibo/amsacta/6876
Source record: https://amsacta.unibo.it/id/eprint/6876/
License: CC BY-NC 4.0, https://creativecommons.org/licenses/by-nc/4.0/

Changes: selected the declared CAL groups and sampled pixels; computed disparity
errors and uncalibrated model radii; stored arrays and group identifiers. These
six files retain the exact bytes of the prepared research operands. They are not
complete images or the complete native GT domain. No endorsement by the dataset
authors is implied. Material is provided without warranties under the source
license. These identified Booster-derived files are excluded from the authors'
MIT-code and CC-BY-result/weight grants; the original third-party terms apply.
