# Rel-Direct companion checkpoint archive

This archive adds the three existing source-selected Rel-Direct checkpoints; it does not replace CVIU_risk_head_weights.zip, which contains four central plus two content-control families only. The original checkpoint bytes, source catalog and SHA/seed/selected-step mapping are retained. Selected steps for seed0/seed1/seed2 are8000/2000/8000; total checkpoint bytes819966. Selection uses source ProxyRel-AURC, ProxyRel-AUSE and earlier step, as in the preserved catalog; no new selection or training occurred.

File hashes/sizes and catalog mappings were checked without constructing a model or running forward. The legacy serialization contains a NumPy global not supported by the current restricted weights_only loader; no unsafe retry was performed. Use a compatible environment and the preserved src/training/grel_checkpoint.py reader for actual use. The full catalog retains the seed12 post-hoc provenance qualification. This package does not provide all predictor caches, RGB/GT, geometry or historical dependencies. Prepared locally; external upload/redistribution and licence decisions remain with the authors.

code/ includes current saved project model/loader source copies and hashes for inspection. Their project imports are not a standalone environment; no loading smoke test or inference is claimed.
