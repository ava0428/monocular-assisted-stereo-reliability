# Existing-data scene sensitivity check

Unrounded results; negative differences favor Base-Risk. This is post-hoc descriptive analysis of the unchanged 19-scene EVAL cohort.

- AbsRel@0.80: raw difference -0.0112930964689372; matched difference -0.0004595813666279796. Matched scene means are lower in 18/19 scenes; this does not mean every fixed run improves.
- Mirror AbsRel@0.80 changes from raw -0.0780674636726596 to matched 0.0006479978367166193. Matched Mirror AbsRel-AURC is -8.385938036453017e-05, so the reversal is specific to the local 0.80 coverage metric.
- Removing Door/Mirror/Tablet for description only leaves matched mean difference -0.0004667438813022778 vs full -0.0004595813666279796; relative difference in magnitude 1.55849%.
- Named-scene signed share of net summed difference: raw 77.04959%; matched 14.47706%. Signed shares are descriptive and cancellation-sensitive; they are not attribution of a material mechanism.
- Raw remaining-16 mean difference -0.003077776540030213, compared with full-19 -0.0112930964689372. The raw benefit is concentrated more strongly than the small matched residual.

Bootstrap uses 10,000 paired resamples of 19 scene indices, NumPy default_rng seed 20260913, after fixed-run averaging within each scene. Intervals are unadjusted for multiple comparisons and are neither independent validation nor confirmatory significance evidence. Plot points never define AURC integrals.
