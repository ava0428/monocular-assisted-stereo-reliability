#!/usr/bin/env python3
"""Reproduce JISE summary statistics and review plots from archived summaries.

This does not reevaluate pixels, scores, GT, CAL fitting, or model inference.
Run from any directory: python reproduce.py --out review_outputs --plots
"""
from __future__ import annotations
import argparse
import csv
import hashlib
import json
import math
from pathlib import Path
import sys
import numpy as np

SEEDS = (20260910, 20260911, 20260912)
BOUNDS = (0., .2, .4, .6, .8, .9, 1.)
BASE_KEYS = tuple(f'{loss}_{suffix}' for loss in ('epe', 'mae', 'absrel') for suffix in ('80', '90', 'aurc'))
KEYS = BASE_KEYS + tuple(f'{loss}_segment_{i}_{suffix}' for loss in ('epe', 'mae', 'absrel') for i in range(6) for suffix in ('mean', 'contribution'))

def loadj(path):
    return json.loads(path.read_text(encoding='utf-8'))

def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1 << 20), b''):
            h.update(block)
    return h.hexdigest()

def rows(path):
    with path.open(encoding='utf-8', newline='') as stream:
        return list(csv.DictReader(stream))

def writej(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + '\n', encoding='utf-8')

def writecsv(path, data):
    with path.open('w', encoding='utf-8', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(data[0]))
        writer.writeheader(); writer.writerows(data)

def equal(a, b, description):
    if not np.isfinite(a) or not np.isfinite(b) or not np.isclose(a, b, rtol=5e-13, atol=1e-12):
        raise ValueError(f'{description}: {a!r} != {b!r}')

def expected_methods():
    families = ('r1', 'r2_concat', 'r2_dis', 'r2_gate', 'n_random', 'n_shuffle')
    return ([f'Raw:{f}:{s}' for f in families for s in SEEDS]
            + [f'Rel-Analytic:{f}:{s}' for f in families[:4] for s in SEEDS]
            + [f'{r}:r2_gate:{s}' for r in ('DispCal', 'Depth-Exact', 'Depth-Linear') for s in SEEDS]
            + ['Depth-Only', 'DDCV', 'PlaneSweep'] + [f'Grel:{s}' for s in SEEDS])

def group(method):
    return method.rsplit(':', 1)[0] if method.split(':')[-1] in set(map(str, SEEDS)) else method

def mean_values(lookup, scenes, method, metric):
    ids = [method.format(seed=s) for s in SEEDS] if '{seed}' in method else [method]
    return np.asarray([[lookup[(scene, m)][metric] for scene in scenes] for m in ids], dtype=np.float64)

def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--package', type=Path, default=Path(__file__).resolve().parent)
    ap.add_argument('--out', type=Path, default=Path('review_outputs'))
    ap.add_argument('--plots', action='store_true')
    args = ap.parse_args(); root = args.package.resolve(); data = root / 'data'
    manifest = loadj(root / 'package_manifest.json')
    for relative, expected in manifest['files_sha256'].items():
        path = (root / relative).resolve()
        if root not in path.parents or not path.is_file() or sha(path) != expected:
            raise ValueError(f'package identity mismatch: {relative}')
    cfg = loadj(root / 'bootstrap_config.json')
    if cfg['seed'] != 20260913 or cfg['replicates'] != 10000 or cfg['scene_count'] != 19:
        raise ValueError('different original bootstrap contract')
    archived_status = loadj(data / 'analysis_status.json')
    if archived_status['status'] != 'COMPLETE':
        raise ValueError('original summary analysis was incomplete')
    for filename in manifest['original_analysis_artifacts']:
        expected = archived_status['artifacts_sha256'][filename]
        if sha(data / filename) != expected:
            raise ValueError(f'original result identity mismatch: {filename}')

    source = rows(data / 'scene_metrics_19x45.csv')
    scenes = sorted({r['scene'] for r in source}); methods = sorted({r['method'] for r in source})
    lookup = {(r['scene'], r['method']): {k: float(r[k]) for k in KEYS} for r in source}
    if len(source) != 855 or len(lookup) != 855 or len(scenes) != 19 or set(methods) != set(expected_methods()):
        raise ValueError('expected complete 19-scene by 45-configuration matrix')
    for method in methods:
        if sum(int(r['frames']) for r in source if r['method'] == method) != 108:
            raise ValueError('frame-count mismatch')
    for row in lookup.values():
        if not all(np.isfinite(v) for v in row.values()):
            raise ValueError('unavailable result in scene matrix')
        for loss in ('absrel', 'mae', 'epe'):
            equal(math.fsum(row[f'{loss}_segment_{i}_contribution'] for i in range(6)), row[f'{loss}_aurc'], 'scene exact segment sum')
    cohort = {m: {k: float(np.mean([lookup[(s, m)][k] for s in scenes], dtype=np.float64)) for k in KEYS} for m in methods}
    original_cohort = loadj(data / 'cohort_metrics.json')['rows']
    for method in methods:
        for key in KEYS:
            equal(cohort[method][key], original_cohort[method][key], 'cohort reduction')
    fixed = []
    for g in sorted({group(m) for m in methods}):
        members = [m for m in methods if group(m) == g]
        fixed.append({'method_group': g, 'fixed_seed_replicates': len(members), **{k: float(np.mean([cohort[m][k] for m in members], dtype=np.float64)) for k in KEYS}})
    original_fixed = {r['method_group']: r for r in rows(data / 'fixed_seed_means.csv')}
    for row in fixed:
        if row['fixed_seed_replicates'] != int(original_fixed[row['method_group']]['fixed_seed_replicates']):
            raise ValueError('fixed replicate-count mismatch')
        for key in KEYS:
            equal(row[key], float(original_fixed[row['method_group']][key]), 'fixed-run mean')

    indices = np.random.default_rng(cfg['seed']).integers(0, len(scenes), size=(cfg['replicates'], len(scenes)))
    boot = []
    for row in rows(data / 'pair_bootstrap_10000.csv'):
        left = mean_values(lookup, scenes, row['left'], row['metric'])
        right = mean_values(lookup, scenes, row['right'], row['metric'])
        delta = np.mean(left - right, axis=0, dtype=np.float64)
        replicas = np.mean(delta[indices], axis=1, dtype=np.float64)
        ci = np.quantile(replicas, [.025, .975])
        computed = {'delta': float(np.mean(delta, dtype=np.float64)), 'ci_low': float(ci[0]), 'ci_high': float(ci[1])}
        for key, value in computed.items():
            equal(value, float(row[key]), f'paired scene bootstrap {key}')
        boot.append({**row, **computed})
    pairs = rows(data / 'pair_scene_differences.csv')
    for row in pairs:
        l = mean_values(lookup, [row['scene']], row['left'], row['metric'])
        r = mean_values(lookup, [row['scene']], row['right'], row['metric'])
        equal(float(np.mean(l - r, dtype=np.float64)), float(row['delta']), 'paired scene difference')

    segment_rows = []
    for row in rows(data / 'exact_segment_differences.csv'):
        i = BOUNDS.index(float(row['lo']))
        if float(row['hi']) != BOUNDS[i + 1]:
            raise ValueError('different segment bounds')
        delta = cohort[row['left']]['absrel_aurc'] - cohort[row['right']]['absrel_aurc']
        c = cohort[row['left']][f'absrel_segment_{i}_contribution'] - cohort[row['right']][f'absrel_segment_{i}_contribution']
        equal(c, float(row['exact_absrel_aurc_contribution_difference']), 'exact segment contrast')
        equal(delta, float(row['exact_total_absrel_aurc_difference']), 'exact total contrast')
        segment_rows.append({**row, 'exact_absrel_aurc_contribution_difference': c, 'exact_total_absrel_aurc_difference': delta})
    for left, right in sorted({(r['left'], r['right']) for r in segment_rows}):
        r = [x for x in segment_rows if x['left'] == left and x['right'] == right]
        if len(r) != 6:
            raise ValueError('incomplete six-segment contrast')
        equal(math.fsum(x['exact_absrel_aurc_contribution_difference'] for x in r), r[0]['exact_total_absrel_aurc_difference'], 'six-segment total')

    curves = {}
    with np.load(data / 'plot_cohort_visualization_only_1001.npz', allow_pickle=False) as z:
        for key in z.files:
            value = z[key]
            if value.shape != (1001,) or not np.isfinite(value).all():
                raise ValueError('invalid visualization payload')
            curves[key] = value.copy()
    if not np.array_equal(curves['requested_coverage'], np.linspace(0., 1., 1001)):
        raise ValueError('different visualization grid')
    for method in methods:
        for k, level in ((800, '80'), (900, '90')):
            equal(float(curves[method][k]), cohort[method][f'absrel_{level}'], 'plot fixed-coverage cross-check')
    for key in curves:
        if key.startswith('DIFF:'):
            left, right = key[5:].split(':minus:')
            if not np.allclose(curves[key], curves[left] - curves[right], rtol=5e-13, atol=1e-12):
                raise ValueError('plot difference mismatch')

    args.out.mkdir(parents=True, exist_ok=True)
    writecsv(args.out / 'cohort_45_configurations.csv', [{'method': m, **cohort[m]} for m in methods])
    writecsv(args.out / 'fixed_run_group_means.csv', fixed)
    writecsv(args.out / 'paired_bootstrap_recomputed.csv', boot)
    writecsv(args.out / 'exact_segment_differences_recomputed.csv', segment_rows)
    np.savez_compressed(args.out / 'scene_fixed_run_matrix.npz', scenes=np.asarray(scenes), methods=np.asarray(methods), metrics=np.asarray(KEYS), values=np.asarray([[[lookup[(s, m)][k] for k in KEYS] for m in methods] for s in scenes], dtype=np.float64))

    excluded = {'Door', 'Mirror', 'Tablet'}
    keep = np.asarray([s not in excluded for s in scenes]); sensitivity = {}; effects = []
    for metric in ('absrel_80', 'absrel_aurc'):
        sensitivity[metric] = {}
        for rule in ('Raw', 'Rel-Analytic'):
            l = mean_values(lookup, scenes, f'{rule}:r2_gate:{{seed}}', metric)
            r = mean_values(lookup, scenes, f'{rule}:r1:{{seed}}', metric)
            per_run = l - r; d = per_run.mean(axis=0, dtype=np.float64)
            ci = np.quantile(d[indices].mean(axis=1, dtype=np.float64), [.025, .975])
            entry = {'scenes': 19, 'lower_scene_mean_count': int(sum(d < 0)), 'higher_scene_mean_count': int(sum(d > 0)), 'delta_full19': float(d.mean(dtype=np.float64)), 'delta_remaining16': float(d[keep].mean(dtype=np.float64)), 'mean_left_full19': float(l.mean(dtype=np.float64)), 'mean_right_full19': float(r.mean(dtype=np.float64)), 'mean_left_remaining16': float(l[:, keep].mean(dtype=np.float64)), 'mean_right_remaining16': float(r[:, keep].mean(dtype=np.float64)), 'ci_low_full19': float(ci[0]), 'ci_high_full19': float(ci[1]), 'remaining_delta_relative_change': float(d[keep].mean(dtype=np.float64) / d.mean(dtype=np.float64) - 1.), 'named3_signed_share_of_net_summed_difference': float(d[~keep].sum(dtype=np.float64) / d.sum(dtype=np.float64)), 'mirror_delta_scene_mean': float(d[scenes.index('Mirror')]), 'fixed_run_lower_scene_counts': {f'seed{i}': int(sum(per_run[i] < 0)) for i in range(3)}}
            sensitivity[metric][rule] = entry
            for j, scene in enumerate(scenes):
                effects.append({'scene': scene, 'metric': metric, 'rule': rule, 'delta_fixed_run_scene_mean': float(d[j]), **{f'delta_seed{i}': float(per_run[i, j]) for i in range(3)}})
        d = (mean_values(lookup, scenes, 'Rel-Analytic:r2_gate:{seed}', metric) - mean_values(lookup, scenes, 'Depth-Only', metric)).mean(axis=0, dtype=np.float64)
        ci = np.quantile(d[indices].mean(axis=1, dtype=np.float64), [.025, .975])
        sensitivity[metric]['matched_base_minus_depth_only'] = {'delta_full19': float(d.mean(dtype=np.float64)), 'ci_low_full19': float(ci[0]), 'ci_high_full19': float(ci[1]), 'lower_scene_mean_count': int(sum(d < 0))}
    findings = {'analysis': 'Post-hoc descriptive scene sensitivity. Main cohort remains all 19 scenes. Scene means average the three fixed runs before paired scene bootstrap. No multiplicity correction, independent validation, confirmatory test, material-mechanism or pure-gate causal claim.', 'sign': 'Negative left-minus-right means lower risk for Base-Risk.', 'excluded_named_scenes_for_sensitivity_only': sorted(excluded), 'results': sensitivity}
    writej(args.out / 'scene_sensitivity_findings.json', findings)
    writecsv(args.out / 'scene_effects_raw_matched.csv', effects)
    metrics = ['absrel_80', 'absrel_aurc', 'epe_aurc', 'mae_80']
    table_groups = [f'{rule}:{f}' for rule in ('Raw', 'Rel-Analytic') for f in ('r1', 'r2_concat', 'r2_dis', 'r2_gate')] + ['Depth-Only']
    writecsv(args.out / 'scientific_summary_table.csv', [{k: row[k] for k in ['method_group', 'fixed_seed_replicates'] + metrics} for g in table_groups for row in fixed if row['method_group'] == g])

    a = sensitivity['absrel_80']['Raw']; b = sensitivity['absrel_80']['Rel-Analytic']; mirror_auc = sensitivity['absrel_aurc']['Rel-Analytic']['mirror_delta_scene_mean']
    notes = f"""# Existing-data scene sensitivity check

Unrounded results; negative differences favor Base-Risk. This is post-hoc descriptive analysis of the unchanged 19-scene EVAL cohort.

- AbsRel@0.80: raw difference {a['delta_full19']:.16g}; matched difference {b['delta_full19']:.16g}. Matched scene means are lower in {b['lower_scene_mean_count']}/19 scenes; this does not mean every fixed run improves.
- Mirror AbsRel@0.80 changes from raw {a['mirror_delta_scene_mean']:.16g} to matched {b['mirror_delta_scene_mean']:.16g}. Matched Mirror AbsRel-AURC is {mirror_auc:.16g}, so the reversal is specific to the local 0.80 coverage metric.
- Removing Door/Mirror/Tablet for description only leaves matched mean difference {b['delta_remaining16']:.16g} vs full {b['delta_full19']:.16g}; relative difference in magnitude {100*b['remaining_delta_relative_change']:.5f}%.
- Named-scene signed share of net summed difference: raw {100*a['named3_signed_share_of_net_summed_difference']:.5f}%; matched {100*b['named3_signed_share_of_net_summed_difference']:.5f}%. Signed shares are descriptive and cancellation-sensitive; they are not attribution of a material mechanism.
- Raw remaining-16 mean difference {a['delta_remaining16']:.16g}, compared with full-19 {a['delta_full19']:.16g}. The raw benefit is concentrated more strongly than the small matched residual.

Bootstrap uses 10,000 paired resamples of 19 scene indices, NumPy default_rng seed 20260913, after fixed-run averaging within each scene. Intervals are unadjusted for multiple comparisons and are neither independent validation nor confirmatory significance evidence. Plot points never define AURC integrals.
"""
    (args.out / 'scene_sensitivity_findings.md').write_text(notes, encoding='utf-8')
    if args.plots:
        make_plots(args.out, scenes, effects, curves, cohort)
    generated = ['cohort_45_configurations.csv', 'fixed_run_group_means.csv', 'paired_bootstrap_recomputed.csv', 'exact_segment_differences_recomputed.csv', 'scene_fixed_run_matrix.npz', 'scene_sensitivity_findings.json', 'scene_effects_raw_matched.csv', 'scientific_summary_table.csv', 'scene_sensitivity_findings.md']
    if args.plots:
        generated += [name + suffix for name in ('review_scene_raw_matched', 'review_full_coverage', 'review_full_coverage_difference', 'review_exact_segments') for suffix in ('.pdf', '.svg', '.png', '.alignment.json', '.alignment.svg')]
    result = {'status': 'PASS_SUMMARY_REPRODUCTION', 'scope': 'Archived unrounded summary reductions, paired scene bootstrap, exact segment summation and plot-input consistency only; not raw pixel reevaluation.', 'scenes': len(scenes), 'configurations': len(methods), 'scene_configuration_rows': len(source), 'frame_count_per_configuration': 108, 'cohort_numeric_cells': len(methods)*len(KEYS), 'bootstrap_rows_recomputed': len(boot), 'paired_scene_rows_checked': len(pairs), 'exact_segment_rows_checked': len(segment_rows), 'visualization_arrays_crc_checked': len(curves), 'plots_generated': args.plots, 'python': sys.version, 'numpy': np.__version__, 'script_sha256': sha(Path(__file__)), 'package_manifest_sha256': sha(root / 'package_manifest.json'), 'output_sha256': {name: sha(args.out / name) for name in generated}}
    writej(args.out / 'verification_result.json', result)
    print(json.dumps({k: v for k, v in result.items() if k != 'output_sha256'}, indent=2))

def make_plots(out, scenes, effects, curves, cohort):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from audit_panel_alignment import require_matplotlib_panel_alignment
    plt.rcParams.update({'font.family': 'sans-serif', 'font.sans-serif': ['Arial', 'DejaVu Sans'], 'font.size': 8, 'axes.labelsize': 8, 'xtick.labelsize': 8, 'ytick.labelsize': 8, 'legend.fontsize': 8, 'pdf.fonttype': 42, 'svg.fonttype': 'none', 'axes.spines.top': False, 'axes.spines.right': False})
    width = 125/25.4
    def save(fig, name):
        require_matplotlib_panel_alignment(fig, json_out=str(out / (name + '.alignment.json')), overlay_svg=str(out / (name + '.alignment.svg')), strict=True)
        fig.savefig(out / (name + '.pdf'), metadata={'CreationDate': None, 'ModDate': None})
        fig.savefig(out / (name + '.svg'))
        fig.savefig(out / (name + '.png'), dpi=300)
        plt.close(fig)
    fig, ax = plt.subplots(figsize=(width, 125/25.4)); fig.subplots_adjust(left=.25, right=.98, bottom=.15, top=.86)
    y = np.arange(len(scenes))
    for rule, color, marker in [('Raw', '#798797', 'o'), ('Rel-Analytic', '#317A76', 's')]:
        lookup = {r['scene']: r['delta_fixed_run_scene_mean'] for r in effects if r['metric'] == 'absrel_80' and r['rule'] == rule}
        ax.plot([lookup[s] for s in scenes], y, marker=marker, linestyle='none', markersize=4, color=color, label='Raw' if rule == 'Raw' else 'Matched Rel-Analytic')
    ax.axvline(0, color='.35', lw=.7); ax.set_yticks(y); ax.set_yticklabels(scenes); ax.invert_yaxis()
    ax.set_xlabel('Base-Risk minus Stereo-Err: AbsRel@0.80'); ax.legend(loc='lower center', bbox_to_anchor=(.5, 1.01), frameon=False)
    save(fig, 'review_scene_raw_matched')
    fig, ax = plt.subplots(figsize=(width, 80/25.4)); fig.subplots_adjust(left=.16, right=.98, bottom=.19, top=.78)
    for name, ids, color, style in [('Rel-Analytic', [f'Rel-Analytic:r2_gate:{s}' for s in SEEDS], '#317A76', '-'), ('Depth-Exact', [f'Depth-Exact:r2_gate:{s}' for s in SEEDS], '#C49347', '--'), ('Depth-Linear', [f'Depth-Linear:r2_gate:{s}' for s in SEEDS], '#805B91', ':'), ('Depth-Only', ['Depth-Only'], '#586578', '-.'), ('DDCV-LR', ['DDCV'], '#AF625B', '-')]:
        values = np.mean([curves[m] for m in ids], axis=0, dtype=np.float64)
        ax.plot(curves['requested_coverage'], values, color=color, linestyle=style, lw=1.1, label=name)
    ax.set_xlabel('Coverage'); ax.set_ylabel('AbsRel risk'); ax.set_xlim(0, 1); ax.legend(loc='lower center', bbox_to_anchor=(.5, 1.0), ncol=3, frameon=False)
    save(fig, 'review_full_coverage')
    fig, ax = plt.subplots(figsize=(width, 75/25.4)); fig.subplots_adjust(left=.16, right=.98, bottom=.20, top=.90)
    for rule, color, style in [('Rel-Analytic', '#317A76', '-'), ('Depth-Exact', '#C49347', '--'), ('Depth-Linear', '#805B91', ':')]:
        values = np.mean([curves[f'{rule}:r2_gate:{s}'] - curves['Depth-Only'] for s in SEEDS], axis=0, dtype=np.float64)
        ax.plot(curves['requested_coverage'], values, color=color, linestyle=style, lw=1.1, label=rule)
    ax.axhline(0, color='.35', lw=.7); ax.set_xlabel('Coverage'); ax.set_ylabel('AbsRel risk minus Depth-Only'); ax.set_xlim(0, 1); ax.legend(frameon=False)
    save(fig, 'review_full_coverage_difference')
    fig, ax = plt.subplots(figsize=(width, 75/25.4)); fig.subplots_adjust(left=.18, right=.98, bottom=.22, top=.80)
    x = np.arange(6)
    for j, (rule, color) in enumerate([('Rel-Analytic', '#317A76'), ('Depth-Exact', '#C49347'), ('Depth-Linear', '#805B91')]):
        values = [float(np.mean([cohort[f'{rule}:r2_gate:{s}'][f'absrel_segment_{i}_contribution'] - cohort['Depth-Only'][f'absrel_segment_{i}_contribution'] for s in SEEDS], dtype=np.float64)) for i in range(6)]
        ax.bar(x + (j-1)*.23, values, width=.23, color=color, label=rule)
    ax.axhline(0, color='.35', lw=.7); ax.set_xticks(x); ax.set_xticklabels(['0–.2', '.2–.4', '.4–.6', '.6–.8', '.8–.9', '.9–1']); ax.set_xlabel('Predeclared coverage interval'); ax.set_ylabel('Exact AbsRel-AURC contribution\nminus Depth-Only'); ax.legend(loc='lower center', bbox_to_anchor=(.5, 1.0), ncol=3, frameon=False)
    save(fig, 'review_exact_segments')

if __name__ == '__main__':
    main()
