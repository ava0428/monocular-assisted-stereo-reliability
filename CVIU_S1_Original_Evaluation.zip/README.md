# JISE light offline summary-review package

This package reproduces the **archived summary results and review plots**, not raw score-map/pixel evaluation. It preserves 19 scenes, 108 frames per configuration, 45 fixed configurations, original seed IDs, and unrounded float64 summary values. Display labels are seed0/seed1/seed2; original IDs remain in data for traceability. No model training or inference occurs.

## Portable run

Python 3.8+ and NumPy are required. Matplotlib is required only for `--plots`. There are no absolute project paths and no network calls.

```text
python reproduce.py --out review_outputs --plots
```

Run from any current directory: `python /path/to/package/reproduce.py --out ./review_outputs --plots`. The default input location is beside reproduce.py; `--package` may name a copied package directory. The bundled alignment helper has no project-dependent imports. Data identity is checked against package_manifest.json and the original completed-analysis status before any scientific output.

The script actually recomputes all 45 equal-scene cohort rows, all fixed-run means, every archived paired scene contrast and 10,000-resample bootstrap interval, and exact six-segment contrast sums from unrounded scene rows. It loads every NPZ member (including ZIP CRC verification) and checks finite arrays, coverage grid, fixed-coverage risk values, and difference curves. It outputs portable CSV tables, a 19 x 45 x 45 scene/configuration/metric matrix, descriptive scene sensitivity, verification_result.json, and four review figures. Those are review figures generated from the delivered plot inputs; they are not an assertion of byte-identical reproduction of manuscript artwork.

## What is included

- data/scene_metrics_19x45.csv: 855 unrounded scene/configuration rows; frame counts and 45 metrics each.
- data/cohort_metrics.json and fixed_seed_means.csv: archived means to cross-check.
- data/pair_bootstrap_10000.csv and pair_scene_differences.csv: all original paired comparisons and intervals.
- bootstrap_config.json: precise experimental unit, fixed-run handling, resampling, seed, bounds, interval, and post-hoc restrictions.
- data/exact_segment_differences.csv: exact predeclared segment contributions; no integration of sampled plots.
- data/plot_cohort_visualization_only_1001.npz: 1001-point cohort curve samples and differences for visualization only.
- compact calibration diagnostics and depth-stratum summaries/scene rows. Full per-frame calibration quantiles are omitted for size; their original identity is retained. Per-frame prediction-depth tertile boundaries are retained in depth_strata_cohort.json.
- original completion/integrity receipt, result/source identity hashes, and the minimal generation script.

## Evidence boundary

**Summary reductions, scene/run contrasts, uncertainty intervals, segment-total consistency, and plots are locally reproducible.** Recomputing original per-pixel metrics, score ordering, CAL fitting, GT masks, calibration quantiles, non-finite support, and native exact risk curves still needs frozen remote/native score maps, GT operands, caches and evaluator input manifests. Those multi-GB assets and original checkpoints are not included. This is not a fully self-contained raw-evaluation release. The archived status records original validation but this small package does not independently repeat raw-data or full-curve validation.

Each bootstrap sample resamples the same scene indices for both methods **after** averaging fixed runs within each scene. Three runs are fixed replicates, never 57 independent scenes. Intervals have no multiplicity correction and are post-hoc descriptive, not independent validation or confirmatory significance. The Door/Mirror/Tablet exclusion is a sensitivity description only; the 19-scene primary cohort is unchanged. Negative Base-Risk minus comparator means lower loss. Mirror sign reversal applies to AbsRel@0.80; its matched AbsRel-AURC remains negative.

## Plot contract and QA boundary

Review figures use a 125-mm physical width, editable vector text, 8-point typography and distinct line/marker encodings. Every figure is a single panel, with alignment NOT APPLICABLE recorded by the bundled geometry helper. PDF text and visual QA receipts from the actual local run are provided outside this package. Automated collision auditing may require PyMuPDF; if unavailable it is explicitly NOT AUDITABLE, not PASS. Plot samples do not substitute for exact integral evidence.
